// Optional browser QA. Usage: node review_report.js PLAYWRIGHT_MODULE REPORT_HTML OUTPUT_FOLDER
// Playwright is a development-only dependency; the operations model uses only Python's standard library.
const fs = require('fs');
const path = require('path');
const {pathToFileURL} = require('url');
const {chromium} = require(process.argv[2] || 'playwright');
const report = path.resolve(process.argv[3] || path.join(__dirname, '../outputs/report.html'));
const out = path.resolve(process.argv[4] || path.join(__dirname, '../tmp/report-review'));

(async () => {
  fs.mkdirSync(out, {recursive:true});
  const browser = await chromium.launch({channel:'msedge', headless:true});
  const page = await browser.newPage({viewport:{width:1280,height:1000}});
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto(pathToFileURL(report).href);
  await page.waitForFunction(() => document.querySelectorAll('#comparison tr').length === 17);
  if(await page.locator('#flux polyline').count() !== 4) throw new Error('Flux chart series missing');
  await page.selectOption('#scenario', 'compound');
  if(!(await page.locator('#status').innerText()).includes('Holding-time proxy exceeded')) throw new Error('Compound warning missing');
  await page.selectOption('#variant', 'outer_only');
  const middleCaptured = await page.locator('#bands tr').nth(1).locator('td').nth(2).innerText();
  if(middleCaptured !== '0.0') throw new Error('Outer-only baseline incorrectly shows middle capture');
  await page.selectOption('#variant', 'three_band');
  await page.locator('#comparison button').filter({hasText:'No permitted release window'}).click();
  if(await page.locator('#scenario').inputValue() !== 'release_closed') throw new Error('Scenario table interaction failed');
  await page.screenshot({path:path.join(out,'report-desktop.png'),fullPage:true});
  await page.setViewportSize({width:360,height:900});
  await page.waitForTimeout(150);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
  if(overflow) throw new Error('Page overflows on mobile');
  await page.screenshot({path:path.join(out,'report-mobile.png'),fullPage:true});
  if(errors.length) throw new Error(errors.join('\n'));
  console.log('Report browser review passed: scenario/architecture switching, table selection, SVG plots, mobile overflow, no runtime errors.');
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
