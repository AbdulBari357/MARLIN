"""Bounded, reproducible public data acquisition. No equipment control or AI training.

Run with the project .venv-data interpreter. HYCOM requests are strictly sequential.
Original responses, request provenance, hashes and quality checks are retained.
"""
from __future__ import annotations
import argparse
import calendar
import csv
import dataclasses
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import time
import re
from urllib.parse import urljoin
import requests
import numpy as np
import netCDF4

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RAW = DATA / "raw"
MANIFEST = DATA / "manifest.json"
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "MARLIN-public-data-research/0.1"})
CATALOG = json.loads(MANIFEST.read_text(encoding='utf-8')) if MANIFEST.exists() else {"schema_version":1,"datasets":{}}

def serializable(value):
    if dataclasses.is_dataclass(value):
        return dataclasses.asdict(value)
    if hasattr(value, 'to_dict'):
        return value.to_dict()
    if isinstance(value, (datetime, Path)):
        return str(value)
    return str(value)

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=serializable), encoding="utf-8")

def record(key, **details):
    old = CATALOG['datasets'].get(key, {})
    old.update(details)
    old['checked_at_utc'] = datetime.now(timezone.utc).isoformat()
    CATALOG['datasets'][key] = old
    write_json(MANIFEST, CATALOG)
    print(key, old.get('status', ''), flush=True)

def artifact(path):
    return {"path":str(path.relative_to(ROOT)).replace('\\','/'),"bytes":path.stat().st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}

def request(url, params=None, timeout=90):
    response = SESSION.get(url, params=params, timeout=(20, timeout))
    response.raise_for_status()
    return response

def get_json(path, url, params=None):
    if path.exists():
        return json.loads(path.read_text(encoding='utf-8'))
    response=request(url, params)
    value=response.json()
    if isinstance(value, dict) and value.get('error'):
        raise ValueError(str(value.get('reason')))
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(response.content)
    return value

def download(path, url, params=None, max_bytes=80_000_000):
    if path.exists():
        return
    path.parent.mkdir(parents=True,exist_ok=True)
    part=path.with_suffix(path.suffix+'.part')
    total=0
    with SESSION.get(url,params=params,stream=True,timeout=(20,180)) as response:
        response.raise_for_status()
        with part.open('wb') as output:
            for block in response.iter_content(1024*256):
                total+=len(block)
                if total>max_bytes:
                    raise ValueError('Bounded download exceeded size limit')
                output.write(block)
    part.replace(path)

def hourly_quality(value):
    quality=[]
    for point in value if isinstance(value,list) else [value]:
        hourly=point['hourly']
        stamps=hourly['time']
        if len(stamps)!=8784 or len(set(stamps))!=len(stamps):
            raise ValueError('2024 UTC hourly coverage is incomplete or duplicated')
        expected_start='2024-01-01T00:00'
        expected_end='2024-12-31T23:00'
        if stamps[0]!=expected_start or stamps[-1]!=expected_end or point.get('utc_offset_seconds')!=0:
            raise ValueError('Time coverage/UTC mismatch')
        if any((datetime.fromisoformat(b)-datetime.fromisoformat(a)).total_seconds()!=3600 for a,b in zip(stamps,stamps[1:])):
            raise ValueError('Non-hourly time step')
        missing={}
        for key, values in hourly.items():
            if key=='time': continue
            if len(values)!=len(stamps): raise ValueError('Variable length mismatch')
            missing[key]=sum(v is None or not math.isfinite(v) for v in values)
        quality.append({'returned_latitude':point['latitude'],'returned_longitude':point['longitude'],'hours':len(stamps),'missing':missing,'units':point['hourly_units']})
    return quality

def weather(kind):
    is_wind=kind=='wind'
    is_current=kind=='smoc'
    key='era5_wind_2024' if is_wind else ('smoc_surface_points_2024' if is_current else 'era5_ocean_waves_2024')
    url='https://archive-api.open-meteo.com/v1/archive' if is_wind else 'https://marine-api.open-meteo.com/v1/marine'
    variables='wind_speed_10m,wind_direction_10m,pressure_msl' if is_wind else ('ocean_current_velocity,ocean_current_direction,sea_level_height_msl' if is_current else 'wave_height,wave_direction,wave_period')
    params={'latitude':'24.125,24.55,24.55','longitude':'52.25,52.25,52.75','start_date':'2024-01-01','end_date':'2024-12-31','hourly':variables,'models':'era5' if is_wind else ('meteofrance_currents' if is_current else 'era5_ocean'),'timezone':'GMT','cell_selection':'sea'}
    if is_wind: params.update(wind_speed_unit='ms',elevation='nan,nan,nan')
    path=RAW/kind/(key+'.json')
    record(key,status='downloading',provider='Meteo-France/Copernicus SMOC via Open-Meteo' if is_current else 'ECMWF/Copernicus via Open-Meteo',url=url,request=params,documentation='https://open-meteo.com/en/docs/historical-weather-api' if is_wind else 'https://open-meteo.com/en/docs/marine-weather-api',limitations='Provider-processed point subset, not a full regional grid. Returned grid coordinates may differ. API hourly values may interpolate coarser native time resolution. No intake-scale validation. SMOC currents include wave/tide contributions: do not add Stokes drift again without checking conventions.',licence='Open-Meteo data CC BY 4.0; free API for non-commercial use; retain underlying provider attribution. Check terms before production use.')
    value=get_json(path,url,params)
    quality=hourly_quality(value)
    records=value if isinstance(value,list) else [value]
    output=DATA/'processed'/(key+'.csv')
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('w',encoding='utf-8',newline='') as handle:
        columns=['point_id','latitude','longitude','time_utc']+variables.split(',')
        if is_wind: columns+=['wind_u_east_m_s','wind_v_north_m_s']
        if is_current: columns+=['current_u_east_m_s','current_v_north_m_s']
        writer=csv.DictWriter(handle,fieldnames=columns)
        writer.writeheader()
        for i,point in enumerate(records):
            for j,stamp in enumerate(point['hourly']['time']):
                row={'point_id':i,'latitude':point['latitude'],'longitude':point['longitude'],'time_utc':stamp+'Z'}
                row.update({v:point['hourly'][v][j] for v in variables.split(',')})
                if is_wind:
                    speed,direction=row['wind_speed_10m'],row['wind_direction_10m']
                    row['wind_u_east_m_s']=None if speed is None or direction is None else -speed*math.sin(math.radians(direction))
                    row['wind_v_north_m_s']=None if speed is None or direction is None else -speed*math.cos(math.radians(direction))
                if is_current:
                    unit=point['hourly_units']['ocean_current_velocity']
                    if unit not in ['km/h','m/s']: raise ValueError('Unrecognized current velocity unit')
                    speed,direction=row['ocean_current_velocity'],row['ocean_current_direction']
                    speed=None if speed is None else speed/(3.6 if unit=='km/h' else 1)
                    row['current_u_east_m_s']=None if speed is None or direction is None else speed*math.sin(math.radians(direction))
                    row['current_v_north_m_s']=None if speed is None or direction is None else speed*math.cos(math.radians(direction))
                writer.writerow(row)
    status='downloaded_checked' if all(all(n==0 for n in q['missing'].values()) for q in quality) else 'downloaded_with_missing_values'
    record(key,status=status,quality=quality,artifacts=[artifact(path),artifact(output)])

def currents():
    key='hycom_surface_currents_2024'
    url='https://ncss.hycom.org/thredds/ncss/grid/GLBy0.08/expt_93.0/uv3z/2024'
    record(key,status='downloading',provider='HYCOM/NRL GOFS 3.1 + NCODA GLBy0.08 expt_93.0',url=url,bounds={'south':23,'north':25,'west':51,'east':54},depth_m=0,variables=['water_u','water_v'],documentation='https://www.hycom.org/dataserver/access-methods/ncss',licence='Freely available, distribution unlimited; acknowledge HYCOM/NRL; no fitness warranty.',limitations='Surface regional model fields only. Not local intake, tidal or net-flow validation; other depths remain pending.')
    metadata=RAW/'currents'/'hycom_dataset.xml'
    if not metadata.exists():
        metadata.parent.mkdir(parents=True,exist_ok=True)
        metadata.write_bytes(request(url+'/dataset.xml').content)
    artifacts=[artifact(metadata)]
    checks=[]
    requests_saved=[]
    for month in range(1,13):
        end=calendar.monthrange(2024,month)[1]
        params=[('var','water_u'),('var','water_v'),('north',25),('south',23),('west',51),('east',54),('disableProjSubset','on'),('horizStride',1),('time_start',f'2024-{month:02}-01T00:00:00Z'),('time_end',f'2024-{month:02}-{end:02}T23:59:59Z'),('timeStride',1),('vertCoord',0),('addLatLon','true'),('accept','netcdf4')]
        path=RAW/'currents'/f'hycom_uv_surface_2024_{month:02}.nc'
        print('HYCOM month',month,flush=True)
        download(path,url,params)
        with netCDF4.Dataset(path) as ds:
            variables={name:{'shape':list(var.shape),'units':getattr(var,'units',None)} for name,var in ds.variables.items()}
            checked={}
            for name in ['water_u','water_v']:
                if name not in ds.variables: raise ValueError('HYCOM variable unavailable')
                values=ds[name][:]
                finite=values.compressed() if np.ma.isMaskedArray(values) else values[np.isfinite(values)]
                if not finite.size: raise ValueError('HYCOM region has no valid values')
                checked[name]={'valid':int(finite.size),'masked':int(values.size-finite.size),'min':float(finite.min()),'max':float(finite.max())}
            t=ds['time'][:]
            dates=netCDF4.num2date(t,ds['time'].units)
            if len(t)<end*8 or not np.all(np.diff(t)>0): raise ValueError('Incomplete/nonmonotonic HYCOM time coverage')
            checks.append({'month':month,'timestamps':len(t),'start':str(dates[0]),'end':str(dates[-1]),'variables':variables,'values':checked})
        artifacts.append(artifact(path))
        requests_saved.append(params)
        record(key,status='partially_downloaded',artifacts=artifacts,quality=checks,requests=requests_saved)
    record(key,status='downloaded_checked')

def bathymetry():
    key='gebco_2025_regional'
    base='https://dap.ceda.ac.uk/thredds/dodsC/bodc/gebco/global/gebco_2025/ice_surface_elevation/netcdf/GEBCO_2025.nc'
    record(key,status='downloading',provider='GEBCO Compilation Group (2025) / CEDA',url=base,citation='doi:10.5285/37c52e96-24ea-67ce-e063-7086abc05f29',licence='Public domain with acknowledgement; not for navigation.',documentation='https://www.gebco.net/data-products-gridded-bathymetry-data/gebco2025-grid',bounds={'south':23,'north':25,'west':51,'east':54},limitations='Compiled regional elevation grid; insufficient for anchors/intake geometry; TID provenance layer requested separately.')
    path=RAW/'bathymetry'/'gebco_2025_23_25N_51_54E.nc'
    if not path.exists():
        path.parent.mkdir(parents=True,exist_ok=True)
        import xarray as xr
        with xr.open_dataset(base,engine='pydap',session=SESSION) as src:
            latitude=src['lat'].values
            longitude=src['lon'].values
            y=np.where((latitude>=23)&(latitude<=25))[0]
            x=np.where((longitude>=51)&(longitude<=54))[0]
            if not y.size or not x.size: raise ValueError('Empty GEBCO subset')
            elevation=src['elevation'].isel(lat=slice(y[0],y[-1]+1),lon=slice(x[0],x[-1]+1)).values
            with netCDF4.Dataset(path,'w') as dst:
                dst.createDimension('lat',len(y));dst.createDimension('lon',len(x))
                for name,values in [('lat',latitude[y]),('lon',longitude[x])]:
                    var=dst.createVariable(name,'f8',(name,));var[:]=values
                    var.setncatts({k:v for k,v in src[name].attrs.items() if k!='_FillValue'})
                var=dst.createVariable('elevation','i2',('lat','lon'),zlib=True)
                var[:]=elevation
                var.setncatts({k:v for k,v in src['elevation'].attrs.items() if k!='_FillValue'})
                dst.setncatts(src.attrs)
                dst.marlin_subset_bounds='23 to 25 N, 51 to 54 E; native spacing preserved'
    with netCDF4.Dataset(path) as ds:
        elev=ds['elevation'][:]
        checks={'shape':list(elev.shape),'negative_depth_cells':int(np.sum(elev<0)),'land_or_zero_cells':int(np.sum(elev>=0)),'min_elevation_m':int(elev.min()),'max_elevation_m':int(elev.max())}
        if checks['negative_depth_cells']==0: raise ValueError('No marine depth in subset')
    record(key,status='downloaded_checked',quality=checks,artifacts=[artifact(path)])

def tid():
    import xarray as xr
    directory='https://data.ceda.ac.uk/bodc/gebco/global/gebco_2025/type_identifier_grid/netcdf/'
    page=request(directory).text
    links=re.findall(r'href=[\"\x27]([^\"\x27]+)',page)
    candidates=sorted({urljoin(directory,link).split('?')[0] for link in links if link.lower().split('?')[0].endswith('.nc')})
    if len(candidates)!=1:
        raise ValueError('TID catalogue discovery returned '+str(candidates))
    source=candidates[0]
    base=source.replace('https://data.ceda.ac.uk/','https://dap.ceda.ac.uk/').replace('https://dap.ceda.ac.uk/bodc/','https://dap.ceda.ac.uk/thredds/dodsC/bodc/')
    path=RAW/'bathymetry'/'gebco_2025_tid_23_25N_51_54E.nc'
    if not path.exists():
        with xr.open_dataset(base,engine='pydap',session=SESSION) as src:
            print('TID variables',list(src.data_vars),flush=True)
            variables=[v for v in src.data_vars if set(src[v].dims)=={'lat','lon'}]
            if len(variables)!=1: raise ValueError('Ambiguous TID variable')
            subset=src.sel(lat=slice(23,25),lon=slice(51,54)).load()
            for target in [subset]+[subset[v] for v in subset.variables]:
                target.attrs={k:json.dumps(v) if isinstance(v,dict) else v for k,v in target.attrs.items()}
            subset.to_netcdf(path)
    with netCDF4.Dataset(path) as ds, netCDF4.Dataset(RAW/'bathymetry'/'gebco_2025_23_25N_51_54E.nc') as depth:
        for coord in ['lat','lon']:
            if not np.array_equal(ds[coord][:],depth[coord][:]): raise ValueError('TID coordinates do not match depth')
        name=next(v for v in ds.variables if set(ds[v].dimensions)=={'lat','lon'})
        values=ds[name][:]
        marine=values[depth['elevation'][:]<0]
        classes,counts=np.unique(marine,return_counts=True)
        quality={'shape':list(values.shape),'marine_source_class_counts':{str(int(k)):int(v) for k,v in zip(classes,counts)},'variable':name}
    record('gebco_2025_tid_regional',status='downloaded_checked',provider='GEBCO Compilation Group (2025) / CEDA',url=base,source_directory=directory,quality=quality,artifacts=[artifact(path)],licence='Public domain with acknowledgement; not for navigation.',documentation='https://www.gebco.net/data-products-gridded-bathymetry-data/gebco2025-grid',limitations='Source-type provenance only, not confidence intervals or a site survey.')

def biological():
    key='gbif_catostylus_photo_records'
    url='https://api.gbif.org/v1/occurrence/search'
    pages=[];records=[];offset=0
    while True:
        params={'taxonKey':2264506,'mediaType':'StillImage','limit':300,'offset':offset}
        path=RAW/'biology'/f'gbif_catostylus_photos_{offset:05}.json'
        page=get_json(path,url,params)
        pages.append(artifact(path));records.extend(page['results'])
        if page['endOfRecords']: break
        offset+=len(page['results'])
        if offset>10000: raise ValueError('Record cap exceeded')
    image_candidates=[]
    for row in records:
        for media in row.get('media',[]):
            if media.get('identifier'):
                image_candidates.append({'gbif_id':row['key'],'scientific_name':row.get('scientificName'),'country':row.get('countryCode'),'source_dataset':row.get('datasetKey'),'image_url':media['identifier'],'image_licence':media.get('license'),'creator':media.get('creator'),'references':media.get('references'),'occurrence_licence':row.get('license')})
    out=DATA/'processed'/'catostylus_image_candidates.json'
    write_json(out,image_candidates)
    record(key,status='downloaded_checked',provider='GBIF occurrence API; linked publishers retain images',url=url,query={'taxonKey':2264506,'mediaType':'StillImage'},record_count=len(records),image_candidates=len(image_candidates),artifacts=pages+[artifact(out)],licence='Per-record licence; media licence assessed separately. Not an annotated detector dataset.',limitations='Mostly external locations/citizen-science evidence; no Gulf detector validity. Bulk occurrence download DOI not created; original dataset citations retained.')
    accepted=[]
    seen=set()
    for candidate in image_candidates:
        licence=(candidate.get('image_licence') or '').lower()
        url=candidate['image_url']
        if url in seen or not any(s in licence for s in ['/by/','/by-sa/','/publicdomain/zero/','/publicdomain/mark/']): continue
        seen.add(url)
        path=RAW/'images'/'catostylus'/f"gbif_{candidate['gbif_id']}_{len(accepted):03}.jpg"
        try:
            download(path,url,max_bytes=20_000_000)
            from PIL import Image
            with Image.open(path) as im: im.verify()
            accepted.append({**candidate,**artifact(path)})
        except Exception as e:
            print('image skipped',type(e).__name__,flush=True)
        if len(accepted)>=100: break
    inventory=DATA/'processed'/'catostylus_downloaded_images.json'
    write_json(inventory,accepted)
    record('catostylus_images_seed',status='downloaded_checked' if accepted else 'no_eligible_downloads',image_count=len(accepted),artifacts=[artifact(inventory)]+[{k:r[k] for k in ['path','bytes','sha256']} for r in accepted],limitations='Seed images without bounding boxes, species review or split assignment. Not a validated training/test dataset. Each image attribution retained in inventory.')
    for label,params in [('catostylus_global',{'scientificname':'Catostylus mosaicus','size':10000}),('catostylus_gulf',{'scientificname':'Catostylus mosaicus','size':10000,'geometry':'POLYGON((48 23,57 23,57 31,48 31,48 23))'})]:
        path=RAW/'biology'/(f'obis_{label}.json')
        value=get_json(path,'https://api.obis.org/v3/occurrence',params)
        record('obis_'+label,status='downloaded_checked',provider='OBIS',url='https://api.obis.org/v3/occurrence',request=params,total=value.get('total'),retrieved=len(value.get('results',[])),artifacts=[artifact(path)],limitations='Occurrence/context records, not bloom time series or abundance at the plant; zero records means no returned data, not species absence.',licence='Underlying dataset licences and citations retained in records.')

def imagery():
    from fathomnet.api import images
    from fathomnet.dto import GeoImageConstraints
    found_all=[];coverage={}
    for concept in ['Catostylus mosaicus','Chrysaora','Chrysaora fuscescens','Scyphozoa','Sebastes']:
        found=images.find(GeoImageConstraints(concept=concept,limit=50))
        coverage[concept]=len(found)
        path=RAW/'imagery_metadata'/('fathomnet_'+concept.replace(' ','_')+'.json')
        write_json(path,found)
        found_all.append(artifact(path))
        record('fathomnet_annotations',status='partially_downloaded',provider='FathomNet/MBARI and contributors',query_limit_per_concept=50,returned_image_counts=coverage,artifacts=found_all,licence='Per-asset/per-annotation licence; metadata retained. Client MIT licence does not licence image assets.',limitations='Source concepts may overlap; counts are returned subsets, not catalogue totals. Metadata/annotations downloaded; assets remain linked pending licence review. No target species or Gulf coverage assumed; no dataset split/trained model.')
    record('fathomnet_annotations',status='downloaded_checked')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('sections',nargs='+',choices=['wind','waves','smoc','currents','bathymetry','tid','biology','imagery'])
    args=parser.parse_args()
    actions={'wind':lambda:weather('wind'),'waves':lambda:weather('waves'),'smoc':lambda:weather('smoc'),'currents':currents,'bathymetry':bathymetry,'tid':tid,'biology':biological,'imagery':imagery}
    for section in args.sections:
        try:
            actions[section]()
            if 'failure_'+section in CATALOG['datasets']: record('failure_'+section,status='resolved')
        except Exception as e:
            record('failure_'+section,status='failed',exception=type(e).__name__,reason=str(e)[:400])
            print(section,'FAILED',type(e).__name__,flush=True)

if __name__=='__main__': main()
