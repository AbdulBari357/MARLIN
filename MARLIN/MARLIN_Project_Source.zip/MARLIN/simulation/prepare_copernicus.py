"""Print bounded monthly requests; downloads only with an explicit --download flag.

Requires separately installed copernicusmarine and locally configured free sign-in
for download mode. Never prints or stores credentials.
"""
import argparse
import calendar
import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
plan=json.loads((root/'data/pending_copernicus_requests.json').read_text(encoding='utf-8'))
parser=argparse.ArgumentParser()
parser.add_argument('--download',action='store_true')
parser.add_argument('--month',type=int,choices=range(1,13),default=1)
parser.add_argument('--name',choices=[x['name'] for x in plan['requests']])
args=parser.parse_args()
for entry in plan['requests']:
    if args.name and args.name!=entry['name']: continue
    request={**plan['bounds'],'dataset_id':entry['dataset_id'],'variables':entry['variables'],
             'start_datetime':f'2024-{args.month:02}-01T00:00:00Z',
             'end_datetime':f'2024-{args.month:02}-{calendar.monthrange(2024,args.month)[1]:02}T23:59:59Z',
             'output_directory':str(root/'data/raw/copernicus'),
             'output_filename':f"{entry['name']}_2024_{args.month:02}.nc"}
    for field in ['minimum_depth','maximum_depth']:
        if field in entry: request[field]=entry[field]
    print(json.dumps(request,indent=2))
    if args.download:
        import copernicusmarine
        result=copernicusmarine.subset(**request)
        print('Download completed; inspect file coverage, units, masks and hash before simulation use.')
