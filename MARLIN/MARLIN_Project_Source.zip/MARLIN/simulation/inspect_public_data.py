"""Offline acquisition audit and reproducible window selection; no model calibration."""
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
import csv
import hashlib
import json
import math
import zipfile
import netCDF4
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def save(path,value): path.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
def artifact(path): return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

manifest=read(DATA/'manifest.json')
hycom=manifest['datasets']['hycom_surface_currents_2024']
hycom.update(status='metadata_only_service_stalled',reason='Regional January subset did not finish during bounded acquisition; no current field downloaded. Public SMOC point data acquired instead; native Copernicus grids remain pending.')
metadata=DATA/'raw/currents/hycom_dataset.xml'
hycom['artifacts']=[artifact(metadata)] if metadata.exists() else []
save(DATA/'manifest.json',manifest)

checked={}
for dataset in manifest['datasets'].values():
    for item in dataset.get('artifacts',[]):
        path=ROOT/item['path']
        actual=artifact(path)
        if actual!=item: raise ValueError('Checksum/size mismatch: '+str(path))
        checked[item['path']]=actual

environment={}
missing=[]
for name,folder in [('era5_wind_2024','wind'),('era5_ocean_waves_2024','waves'),('smoc_surface_points_2024','smoc')]:
    points=read(DATA/f'raw/{folder}/{name}.json')
    environment[name]=points
    for i,point in enumerate(points):
        hourly=point['hourly']
        stamps=[datetime.fromisoformat(t) for t in hourly['time']]
        if len(stamps)!=8784 or any(b-a!=timedelta(hours=1) for a,b in zip(stamps,stamps[1:])):
            raise ValueError('Non-contiguous timestamp coverage')
        for variable,values in hourly.items():
            if variable=='time': continue
            begin=None
            for j,v in enumerate(values+[0]):
                absent=v is None or not math.isfinite(v)
                if absent and begin is None: begin=j
                if not absent and begin is not None:
                    missing.append({'dataset':name,'point_id':i,'variable':variable,'start_utc':hourly['time'][begin]+'Z','end_utc_inclusive':hourly['time'][j-1]+'Z','missing_hours':j-begin})
                    begin=None
out=DATA/'processed/missing_intervals.csv'
with out.open('w',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['dataset','point_id','variable','start_utc','end_utc_inclusive','missing_hours'])
    writer.writeheader();writer.writerows(missing)

# Selection by matching UTC time indices, not geographic interpolation between datasets.
stamps=environment['era5_wind_2024'][0]['hourly']['time']
complete=np.ones(len(stamps),dtype=bool)
for points in environment.values():
    for point in points:
        if point['hourly']['time']!=stamps: raise ValueError('Environmental UTC alignment mismatch')
        for variable,values in point['hourly'].items():
            if variable!='time': complete &= np.array([v is not None and math.isfinite(v) for v in values])
weeks=[i for i in range(0,len(stamps)-167,24) if complete[i:i+168].all()]
if not weeks: raise ValueError('No complete weekly forcing windows')
windows=[]
def window(label,i,selection):
    return {'label':label,'start_utc':stamps[i]+'Z','end_utc_inclusive':stamps[i+167]+'Z','hours':168,'selection':selection,'interpretation':'Complete regional forcing window, not an observed jellyfish bloom or site operating limit.'}
for quarter,months in enumerate([(1,2,3),(4,5,6),(7,8,9),(10,11,12)],1):
    candidates=[i for i in weeks if datetime.fromisoformat(stamps[i]).month in months]
    windows.append(window(f'quarter_{quarter}_first_complete_week',candidates[0],'First UTC-midnight complete week beginning in quarter'))
for name,key,variable in [('high_wave_week','era5_ocean_waves_2024','wave_height'),('high_current_week','smoc_surface_points_2024','ocean_current_velocity')]:
    values=environment[key][0]['hourly'][variable]
    i=max(weeks,key=lambda index:sum(values[index:index+168])/168)
    w=window(name,i,'Highest mean of selected variable at point 0 among complete midnight-start seven-day windows')
    w.update(selection_variable=variable,selection_mean=sum(values[i:i+168])/168,selection_units=environment[key][0]['hourly_units'][variable])
    windows.append(w)
save(DATA/'processed/environment_windows.json',windows)

inventory=read(DATA/'processed/catostylus_downloaded_images.json')
dimensions=[]
for row in inventory:
    with Image.open(ROOT/row['path']) as im:
        dimensions.append({'path':row['path'],'width':im.width,'height':im.height,'format':im.format})
        im.verify()
image_summary={'downloaded':len(inventory),'unique_sha256':len({r['sha256'] for r in inventory}),'unique_occurrence_ids':len({r['gbif_id'] for r in inventory}),'countries':dict(Counter(r.get('country') or 'unknown' for r in inventory)),'media_licences':dict(Counter(r['image_licence'] for r in inventory)),'review_status':'No expert identity review, exhaustive bounding boxes or train/validation/test split. Multiple images per occurrence: group these together when splitting.'}
save(DATA/'processed/image_file_checks.json',dimensions)
fathom=[]
for p in (DATA/'raw/imagery_metadata').glob('*.json'): fathom.extend(read(p))
fathom_ids={r.get('uuid') or r.get('id') or r.get('url') for r in fathom}
regional=read(DATA/'raw/biology/obis_catostylus_gulf.json')['results']
audit={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'unique_manifest_artifacts_verified':len(checked),'verified_bytes':sum(a['bytes'] for a in checked.values()),'missing_intervals':missing,'complete_hours_all_variables_all_points':int(complete.sum()),'selected_windows':windows,'image_summary':image_summary,'fathomnet_returned_entries':len(fathom),'fathomnet_unique_ids':len(fathom_ids),'regional_obis_records':[{'location':r.get('verbatimLocality'),'eventDate':r.get('eventDate'),'flags':r.get('flags'),'coordinateUncertaintyInMeters':r.get('coordinateUncertaintyInMeters'),'license':r.get('license'),'reference':r.get('references')} for r in regional],'pending_native_downloads':read(DATA/'pending_copernicus_requests.json')}
save(DATA/'acquisition_audit.json',audit)

ds=manifest['datasets']
tid=ds['gebco_2025_tid_regional']['quality']['marine_source_class_counts']
codes={'10':'singlebeam','11':'multibeam','14':'chart sounding','16':'optical light sensor depth measurement','17':'combined direct measurements','40':'gravity-guided prediction/interpolation','41':'algorithmic interpolation','42':'chart contours','43':'ENC contours','44':'mixed measured/derived gridded sources','70':'pre-generated mixed-source grid','71':'unknown source','72':'steering point'}
tid_text=', '.join(f"{k}: {v:,} ({codes.get(k,'see GEBCO code table')})" for k,v in tid.items())
report=f'''# MARLIN public-data acquisition report

Reviewed 11 October 2026. Initial research collection; not a calibrated or validated site model.

## Actual downloaded data

| Source | Files/coverage acquired | Intended use | Limits |
|---|---|---|---|
| ERA5 wind via Open-Meteo | Three points, all 8,784 UTC hours of 2024; wind speed/direction and pressure; raw JSON and CSV | Seasonal/weather forcing and vessel interruption scenarios | Provider-processed point subset, approximately 0.25-degree native grid; no local wind validation |
| ERA5-Ocean waves via Open-Meteo | Three points, all 8,784 hourly slots of 2024; height/direction/period; raw JSON and CSV | Rough/calm conditions and optional bubble trial scenarios | Approximately 0.5-degree native grid; hourly output is not proof of hourly native information; no bubble-effectiveness measurement |
| SMOC currents/sea level via Open-Meteo | Three points, 8,784 slots of 2024; 96 missing hours per current variable per point, 168 per sea-level point | Surface current direction/speed and regional water-level forcing | Missing intervals preserved. Approximately 1/12-degree native grid. Cannot reconstruct three-dimensional channel flow from three points |
| GEBCO_2025 elevation and matching TID | Two 480 × 720 NetCDF subsets, 23–25° N / 51–54° E, native 15-arc-second spacing | Regional domain depth and source provenance | Roughly 400–460 m spacing; not navigation, anchors or intake survey data |
| GBIF Catostylus mosaicus photo records | {ds['gbif_catostylus_photo_records']['record_count']:,} occurrence records, {ds['gbif_catostylus_photo_records']['image_candidates']:,} media candidates | Traceable image candidates and species context | Original records/media licences differ; occurrence licence does not automatically licence image |
| GBIF linked species photographs | {len(inventory)} image files; {image_summary['unique_sha256']} unique file hashes; {image_summary['unique_occurrence_ids']} occurrence groups | Initial species-image annotation exercise | Not yet an expert-labelled detector dataset; {image_summary['countries']} geography is unlike local deployment |
| OBIS species occurrence query | {ds['obis_catostylus_global']['retrieved']:,} global records; {len(regional)} in broad Gulf/adjacent bounding box | Biological context and review of species evidence | No abundance/bloom time series; regional record has quality flags described below |
| FathomNet | {len(fathom)} returned metadata/annotation entries across queries; {len(fathom_ids)} unique identifiers | Supplemental underwater object and non-target annotation review | Image assets have NOT been downloaded; queries may overlap; exact Catostylus mosaicus query returned zero |

Point indices identify different returned grid locations for each source. These are not three coincident observation stations. Exact request/returned coordinates, units, source URLs, retrieval dates and SHA-256 hashes are in `manifest.json`. Downloads and file checks do not establish physical accuracy.

## Checks and findings

- Verified {len(checked)} unique manifest artifacts against recorded hashes and byte counts; {audit['verified_bytes']/1e6:.1f} MB of original/derived artifacts.
- All environmental timestamps are contiguous, unique UTC hours for 2024. Wind/waves have no missing values for the requested variables.
- {int(complete.sum()):,} hours have all requested values at all three points across all three products. Missing values remain blank in CSV; they are never converted to calm water or zero current. See `processed/missing_intervals.csv`.
- Wind direction is meteorological FROM; wind components use the negative sine/cosine convention. SMOC direction is TO; raw velocity in km/h is converted to m/s for east/north components. Raw units remain intact.
- SMOC includes tidal/wave contributions as documented by the provider; do not blindly add separate Stokes drift to the same current convention.
- GEBCO marine cells: {ds['gebco_2025_regional']['quality']['negative_depth_cells']:,}. TID marine counts: {tid_text}. These classifications are source types, not uncertainty bounds. No local dredged-channel geometry is established.
- Six complete seven-day windows are selected reproducibly in `processed/environment_windows.json`: one per quarter plus high-mean-wave and high-mean-current windows at each product's point 0. They are candidate forcing scenarios, NOT recorded blooms or certified worst cases.
- Images decode successfully and have retained per-image attribution/licence. Split images by occurrence/source/deployment, never randomly across repeated photographs of one occurrence. Expert identity and box annotation review remain pending.
- FathomNet query counts: {ds['fathomnet_annotations']['returned_image_counts']}. Counts are bounded returned subsets, not full catalogue totals or independent samples.
- The one regional OBIS return is a 2019 Dubai citizen-science observation, with `ON_LAND` and `NO_DEPTH` flags and a CC BY-NC licence. It is not reliable evidence of a bloom at Barakah. Retain it for review; do not use it to calibrate bloom density. Global GBIF/OBIS records can overlap.
- HYCOM metadata was retrieved, but its regional field download stalled. No HYCOM current dataset is included. An alternative public SMOC point subset was acquired.

## Prepared, not downloaded

`pending_copernicus_requests.json` and `../simulation/prepare_copernicus.py` prepare bounded 2024 requests for GLORYS depth-dependent physics, native SMOC regional hourly currents and WAVERYS waves/Stokes drift. These require free sign-in and catalogue/variable checks. Native grid downloads remain necessary before a defensible regional particle-transport experiment; additional local hydraulics remains unresolved even then. Reanalysis/current products sharing sources are not independent validation observations.

## Integration status

The current MARLIN operations model still uses synthetic arrivals, capture efficiencies and fault assumptions. These downloads are NOT already driving it. Next: obtain native grids → inspect masks/depth/time/velocity conventions → build regional transport plus explicitly assumed local boundary scenarios → derive arrival flux → feed operations model → compare designs and faults. Report assumed jellyfish buoyancy/swimming/size, vertical distribution and mass conversion separately. Public data do not measure guide-net collection, bubble deflection, bycatch or survival.

## Source documentation and terms

- [Open-Meteo historical weather](https://open-meteo.com/en/docs/historical-weather-api) and [marine documentation](https://open-meteo.com/en/docs/marine-weather-api): processed environmental data, attribution and API use limits. Retain ECMWF/Copernicus and Meteo-France attribution. Free API use is for non-commercial research; review production terms.
- [GEBCO_2025 and TID code definitions](https://www.gebco.net/data-products-gridded-bathymetry-data/gebco2025-grid); cite GEBCO Compilation Group (2025), doi:10.5285/37c52e96-24ea-67ce-e063-7086abc05f29. Public domain with acknowledgement; not navigation data.
- [GBIF media guidance](https://techdocs.gbif.org/en/openapi/images), [OBIS access](https://portal.obis.org/data/access/) and [FathomNet terms](https://www.fathomnet.org/terms). Preserve original dataset/asset citations. This research package has mixed licences, not one blanket commercial licence.
- [GLORYS](https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_PHY_001_030/services), [native SMOC](https://data.marine.copernicus.eu/product/GLOBAL_ANALYSISFORECAST_PHY_001_024/services), [WAVERYS](https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_WAV_001_032/services).

## Reproduce

From the project root, use the local research interpreter:

```powershell
marlin-development/.venv-data/Scripts/python.exe marlin-development/simulation/acquire_public_data.py wind waves smoc bathymetry tid biology imagery
marlin-development/.venv-data/Scripts/python.exe marlin-development/simulation/inspect_public_data.py
marlin-development/.venv-data/Scripts/python.exe marlin-development/simulation/prepare_copernicus.py --month 1
```

The last command is a dry run. Actual account-dependent retrieval is a separate step. Re-running acquisition uses cached environmental/GBIF/OBIS responses; external catalogues and imagery may change.
'''
(DATA/'DATA_REPORT.md').write_text(report,encoding='utf-8')
(DATA/'README.md').write_text('''# MARLIN public research data — initial collection

Read [DATA_REPORT.md](DATA_REPORT.md) for acquired coverage, checks, limitations, licences and remaining requests. The archive also includes `BOAT_AND_EVIDENCE_GAPS.md` for vessel strategy and issues simulation cannot resolve alone; its editable source lives in the project's docs folder.

- `raw/`: original provider responses, image files and regional NetCDF subsets.
- `processed/`: environmental CSVs, missing intervals, complete scenario windows and image attribution/check inventories.
- `manifest.json`: exact requests, returned locations, hashes, licences and acquisition status.
- `acquisition_audit.json`: offline checks and findings.
- `pending_copernicus_requests.json`: prepared account-dependent requests; no credentials.

This initial collection supports research planning. It is not ENEC operating data or proof of MARLIN performance. The existing operations simulation has not been connected to these environmental files. Images are a seed collection without expert-reviewed detector labels. Preserve per-asset attribution and restrictions; occurrence records can carry non-commercial licences.
''',encoding='utf-8')

# Package data only; exclude environments, credentials, partial downloads and archive itself.
archive=DATA/'marlin-public-data-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(DATA.rglob('*')):
        if path.is_file() and path!=archive and path.suffix not in ['.zip','.part']:
            z.write(path,path.relative_to(DATA))
    z.write(ROOT/'docs/BOAT_AND_EVIDENCE_GAPS.md','BOAT_AND_EVIDENCE_GAPS.md')
print(json.dumps({'verified_artifacts':len(checked),'image_summary':image_summary,'fathomnet_unique_ids':len(fathom_ids),'tid_counts':tid,'complete_hours':int(complete.sum()),'missing_intervals':missing,'archive_mb':archive.stat().st_size/1e6},indent=2))
