"""Accounting and operational fault tests; no claim of physical validation."""
import copy
import json
from pathlib import Path
import unittest

from marlin_sim import SCENARIOS, sampled_config, simulate, validate


class ModelTests(unittest.TestCase):
    def setUp(self):
        self.cfg = json.loads((Path(__file__).resolve().parents[1] / "config/model.json").read_text(encoding="utf-8"))

    def test_all_scenarios_conserve_mass_and_do_not_invent_disposal(self):
        for scenario in SCENARIOS:
            for variant in ("three_band", "outer_only"):
                with self.subTest(scenario=scenario["id"], variant=variant):
                    result = simulate(self.cfg, scenario["id"], variant, False)
                    s = result["summary"]
                    self.assertLess(s["max_mass_balance_error_kg"], 1e-5)
                    self.assertAlmostEqual(s["external_kg"], s["residual_beyond_inner_kg"] + s["held_at_end_kg"] + s["in_transit_at_end_kg"] + s["released_at_sea_account_kg"], places=5)
                    for b, cfg in zip(result["bands"], self.cfg["bands"]):
                        self.assertLessEqual(b["stats"]["peak_net_kg"], cfg["net_capacity_kg"] + 1e-6)
                        self.assertLessEqual(b["stats"]["peak_receiver_kg"], cfg["receiver_capacity_kg"] + 1e-6)
                        self.assertGreaterEqual(b["retained_at_end_kg"], 0)

    def test_complete_interception_and_adequate_service_are_accounted(self):
        cfg = copy.deepcopy(self.cfg)
        cfg["release_return_fraction"] = 0
        cfg["bands"][0]["efficiency"] = 1
        cfg["bands"][0]["collector_rate_kg_h"] = 5000
        cfg["transport_release_rate_kg_h"] = 5000
        s = simulate(cfg, keep_series=False)["summary"]
        self.assertAlmostEqual(s["residual_beyond_inner_kg"], 0)
        self.assertAlmostEqual(s["released_at_sea_account_kg"], s["external_kg"])
        self.assertAlmostEqual(s["held_at_end_kg"], 0)

    def test_no_release_service_exposes_overload_and_unresolved_catch(self):
        cfg = copy.deepcopy(self.cfg)
        cfg["transport_release_rate_kg_h"] = 0
        s = simulate(cfg, keep_series=False)["summary"]
        self.assertGreater(s["residual_beyond_inner_kg"], 0)
        self.assertGreater(s["held_at_end_kg"], 0)
        self.assertTrue(s["holding_age_flag"])
        self.assertAlmostEqual(s["released_at_sea_account_kg"], 0)
        self.assertAlmostEqual(s["unresolved_percent_external"], 100)

    def test_returned_mass_is_not_counted_as_new_external_biomass(self):
        r = simulate(self.cfg, "high_return", keep_series=False)
        self.assertGreater(r["summary"]["returned_kg"], 0)
        self.assertAlmostEqual(r["summary"]["external_kg"], self.cfg["external_rate_kg_h"] * self.cfg["input_duration_hours"])
        self.assertGreater(r["summary"]["historical_transfer_release_kg"], r["summary"]["released_at_sea_account_kg"])

    def test_reserve_collectors_receive_more_during_primary_outage(self):
        base = simulate(self.cfg, keep_series=False)
        fault = simulate(self.cfg, "outer_outage", keep_series=False)
        self.assertGreater(fault["bands"][1]["stats"]["collected_kg"], base["bands"][1]["stats"]["collected_kg"])
        self.assertTrue(any("collector_unavailable" in e["code"] for e in fault["alerts"]))

    def test_missing_observation_is_explicit_and_local_network_loss_does_not_disable_reserve(self):
        blind = simulate(self.cfg, "sensor_blind", keep_series=False)
        network = simulate(self.cfg, "network_loss", keep_series=False)
        self.assertTrue(any("sensor_missing" in e["code"] for e in blind["alerts"]))
        self.assertGreater(network["bands"][1]["stats"]["collected_kg"], 0)
        self.assertGreater(network["bands"][2]["stats"]["collected_kg"], 0)

    def test_unsafe_maintenance_is_refused_and_lull_can_permit_it(self):
        full = simulate(self.cfg, "maintenance_full", keep_series=False)
        lull = simulate(self.cfg, "maintenance_lull", keep_series=False)
        self.assertFalse(full["summary"]["maintenance_permitted"])
        self.assertIn("maintenance_refused", full["alarm_minutes"])
        self.assertTrue(lull["summary"]["maintenance_permitted"])

    def test_zero_external_input_cannot_create_biomass(self):
        cfg = copy.deepcopy(self.cfg)
        cfg["external_rate_kg_h"] = 0
        s = simulate(cfg, keep_series=False)["summary"]
        for key in ("external_kg", "returned_kg", "released_at_sea_account_kg", "held_at_end_kg", "residual_beyond_inner_kg"):
            self.assertEqual(s[key], 0)

    def test_seeded_parameter_sets_are_reproducible_and_do_not_mutate_original(self):
        original = copy.deepcopy(self.cfg)
        a = sampled_config(self.cfg, 42)
        b = sampled_config(self.cfg, 42)
        self.assertEqual(a, b)
        self.assertEqual(self.cfg, original)
        self.assertEqual(simulate(a, keep_series=False), simulate(b, keep_series=False))

    def test_halving_timestep_preserves_accounting_and_close_reference_output(self):
        half = copy.deepcopy(self.cfg)
        half["step_minutes"] = 0.5
        a = simulate(self.cfg, keep_series=False)["summary"]
        b = simulate(half, keep_series=False)["summary"]
        self.assertLess(b["max_mass_balance_error_kg"], 1e-5)
        self.assertLess(abs(a["residual_percent_external"] - b["residual_percent_external"]), 0.5)

    def test_invalid_configuration_rejected(self):
        for key, value in (("step_minutes", 0), ("release_return_fraction", 1.1), ("observation_duration_hours", 1), ("external_rate_kg_h", float("inf"))):
            cfg = copy.deepcopy(self.cfg)
            cfg[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate(cfg)


if __name__ == "__main__":
    unittest.main()
