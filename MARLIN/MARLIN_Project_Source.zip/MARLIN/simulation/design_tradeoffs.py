"""Compare illustrative capacity changes. Never a hardware sizing recommendation."""
import copy
import csv
import json
from pathlib import Path

from marlin_sim import SCENARIOS, simulate


def variants(cfg):
    reserves = copy.deepcopy(cfg)
    reserves["bands"][1].update(collector_rate_kg_h=1400, net_capacity_kg=350, receiver_capacity_kg=700, collector_power_kw=6)
    reserves["bands"][2].update(collector_rate_kg_h=700, net_capacity_kg=180, receiver_capacity_kg=400, collector_power_kw=3.5)
    logistics = copy.deepcopy(cfg)
    logistics["transport_release_rate_kg_h"] = 3200
    combined = copy.deepcopy(reserves)
    combined["transport_release_rate_kg_h"] = 3200
    return {"reference_assumptions": cfg, "larger_reserve_assumptions": reserves,
            "larger_logistics_assumption": logistics, "combined_assumptions": combined}


def main():
    root = Path(__file__).resolve().parents[1]
    cfg = json.loads((root / "config/model.json").read_text(encoding="utf-8"))
    rows = []
    for label, inputs in variants(cfg).items():
        for scenario in SCENARIOS:
            s = simulate(inputs, scenario["id"], keep_series=False)["summary"]
            rows.append({"illustrative_design": label, "scenario": scenario["id"],
                         "residual_percent": s["residual_percent_external"],
                         "holding_age_flag": s["holding_age_flag"],
                         "maintenance_permitted": s["maintenance_permitted"],
                         "partial_electricity_kwh": s["equipment_electricity_kwh"],
                         "held_at_end_kg": s["held_at_end_kg"]})
    output = root / "outputs"
    output.mkdir(exist_ok=True)
    with (output / "design_tradeoffs.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = ["# Illustrative design tradeoffs", "", "**All capacities and powers are synthetic. These are not measured improvements or procurement specifications. No hydraulic, survival, fuel or total-cost comparison is computed.**", "",
             "Larger reserves modify middle/inner collection and receiving assumptions. Larger logistics doubles the aggregated service rate; an actual vessel plan is not modelled. No capacity is changed secretly in the reference results.", "",
             "| Illustrative design | Scenario | Residual % | Age flag | Maintenance permitted | Partial electricity kWh |", "|---|---|---:|---|---|---:|"]
    focus = {"reference", "outer_outage", "sustained_overload", "release_closed", "high_return", "maintenance_full", "compound"}
    for r in rows:
        if r["scenario"] in focus:
            lines.append(f"| {r['illustrative_design']} | {r['scenario']} | {r['residual_percent']:.2f} | {r['holding_age_flag']} | {r['maintenance_permitted']} | {r['partial_electricity_kwh']:.1f} |")
    lines += ["", "Additional capacity does not make a prolonged closed release route safe. Time-limit flags and shared failures remain. Field sizing requires measured incoming-load distributions, actual flow effects, validated welfare limits and realistic transport/release availability."]
    (output / "DESIGN_TRADEOFFS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Completed {len(rows)} illustrative design/scenario combinations; see outputs/DESIGN_TRADEOFFS.md")


if __name__ == "__main__":
    main()
