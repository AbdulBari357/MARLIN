"""Run MARLIN's depth-resolved, reduced-order bubble-plume screening model."""
import copy
import csv
import json
import math
from pathlib import Path

from engine import DISCLAIMER, SCENARIOS, VARIANTS, simulate
from forcing import Forcing

ROOT=Path(__file__).resolve().parents[2]
CONFIG=ROOT/'config/model_two_layer_physics.json'
OUTPUT=ROOT/'outputs/v3/two-layer-plume'
OFF='two_off';AIR_ON='two_airlift_physics_test'
RUN_VARIANTS=[OFF,AIR_ON,'two_bubble_wall_only','two_airlift_plus_wall','three_airlift_plus_wall']

def write_csv(path,rows):
 fields=list(dict.fromkeys(k for row in rows for k in row))
 with path.open('w',encoding='utf-8',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows(rows)

def diffuser_copy(source,name,role,start,end):
 return {'name':name,'role':role,'diffuser_start_xy_m':start,'diffuser_end_xy_m':end,
         'diffuser_bottom_clearance_m':source['diffuser_bottom_clearance_m'],
         'diffuser_spacing_m':source['diffuser_spacing_m'],
         'gas_flow_per_metre_m3_s_m':source['gas_flow_per_metre_m3_s_m']}

def main():
 cfg=json.loads(CONFIG.read_text(encoding='utf-8'));forcing=Forcing(ROOT)
 flow=forcing.select(forcing.windows[0]['label'],cfg['observation_hours'])
 variant_map={v['id']:v for v in VARIANTS};records=[];runs=[]
 source=cfg['bubble']
 airlift=diffuser_copy(source,'Seabed airlift','airlift',source['diffuser_start_xy_m'],source['diffuser_end_xy_m'])
 wall=diffuser_copy(source,'Near-outer bubble wall','curtain',[92.0,3.0],[127.0,117.0])
 third={'name':'inner','start':[285,3],'end':[320,117],'intercept_probability':0.75,
        'capture_load_limit_kg':180,'collector_rate_kg_h':500,'receiver_capacity_kg':300,
        'activate_flux_kg_h':60,'activation_delay_minutes':4,'collector_power_kw':2.5,
        'skirt_depth_m':6.0,'skirt_depth_note':'Illustrative third-layer skirt; requires site and ecological review.'}
 def config_for(variant):
  run=copy.deepcopy(cfg)
  if variant=='two_bubble_wall_only':
   run['bubble']['diffusers']=[copy.deepcopy(wall)]
   run['bubble']['compressor_power_kw']=6.0
  elif variant in ('two_airlift_plus_wall','three_airlift_plus_wall'):
   run['bubble']['diffusers']=[copy.deepcopy(airlift),copy.deepcopy(wall)]
   run['bubble']['compressor_power_kw']=12.0
  if variant=='three_airlift_plus_wall':
   run['bands'].append(copy.deepcopy(third))
   run['vessel']['pickup_travel_minutes_by_band'].append(5)
  return run
 for variant in RUN_VARIANTS:
  cfg_run=config_for(variant)
  result=simulate(cfg_run,flow,'reference',variant,cfg['seed'],detail=True)
  result['variant_label']=variant_map[variant]['label']
  summary=result['summary'];bands={b['name']:b for b in result['bands']}
  layer_names=[b['name'] for b in cfg_run['bands']]
  rec={'scenario':'reference','scenario_label':'Reference bloom / same forcing',
       'variant':variant,'variant_label':variant_map[variant]['label'],
       'layer_count':len(layer_names),'final_layer':layer_names[-1],
       'outer_intercepted_kg':round(bands.get('outer',{}).get('intercepted_kg',0),3),
       'second_intercepted_kg':round(bands.get('second',{}).get('intercepted_kg',0),3),
       'third_intercepted_kg':round(bands.get('inner',{}).get('intercepted_kg',0),3),
       'beyond_final_kg':round(summary['residual_kg'],3),
       'beyond_final_percent':round(summary['residual_percent'],3),
       'unknown_domain_exit_percent':round(summary['unknown_exit_percent'],3),
       'bubble_lifted_percent':round(summary['bubble_lifted_percent'],3),
       'gas_flow_m3_h':round(summary['bubble_gas_flow_m3_h'],3),
       'bubble_kwh':round(summary['bubble_kwh'],3),
       'bubble_active_minutes':round(summary['bubble_active_minutes'],2),
       'total_kwh':round(summary['total_kwh'],3),
       'max_accounting_error_kg':summary['max_accounting_error_kg'],
       'gap_codes':'; '.join(sorted({g['code'] for g in result['gaps']}))}
  records.append(rec);runs.append(result)
  print(f"Completed {variant}",flush=True)
 OUTPUT.mkdir(parents=True,exist_ok=True)
 write_csv(OUTPUT/'scenario_summary.csv',records)
 payload={'model':'MARLIN v3 reduced-order bubble-plume and layered interception screening model',
          'disclaimer':DISCLAIMER,'config':cfg,'forcing':flow.metadata(),
          'case_variants':RUN_VARIANTS,'runs':runs,
          'scenario_scope':'Five same-forcing comparisons: two-layer no bubbles, upstream seabed airlift, near-outer bubble wall, combined diffusers, and the same combined diffusers with a third layer. No ML/CV is used.'}
 (OUTPUT/'results.json').write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False,separators=(',',':')),encoding='utf-8')
 by={row['variant']:row for row in records}
 lines=['# MARLIN v3 — bubble placement and layer comparison','','**Status: illustrative research screening only.** The airlift and curtain are modeled as seabed diffuser lines that entrain water upward. The wall is not given a perfect-blocking or animal-avoidance effect. This is a reduced-order model, not CFD or field validation.',
        '',f"Forcing window: {flow.window['label']}. All five runs use the same deterministic reference arrivals and random seed so changes can be compared. No trained ML/CV is used; bubble operation is forced on in the bubble cases to isolate hydrodynamics.",
        '', '## Five necessary comparisons','','| Configuration | Layers | Diffuser flow (m³/h) | Bubble-attributed lift (%) | Outer intercepted (kg) | Second (kg) | Third (kg) | Past final layer (%) | Bubble energy (kWh) |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
 for variant in RUN_VARIANTS:
  row=by[variant]
  lines.append(f"| {row['variant_label']} | {row['layer_count']} | {row['gas_flow_m3_h']:.1f} | {row['bubble_lifted_percent']:.2f} | {row['outer_intercepted_kg']:.1f} | {row['second_intercepted_kg']:.1f} | {row['third_intercepted_kg']:.1f} | {row['beyond_final_percent']:.2f} | {row['bubble_kwh']:.1f} |")
 lines += ['', '## Layout and meaning','',
  '- The current airlift line is about 45 m upstream of the outer boom. It is not too close; if anything, it provides a longer exposure distance before the first layer.',
  '- The comparison curtain is a second seabed diffuser line parallel to the outer boom, about 8 m upstream of it. “Just below the first layer” is interpreted as immediately upstream in the intakeward direction, in plan view; it is not a shallow mid-water diffuser.',
  '- Bubble wall only isolates the near-outer line. The combined case adds that line to the original upstream seabed airlift. The three-layer case adds a third surface-to-skirt guide at the inner end.',
  '- Bubble flow is represented through water upwelling and current-shifted plumes. The model does not yet compute lateral avoidance/redirection, individual jellyfish behavior, wave-driven Stokes drift, plume-to-plume interaction, or bubble-curtain contact/penetration probability. A rising curtain is not a solid barrier.',
  '- The extra diffuser is assigned twice the single-line compressor power as a placeholder, proportional to doubled gas flow. Compressor sizing and cost are not established.',
  '- Jellyfish are weighted cohorts. Bubble-attributed lift is a paired trajectory metric; it does not mean collected, safely removed, or proof of successful deflection.',
  '',
  '## Interpretation cautions','',
  '- Read the comparison as a test of model wiring and conditional assumptions, not predicted ENEC performance. Sea-state and intake-current data, diffuser flow, outlet spacing, bubble size, plume width, water-column velocity, skirt geometry, collection capacity and ecological effects need measurements.',
  '- Published experiments report that bubble-curtain outcomes vary with current, waves, airflow and jellyfish size; one field curtain deflected large compass jellyfish while a low-flow curtain did not significantly affect small hydromedusae. That makes a calibrated flume trial essential.',
  '- The third layer is a reserve capture opportunity, not a replacement for poor outer capture. It can only recover material still inside the modeled domain and within its skirt depth.',
  '- A near-outer wall may reduce the crossflow distance before the outer boom, but its real value depends on measured upwelling and plume behavior. Compare the outputs here; do not assume it improves performance.',
  '',
  '## Validation before design','',
  '- Survey bathymetry and depth-resolved currents; confirm allowable placement and intake protection geometry with ENEC.',
  '- Flume-test single and paired diffuser lines under current and wave sweeps. Measure gas flow, bubble size, plume width, three-component water velocity, and flexible-surrogate trajectories.',
  '- Fit plume coefficients on calibration runs and check against held-out runs. Conduct ecological review and approvals before any animal exposure trial.',
  '- A small mass-accounting error confirms bookkeeping only; it does not validate the physics.',
  '',
  f"Maximum mass-accounting error across {len(records)} cases: {max(row['max_accounting_error_kg'] for row in records):.3e} kg.",
  '',
  'See scenario_summary.csv and results.json. The interactive report is report.html and can be opened through the local MARLIN server.']
 (OUTPUT/'RUN_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 (OUTPUT/'report.html').write_text(HTML,encoding='utf-8')
 print(json.dumps({'output':str(OUTPUT.resolve()),'runs':len(records),
                   'max_mass_error_kg':max(row['max_accounting_error_kg'] for row in records),
                   'html':str((OUTPUT/'report.html').resolve())},indent=2))

HTML=r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MARLIN v3 — depth-resolved simulation</title><style>
:root{color-scheme:dark;--bg:#071622;--panel:#102637;--line:#27445a;--text:#e5f0f5;--muted:#9cb3c2;--teal:#4de0c0;--amber:#ffbd64;--red:#ff786b;--blue:#65b7ff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 80% 0%,#12314a,var(--bg) 55%);color:var(--text);font:15px/1.5 system-ui,Segoe UI,sans-serif}main{max-width:1260px;margin:auto;padding:28px}header{display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:20px}h1{font-size:clamp(26px,4vw,42px);line-height:1.05;margin:0 0 7px;letter-spacing:-.03em}.sub,.muted{color:var(--muted)}.badge{border:1px solid #ac7b39;color:#ffd494;background:#52351266;border-radius:999px;padding:6px 11px;font-size:12px;white-space:nowrap}.layout{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(270px,.8fr);gap:16px}.card{background:linear-gradient(145deg,#122c3e,#0b1e2c);border:1px solid var(--line);border-radius:16px;padding:18px;box-shadow:0 12px 40px #0003}.canvaswrap{height:min(57vh,510px);min-height:330px;background:#0a2637;border-radius:10px;overflow:hidden}canvas{display:block;width:100%;height:100%}.controls{display:grid;grid-template-columns:1fr auto auto;gap:12px;align-items:center;margin-top:15px}select,button{background:#18394e;color:var(--text);border:1px solid #355a70;border-radius:9px;padding:9px 12px;font:inherit}button{cursor:pointer}button:hover{border-color:var(--teal)}input{width:100%;accent-color:var(--teal)}.metrics{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}.metric{padding:12px;background:#081a27;border:1px solid #203a4c;border-radius:10px}.metric b{font-size:20px;display:block}.metric span{font-size:12px;color:var(--muted)}h2{font-size:18px;margin:0 0 12px}.key{display:flex;flex-wrap:wrap;gap:12px;margin-top:12px;color:var(--muted);font-size:12px}.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px}.note{font-size:13px;color:var(--muted);margin-top:14px}.equation{font:13px ui-monospace,Consolas,monospace;color:#c4e7ec;background:#081a27;border-radius:8px;padding:10px;overflow-wrap:anywhere}.side p{margin:.4em 0}.side ul{padding-left:18px;color:var(--muted)}footer{color:var(--muted);font-size:12px;margin-top:16px}@media(max-width:850px){main{padding:16px}.layout{grid-template-columns:1fr}.canvaswrap{height:45vh}.controls{grid-template-columns:1fr auto}.controls select{grid-column:1/-1}}
</style></head><body><main><header><div><h1>MARLIN, in the water column</h1><div class="sub">Two- and three-layer screening model · seabed diffusers · plume-driven cohort lift</div></div><div class="badge">ILLUSTRATIVE MODEL · NOT FIELD VALIDATION</div></header><div class="layout"><section class="card"><div class="canvaswrap"><canvas id="plot"></canvas></div><div class="controls"><select id="run"></select><button id="play">Play</button><span id="clock" class="muted">0 min</span><input id="time" type="range" min="0" max="0" value="0" style="grid-column:1/-1"></div><div class="key"><span><i class="dot" style="background:var(--blue)"></i>Free cohort</span><span><i class="dot" style="background:var(--amber)"></i>Intercepted / guided</span><span><i class="dot" style="background:var(--teal)"></i>Green = in modeled upflow or previously plume-lifted</span><span>Seabed diffuser line(s) · arrows show modeled upward water flow</span><span>Bubble state: <strong id="bubble-state">—</strong></span></div><div class="metrics"><div class="metric"><b id="lift">—</b><span>mass with plume-attributed lift (paired model metric)</span></div><div class="metric"><b id="escape">—</b><span>passed beyond second layer</span></div><div class="metric"><b id="energy">—</b><span>bubble energy (fixed compressor assumption)</span></div><div class="metric"><b id="depth">—</b><span>water depth / boom skirt</span></div></div></section><aside class="card side"><h2>What moves the jellyfish upward?</h2><p id="mode-note">Diffusers are at the seabed. They entrain water upward only where a cohort path overlaps the modeled plume. A bubble curtain is not a solid barrier.</p><div class="equation">Q<sub>liquid</sub> = λ B h / v<sub>s</sub><sup>2</sup><br>r<sub>plume</sub> = k √(B h / v<sub>s</sub><sup>3</sup>)<br>w(r) = w<sub>center</sub> exp(−r² / 2r<sub>liquid</sub>²)</div><ul><li>Depth is positive downward; bubbles lift cohorts by entraining water upward.</li><li>Each boom covers the surface to its skirt depth. A deep cohort can pass underneath.</li><li>Ambient current shifts the rising plume sideways.</li><li>Particle marks are weighted cohorts, not individual jellyfish.</li></ul><p class="note"><b>Read the percentages carefully.</b> Gas flow, plume spread, water depth, animal depth, capture efficiency and compressor power are placeholders. Bubble-attributed lift means the cohort crossed above the outer skirt in the plume run while its paired no-bubble trajectory remained below; it is not confirmed capture.</p><p class="note">The wall is modeled as another upwelling plume only. No perfect interception, lateral redirection, or jellyfish avoidance is assumed. Plume fields are superposed without resolving how adjacent plumes interact. Actual performance needs flume data.</p></aside></div><footer id="footer">Loading simulation results…</footer></main><script>
const $=s=>document.querySelector(s),canvas=$('#plot'),ctx=canvas.getContext('2d'),select=$('#run'),slider=$('#time');let data,current,playing=false,timer;
const colors=['#ffbd64','#ff786b','#c78cff'],bubbleColors=['#4de0c0','#65b7ff','#f4d35e'];
function size(){const r=canvas.getBoundingClientRect(),d=window.devicePixelRatio||1;canvas.width=Math.max(1,Math.round(r.width*d));canvas.height=Math.max(1,Math.round(r.height*d));ctx.setTransform(d,0,0,d,0,0);draw()}window.addEventListener('resize',size);
function diffusers(c){return c.bubble.diffusers||[{name:'Seabed airlift',role:'airlift',diffuser_start_xy_m:c.bubble.diffuser_start_xy_m,diffuser_end_xy_m:c.bubble.diffuser_end_xy_m,diffuser_bottom_clearance_m:c.bubble.diffuser_bottom_clearance_m}]}
function options(){data.runs.forEach((run,i)=>{let o=document.createElement('option');o.value=i;o.textContent=run.variant_label||run.variant;select.append(o)});select.onchange=()=>loadRun(+select.value);const i=data.runs.findIndex(r=>r.variant==='two_airlift_plus_wall');select.value=String(i>=0?i:0);loadRun(+select.value)}
function loadRun(i){current=data.runs[i];const f=current.frames||[];slider.max=Math.max(0,f.length-1);slider.value=String(Math.min(30,Math.max(0,f.length-1)));slider.oninput=draw;draw();const s=current.summary,c=current.config||data.config,n=c.bands.length;$('#lift').textContent=(s.bubble_lifted_percent||0).toFixed(1)+'%';$('#escape').textContent=(s.residual_percent||0).toFixed(1)+'%';$('#energy').textContent=(s.bubble_kwh||0).toFixed(1)+' kWh';$('#depth').textContent=c.geometry.water_depth_m+' m / '+c.bands.map(b=>b.skirt_depth_m+' m').join(', ');document.querySelector('#escape').nextElementSibling.textContent='passed beyond final '+n+'-layer band';document.querySelector('#depth').nextElementSibling.textContent='water depth / modeled skirt depth(s)';$('#mode-note').textContent='All bubble cases force the diffuser(s) on to isolate their modeled flow effect. Bubble curtains create moving water, not a sealed wall. No ML/CV or behavior-based avoidance is represented.';$('#footer').textContent=(current.window?.label||data.forcing.window?.label||'')+' · '+(current.variant_label||current.variant)+' · Conditional outputs, not field effectiveness.'}
function draw(){if(!current)return;const W=canvas.clientWidth,H=canvas.clientHeight;ctx.clearRect(0,0,W,H);const pad={l:55,r:20,t:26,b:38},pw=W-pad.l-pad.r,ph=H-pad.t-pad.b,c=current.config||data.config,depth=c.geometry.water_depth_m,maxX=c.geometry.length_m,X=x=>pad.l+x/maxX*pw,Z=z=>pad.t+z/depth*ph;ctx.fillStyle='#0b2b3c';ctx.fillRect(pad.l,pad.t,pw,ph);ctx.strokeStyle='#33556a';ctx.lineWidth=1;for(let x=0;x<=maxX;x+=60){ctx.beginPath();ctx.moveTo(X(x),pad.t);ctx.lineTo(X(x),pad.t+ph);ctx.stroke();ctx.fillStyle='#9cb3c2';ctx.fillText(x+' m',X(x)-14,H-12)}for(let z=0;z<=depth;z+=Math.max(2,Math.ceil(depth/6))){ctx.beginPath();ctx.moveTo(pad.l,Z(z));ctx.lineTo(pad.l+pw,Z(z));ctx.stroke();ctx.fillText(z+' m',7,Z(z)+4)}ctx.fillStyle='#b9e4e8';ctx.fillText('SEA SURFACE',pad.l+8,pad.t-9);ctx.fillStyle='#826e53';ctx.fillRect(pad.l,Z(depth),pw,pad.t+ph-Z(depth));
function band(b,i){const x=(b.start[0]+b.end[0])/2;ctx.strokeStyle=colors[i%colors.length];ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(X(x),Z(0));ctx.lineTo(X(x),Z(b.skirt_depth_m));ctx.stroke();ctx.setLineDash([4,4]);ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(X(x)-12,Z(b.skirt_depth_m));ctx.lineTo(X(x)+12,Z(b.skirt_depth_m));ctx.stroke();ctx.setLineDash([]);ctx.fillStyle=colors[i%colors.length];ctx.fillText((i+1)+' · '+b.name.toUpperCase(),X(x)-28,Z(0)+18)}c.bands.forEach(band);
const frame=(current.frames||[])[+slider.value],bubbleOn=!!frame?.bubble_active;$('#bubble-state').textContent=bubbleOn?'ON':'OFF';if(frame)$('#clock').textContent=frame.minute.toFixed(0)+' min';
for(const [i,d] of diffusers(c).entries()){const p0=d.diffuser_start_xy_m,p1=d.diffuser_end_xy_m,clear=d.diffuser_bottom_clearance_m??c.bubble.diffuser_bottom_clearance_m,bz=depth-clear,frac=Math.max(0,Math.min(1,(c.geometry.width_m/2-p0[1])/(p1[1]-p0[1]))),bx=p0[0]+(p1[0]-p0[0])*frac,col=bubbleColors[i%bubbleColors.length];ctx.strokeStyle=bubbleOn?col:'#8194a0';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(X(bx)-6,Z(bz));ctx.lineTo(X(bx)+6,Z(bz));ctx.stroke();ctx.fillStyle=bubbleOn?col:'#aab8bf';ctx.fillText(d.role==='curtain'?'WALL':'AIRLIFT',X(bx)-24,Z(bz)-8-i*16);if(bubbleOn){ctx.fillStyle=col+'22';ctx.fillRect(X(bx)-Math.max(4,pw*.004),pad.t,Math.max(8,pw*.008),Z(bz)-pad.t);ctx.strokeStyle=col;ctx.setLineDash([4,5]);ctx.beginPath();ctx.moveTo(X(bx),Z(bz));ctx.lineTo(X(bx),Z(0));ctx.stroke();ctx.setLineDash([]);ctx.lineWidth=2;for(let j=0;j<3;j++){const ay=Z(bz*(.78-j*.25)),ax=X(bx);ctx.beginPath();ctx.moveTo(ax,ay+7);ctx.lineTo(ax,ay-7);ctx.moveTo(ax,ay-7);ctx.lineTo(ax-4,ay-2);ctx.moveTo(ax,ay-7);ctx.lineTo(ax+4,ay-2);ctx.stroke()}for(let j=0;j<6;j++){const phase=(frame?.minute||0)*.12+j*1.7,xx=X(bx)+Math.sin(phase)*Math.max(3,pw*.009),yy=Z(bz)*(1-((j/6+(frame?.minute||0)/10)%1));ctx.beginPath();ctx.arc(xx,yy,2,0,2*Math.PI);ctx.fill()}ctx.fillStyle=col}}
if(frame){for(const p of frame.particles){const x=X(p[1]),z=Z(p[3]),guided=p[4]>=0,lifted=p[6],inUpflow=p[7]>0.001;ctx.fillStyle=guided?'#ffbd64':(lifted||inUpflow)?'#4de0c0':'#65b7ff';ctx.globalAlpha=.82;ctx.beginPath();ctx.arc(x,z,Math.max(2.3,Math.min(5,2+p[5]*.06)),0,2*Math.PI);ctx.fill()}ctx.globalAlpha=1}ctx.fillStyle='#9cb3c2';ctx.fillText('INTAKEWARD →',W-105,pad.t+18)}
$('#play').onclick=()=>{playing=!playing;$('#play').textContent=playing?'Pause':'Play';if(playing){timer=setInterval(()=>{let n=+slider.value+1;if(n>+slider.max){playing=false;$('#play').textContent='Play';clearInterval(timer);return}slider.value=n;draw()},70)}else clearInterval(timer)};
fetch('./results.json').then(r=>{if(!r.ok)throw new Error('Open this report through the MARLIN local web server so it can load results.json.');return r.json()}).then(d=>{data=d;options();size()}).catch(e=>{$('#footer').textContent=e.message});
</script></body></html>"""
if __name__=='__main__': main()
