"""Illustrative particle/operations model. Never controls physical equipment.

Particles are weighted cohorts, not individual jellyfish. Flow and contact are
prescribed scenarios; no CFD, survival, trained perception or vessel navigation.
"""
from collections import deque
from dataclasses import dataclass, field
import copy
import math
import random

DISCLAIMER='Depth-aware two-layer scenario model with a reduced-order, uncalibrated bubble-plume closure. Regional surface forcing, local flow, diffuser inputs, jellyfish behavior, interception, collection and operations remain assumptions. Not for equipment control or field-performance claims.'
SCENARIOS=[
 ('reference','Reference arrivals'),('overload','Sustained overload'),('surge','Short surge'),
 ('outer_outage','Outer collector outage'),('boat_outage','Both vessels unavailable'),
 ('release_closed','Release unavailable'),('sensor_bias','Reserve sensors undercount'),
 ('sensor_blind','Reserve sensors blind'),('false_alarms','False reserve alarms'),('outer_false_alarm','False outer detector alert'),
 ('network_loss','Lost inter-band messages'),('reversal','Prescribed current reversal'),
 ('storm','Common rough-water degradation'),('bypass','Extra depth / side bypass'),
 ('debris','Debris slows collectors'),('animal_pause','Uncertain-animal handling pause'),
 ('guide_escape','Escape while being guided'),('high_return','High assumed return'),
 ('compound','Collector, transport and network failures'),('deep_bloom','Deep-distributed bloom sensitivity'),('depth_sweep','Water-depth sensitivity'),('vertical_mix_sweep','Vertical-mixing sensitivity')
]
VARIANTS=[
 {'id':'three_off','label':'Three bands · bubbles off','bands':3,'bubble':'off','coordination':True},
 {'id':'outer_off','label':'Outer only · bubbles off','bands':1,'bubble':'off','coordination':True},
 {'id':'three_local','label':'Three bands · local controls','bands':3,'bubble':'off','coordination':False},
 {'id':'three_assist','label':'Three bands · assumed bubble assist','bands':3,'bubble':'positive','coordination':True},
 {'id':'three_zero','label':'Three bands · zero bubble benefit','bands':3,'bubble':'zero','coordination':True},
 {'id':'three_adverse','label':'Three bands · adverse bubble effect','bands':3,'bubble':'adverse','coordination':True},
 {'id':'three_optical','label':'Three bands · bubbles obscure outer sensor','bands':3,'bubble':'positive_optical','coordination':True},
 {'id':'two_off','label':'Two layers · bubble off','bands':2,'bubble':'off','coordination':True,'bubble_activation':'off'},
 {'id':'two_always_positive','label':'Two layers · bubble on whenever conditions allow','bands':2,'bubble':'positive','coordination':True,'bubble_activation':'always'},
 {'id':'two_trigger_positive','label':'Two layers · detected-bloom bubble, assumed benefit','bands':2,'bubble':'positive','coordination':True,'bubble_activation':'detected'},
 {'id':'two_trigger_zero','label':'Two layers · detected-bloom bubble, zero assumed benefit','bands':2,'bubble':'zero','coordination':True,'bubble_activation':'detected'},
 {'id':'two_trigger_adverse','label':'Two layers · detected-bloom bubble, adverse stress case','bands':2,'bubble':'adverse','coordination':True,'bubble_activation':'detected'},
 {'id':'two_trigger_optical','label':'Two layers · detected-bloom bubble, optical interference stress case','bands':2,'bubble':'positive_optical','coordination':True,'bubble_activation':'detected'},
 {'id':'two_trigger_plume_low','label':'Two layers · triggered physical-plume model, low gas-flow case','bands':2,'bubble':'plume','coordination':True,'bubble_activation':'detected','plume_scale':0.5},
 {'id':'two_trigger_plume_nominal','label':'Two layers · triggered physical-plume model, nominal gas-flow case','bands':2,'bubble':'plume','coordination':True,'bubble_activation':'detected','plume_scale':1.0},
 {'id':'two_trigger_plume_high','label':'Two layers · triggered physical-plume model, high gas-flow case','bands':2,'bubble':'plume','coordination':True,'bubble_activation':'detected','plume_scale':2.0},
 {'id':'two_airlift_physics_test','label':'Two layers · seabed airlift only, forced ON','bands':2,'bubble':'plume','coordination':True,'bubble_activation':'manual_on','plume_scale':1.0},
 {'id':'two_bubble_wall_only','label':'Two layers · near-outer bubble wall only','bands':2,'bubble':'plume','coordination':True,'bubble_activation':'manual_on','plume_scale':1.0},
 {'id':'two_airlift_plus_wall','label':'Two layers · seabed airlift + near-outer bubble wall','bands':2,'bubble':'plume','coordination':True,'bubble_activation':'manual_on','plume_scale':1.0},
 {'id':'three_airlift_plus_wall','label':'Three layers · seabed airlift + near-outer bubble wall','bands':3,'bubble':'plume','coordination':True,'bubble_activation':'manual_on','plume_scale':1.0}
]

def uniform(seed,*keys):
    """Counter-based draws: variants share source and individual encounter draws."""
    mask=(1<<64)-1
    value=seed & mask
    for key in keys:
        value=(value+int(key)+0x9e3779b97f4a7c15)&mask
        value=((value^(value>>30))*0xbf58476d1ce4e5b9)&mask
        value=((value^(value>>27))*0x94d049bb133111eb)&mask
        value^=value>>31
    return (value>>11)/float(1<<53)

@dataclass
class Lot:
    kg: float
    captured: float
    origin: int
    generation: int

class Inventory:
    def __init__(self): self.lots=deque();self.kg=0.0
    def add(self,lot):
        if lot.kg>1e-10:
            reorder=bool(self.lots and self.lots[-1].captured>lot.captured)
            self.lots.append(lot);self.kg+=lot.kg
            if reorder: self.lots=deque(sorted(self.lots,key=lambda item:item.captured))
    def take(self,kg):
        wanted=min(max(kg,0),self.kg);result=[]
        while wanted>1e-9 and self.lots:
            lot=self.lots[0];amount=min(wanted,lot.kg)
            result.append(Lot(amount,lot.captured,lot.origin,lot.generation))
            wanted-=amount;lot.kg-=amount;self.kg-=amount
            if lot.kg<1e-9: self.lots.popleft()
        if not self.lots: self.kg=0.0
        return result
    def age(self,t): return max(0,t-min(l.captured for l in self.lots)) if self.lots else 0

@dataclass
class Particle:
    id: int
    origin: int
    kg: float
    x: float
    y: float
    z: float  # depth below the sea surface; metres, positive downward
    z_no_bubble: float  # paired counterfactual depth using identical diffusion
    generation: int=0
    state: str='free'
    band: int=-1
    captured: float=0
    probes: set=field(default_factory=set)
    passed: set=field(default_factory=set)
    encounters: dict=field(default_factory=dict)
    lifted_by_bubble: bool=False

def intersect(x,y,nx,ny,start,end):
    rx,ry=nx-x,ny-y; sx,sy=end[0]-start[0],end[1]-start[1]
    determinant=rx*sy-ry*sx
    if determinant<=1e-12: return None  # Inward crossings only.
    ax,ay=start[0]-x,start[1]-y
    t=(ax*sy-ay*sx)/determinant;u=(ax*ry-ay*rx)/determinant
    return (t,u) if -1e-9<=t<=1+1e-9 and -1e-9<=u<=1+1e-9 else None

class Simulation:
    def __init__(self,cfg,forcing,scenario,variant,seed,detail=False):
        self.cfg=copy.deepcopy(cfg);self.forcing=forcing;self.scenario=scenario
        self.variant=next(v for v in VARIANTS if v['id']==variant)
        self.seed=seed;self.detail=detail;self.particles=[];self.next_id=0;self.next_external_origin=0;self._conditions_cache={}
        self.external=self.residual=self.left_domain=self.released=self.gross_release=self.returned=0.0
        self.pending_returns=[];self.spawn_credit=0.0;self.max_error=0.0
        self.gaps={};self.events=[];self.series=[];self.frames=[];self.trips=[];self.lifecycle=[]
        self.bubble_kwh=self.boat_kwh=self.band_kwh=0.0
        self.bubble_lifted_kg=0.0
        self.bubble_upward_displacement_kg_m=0.0
        self.bubble_command=False;self.bubble_ready=None;self.bubble_idle=0.0;self.bubble_persistence=0.0;self.bubble_active_minutes=0.0
        self.peak_held_age=0.0;self.t=0.0
        self.bands=[]
        for i,b in enumerate(cfg['bands']):
            self.bands.append({'cfg':b,'net':Inventory(),'receiver':Inventory(),'guided_kg':0.0,'active':i==0,'ready':None,'idle':0.0,'persistence':0.0,'true_events':deque(),'observed_events':deque(),'delivery':deque(),'pass_events':deque(),'arrived_kg':0.0,'intercepted_kg':0.0,'collected_kg':0.0,'passed_kg':0.0,'transferred_kg':0.0,'observed_total_kg':0.0,'peak_capture_load_kg':0.0,'peak_receiver_kg':0.0,'max_age_minutes':0.0,'true_flux':0.0,'observed_flux':0.0,'active_minutes':0.0,'state':'active' if i==0 else 'standby'})
        self.boats=[{'id':i,'state':'idle','remaining':0.0,'band':None,'cargo':Inventory(),'trip':None} for i in range(cfg['vessel']['count'])]
        self.validate()

    def validate(self):
        c=self.cfg
        if c['step_seconds']<=0 or c['step_seconds']>60: raise ValueError('Step must be >0 and <=60 seconds')
        if c['observation_hours']<c['arrival_hours'] or c['arrival_hours']<=0: raise ValueError('Invalid observation/arrival horizon')
        if c['cohort_kg']<=0 or c['external_rate_kg_h']<0 or c['assumed_individual_mass_kg']<=0: raise ValueError('Invalid mass inputs')
        if c['vessel']['count']<1 or c['vessel']['payload_kg']<=0: raise ValueError('Invalid vessel resources')
        if not 0<=c['return_fraction']<=1: raise ValueError('Invalid fraction')
        g=c['geometry'];bub=c['bubble']
        if not 0<g['water_depth_m'] or not 0<=bub['diffuser_bottom_clearance_m']<g['water_depth_m']: raise ValueError('Invalid water depth or seabed diffuser clearance')
        if min(bub['gas_flow_per_metre_m3_s_m'],bub['diffuser_spacing_m'],bub['bubble_slip_speed_m_s'],bub['plume_radius_coefficient'],bub['liquid_plume_width_ratio'],bub['maximum_water_upwelling_m_s'])<=0: raise ValueError('Invalid bubble-plume input')
        if len(c['bands']) not in (2,3): raise ValueError('Two or three band definitions required')
        for b in c['bands']:
            if not 0<=b['intercept_probability']<=1: raise ValueError('Invalid interception assumption')
            if not 0<b['skirt_depth_m']<=c['geometry']['water_depth_m']: raise ValueError('Invalid boom skirt depth')
            if min(b['capture_load_limit_kg'],b['receiver_capacity_kg'])<c['cohort_kg']: raise ValueError('Capacities must accommodate one cohort')
            if b['collector_rate_kg_h']<0: raise ValueError('Negative collection rate')
            if math.dist(b['start'],b['end'])<=0: raise ValueError('Empty guide')
        def numeric(value):
            if isinstance(value,dict): return all(numeric(v) for v in value.values())
            if isinstance(value,list): return all(numeric(v) for v in value)
            return not isinstance(value,(float,int)) or math.isfinite(value)
        if not numeric(c): raise ValueError('Nonfinite input')

    def flag(self,code,band,meaning,value=0,unit='',response='Review the design and obtain missing measurements.'):
        key=f'{code}:{band}'
        if key not in self.gaps:
            self.gaps[key]={'code':code,'band':band,'first_minute':round(self.t,2),'last_minute':round(self.t,2),'meaning':meaning,'peak_value':value,'unit':unit,'response':response,'status':'SIMULATED_FINDING_NOT_FIELD_CONFIRMATION'}
            self.events.append({'minute':round(self.t,2),'band':band,'code':code,'message':meaning})
        else:
            self.gaps[key]['last_minute']=round(self.t,2)
            self.gaps[key]['peak_value']=max(self.gaps[key]['peak_value'],value)

    def conditions(self,t):
        if t in self._conditions_cache: return self._conditions_cache[t]
        e=self.forcing.at(t);s=self.scenario
        if s=='storm' and 60<=t<180:
            e['wave_height']=max(2.0,e['wave_height']);e['wind_speed_10m']=max(14,e['wind_speed_10m'])
        self._conditions_cache[t]=e
        return e

    def bubble_on(self,t):
        if self.variant['bubble']=='off': return False
        mode=self.variant.get('bubble_activation','always')
        if mode=='manual_on': return self.variant['bubble']=='plume'
        if mode=='detected' and not self.bubble_command: return False
        e=self.conditions(t);b=self.cfg['bubble']
        return e['wave_height']<=b['illustrative_wave_enable_max_m'] and math.hypot(e['current_u_east_m_s'],e['current_v_north_m_s'])<=b['illustrative_current_enable_max_m_s']

    def velocity(self,x,y,t):
        """Prescribed horizontal ambient flow; it is not a resolved site field."""
        e=self.conditions(t);g=self.cfg['geometry'];angle=math.radians(g['regional_projection_heading_deg_from_east'])
        east,north=e['current_u_east_m_s'],e['current_v_north_m_s']
        u=g['assumed_intakeward_component_m_s']+g['regional_current_scale']*(east*math.cos(angle)+north*math.sin(angle))
        v=g['regional_current_scale']*(-east*math.sin(angle)+north*math.cos(angle))*g.get('assumed_transverse_current_scale',0.15)
        if self.scenario=='reversal' and 60<=t<120: u=-max(abs(u),0.08)
        return u,v

    def _plume_specs(self):
        """Return configured seabed diffuser lines; old single-line configs remain valid."""
        return self.cfg["bubble"].get("diffusers") or [self.cfg["bubble"]]

    def _plume_state(self, depth, t, spec):
        """Reduced-order plume state for one seabed diffuser line."""
        bubble=self.cfg["bubble"]
        source_depth=self.cfg["geometry"]["water_depth_m"]-spec.get(
            "diffuser_bottom_clearance_m", bubble["diffuser_bottom_clearance_m"])
        height=source_depth-depth
        if height<=0:
            return None
        scale=self.variant.get("plume_scale",1.0)
        spacing=spec.get("diffuser_spacing_m",bubble["diffuser_spacing_m"])
        flow_per_m=spec.get("gas_flow_per_metre_m3_s_m",bubble["gas_flow_per_metre_m3_s_m"])
        qg=flow_per_m*spacing*scale
        g0=9.80665;vs=bubble["bubble_slip_speed_m_s"];lam=bubble["slip_flux_coefficient"]
        buoyancy_flux=g0*qg
        transition=32*(lam**1.5)*buoyancy_flux/(vs**3)
        if height>transition:
            liquid_flux=lam*buoyancy_flux*height/(vs**2)
            bubble_radius=bubble["plume_radius_coefficient"]*math.sqrt(buoyancy_flux*height/(vs**3))
        else:
            liquid_flux=bubble["classical_volume_flux_coefficient"]*(buoyancy_flux**(1/3))*max(height,1e-4)**(5/3)
            bubble_radius=max(bubble["source_radius_m"],bubble["classical_entrainment_coefficient"]*height)
        liquid_radius=max(bubble["source_radius_m"],bubble_radius*bubble["liquid_plume_width_ratio"])
        centerline=min(liquid_flux/(2*math.pi*liquid_radius**2),bubble["maximum_water_upwelling_m_s"])
        line0=spec["diffuser_start_xy_m"];line1=spec["diffuser_end_xy_m"]
        length=math.dist(line0,line1);count=max(1,math.ceil(length/spacing));pitch=length/count
        u,v=self.velocity((line0[0]+line1[0])/2,(line0[1]+line1[1])/2,t)
        rise_time=height/max(vs+centerline,0.05)
        shift_cap=bubble["maximum_crossflow_offset_m"]
        shift_x=max(-shift_cap,min(shift_cap,u*rise_time))
        shift_y=max(-shift_cap,min(shift_cap,v*rise_time))
        return {"spec":spec,"line0":(line0[0]+shift_x,line0[1]+shift_y),
                "line1":(line1[0]+shift_x,line1[1]+shift_y),"length":length,
                "count":count,"pitch":pitch,"radius":liquid_radius,"centerline":centerline}

    def _plume_states(self, depth, t):
        """Superpose active line diffusers; no behavioral avoidance is presumed."""
        if not self.bubble_on(t) or self.variant["bubble"]!="plume":
            return []
        return [state for spec in self._plume_specs()
                if (state:=self._plume_state(depth,t,spec)) is not None]

    @staticmethod
    def _point_segment_distance(px,py,ax,ay,bx,by):
        dx=bx-ax;dy=by-ay;den=dx*dx+dy*dy
        f=0.0 if den<=1e-15 else max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/den))
        return math.hypot(px-(ax+f*dx),py-(ay+f*dy))

    def _state_upwelling(self,x,y,state):
        a=state["line0"];b=state["line1"];dx=b[0]-a[0];dy=b[1]-a[1]
        length2=state["length"]**2
        f=((x-a[0])*dx+(y-a[1])*dy)/length2
        count=state["count"];pitch=state["pitch"];radius=state["radius"]
        center=max(0,min(count,round(f*count)));extent=math.ceil(4*radius/pitch)+1
        total=0.0
        for j in range(max(0,center-extent),min(count,center+extent)+1):
            q=j/count;cx=a[0]+q*dx;cy=a[1]+q*dy
            radial2=(x-cx)**2+(y-cy)**2
            end_weight=0.5 if j in (0,count) else 1.0
            total+=end_weight*state["centerline"]*math.exp(-0.5*radial2/(radius**2))
        return total

    def bubble_upwelling(self,x,y,depth,t):
        """Vertical water speed from the superposed modeled line-plume fields."""
        return min(sum(self._state_upwelling(x,y,state) for state in self._plume_states(depth,t)),
                   self.cfg["bubble"]["maximum_water_upwelling_m_s"])

    def _state_path_average(self,x0,y0,x1,y1,state):
        vx=x1-x0;vy=y1-y0;path_length=math.hypot(vx,vy)
        if path_length<1e-9:
            return self._state_upwelling(x0,y0,state)
        a=state["line0"];b=state["line1"];lx=b[0]-a[0];ly=b[1]-a[1]
        segment_gap=min(self._point_segment_distance(x0,y0,a[0],a[1],b[0],b[1]),
                        self._point_segment_distance(x1,y1,a[0],a[1],b[0],b[1]),
                        self._point_segment_distance(a[0],a[1],x0,y0,x1,y1),
                        self._point_segment_distance(b[0],b[1],x0,y0,x1,y1))
        den=vx*ly-vy*lx
        if abs(den)>1e-12:
            qx=a[0]-x0;qy=a[1]-y0
            along_path=(qx*ly-qy*lx)/den
            along_diffuser=(qx*vy-qy*vx)/den
            if 0.0<=along_path<=1.0 and 0.0<=along_diffuser<=1.0:
                segment_gap=0.0
        if segment_gap>5*state["radius"]:
            return 0.0
        count=state["count"];pitch=state["pitch"];length2=state["length"]**2
        f0=((x0-a[0])*lx+(y0-a[1])*ly)/length2
        f1=((x1-a[0])*lx+(y1-a[1])*ly)/length2
        margin=5*state["radius"]/state["length"]
        lo=max(0,math.floor((min(f0,f1)-margin)*count)-1)
        hi=min(count,math.ceil((max(f0,f1)+margin)*count)+1)
        radius=state["radius"];root2r=math.sqrt(2)*radius
        path2=path_length*path_length;total=0.0
        for j in range(lo,hi+1):
            q=j/count;cx=a[0]+q*lx;cy=a[1]+q*ly
            along=((cx-x0)*vx+(cy-y0)*vy)/path2
            px=x0+along*vx;py=y0+along*vy;perp2=(cx-px)**2+(cy-py)**2
            arg1=(1-along)*path_length/root2r;arg0=-along*path_length/root2r
            path_integral=math.sqrt(math.pi/2)*radius/path_length*(math.erf(arg1)-math.erf(arg0))
            end_weight=0.5 if j in (0,count) else 1.0
            total+=end_weight*state["centerline"]*math.exp(-0.5*perp2/(radius**2))*path_integral
        return max(0.0,total)

    def bubble_path_average(self,x0,y0,x1,y1,depth,t):
        """Integrate exposure to each narrow diffuser plume along a cohort step."""
        total=sum(self._state_path_average(x0,y0,x1,y1,state)
                  for state in self._plume_states(depth,t))
        return min(total,self.cfg["bubble"]["maximum_water_upwelling_m_s"])

    def bubble_gas_flow_m3_h(self):
        if self.bubble_active_minutes<=0 or self.variant["bubble"]!="plume":
            return 0.0
        scale=self.variant.get("plume_scale",1.0)
        return sum(3600*spec.get("gas_flow_per_metre_m3_s_m",self.cfg["bubble"]["gas_flow_per_metre_m3_s_m"])
                   *math.dist(spec["diffuser_start_xy_m"],spec["diffuser_end_xy_m"])*scale
                   for spec in self._plume_specs())

    def reflect_depth(self,depth):
        """Reflect vertical steps at the surface and seabed."""
        lower=0.05;upper=self.cfg['geometry']['water_depth_m']-0.05;span=upper-lower
        phase=(depth-lower)%(2*span)
        return lower+(phase if phase<=span else 2*span-phase)

    def vertical_rate(self,x,y,depth,t):
        """Depth-positive-down velocity of a cohort in metres per second."""
        return -self.bubble_upwelling(x,y,depth,t)+self.cfg['biology'].get('assumed_downward_swimming_m_s',0.0)

    def collector_rate(self,i):
        rate=self.bands[i]['cfg']['collector_rate_kg_h'];s=self.scenario;t=self.t
        if i==0 and ((s=='outer_outage' and 60<=t<180) or (s=='compound' and 60<=t<240) or (s=='animal_pause' and 30<=t<90)): return 0
        if s=='debris' and 60<=t<240: rate*=0.35
        return rate

    def network_ok(self): return not ((self.scenario=='network_loss' and 90<=self.t<210) or (self.scenario=='compound' and 60<=self.t<240))
    def sensor_blind(self,i): return i>0 and self.scenario=='sensor_blind' and 60<=self.t<180
    def vessel_ok(self): return not ((self.scenario=='boat_outage' and 60<=self.t<240) or (self.scenario=='compound' and 60<=self.t<240))
    def release_open(self): return not ((self.scenario=='release_closed' and 60<=self.t<300) or (self.scenario=='compound' and 60<=self.t<300))
    def weather_ok(self):
        e=self.conditions(self.t);v=self.cfg['vessel']
        return e['wave_height']<=v['illustrative_wave_limit_m'] and e['wind_speed_10m']<=v['illustrative_wind_limit_m_s']

    def record_observation(self,p,i,kind):
        b=self.bands[i];sensor=self.cfg['sensor'];target=b['true_events'] if kind==0 else None
        if target is not None: target.append((self.t,p.kg));b['arrived_kg']+=p.kg
        if i>=self.variant['bands'] or self.sensor_blind(i): return
        probability=sensor['detect_probability'];bias=1.0
        if self.scenario=='sensor_bias' and i>0: bias=0.1
        if i==0 and self.variant['bubble']=='positive_optical' and self.bubble_on(self.t):
            probability*=0.3
            self.flag('bubble_visibility','outer','Assumed bubble plume reduces optical observations; this is not a measured detector result.',response='Measure visibility and evaluate sensing independently of bubble activation.')
        if uniform(self.seed,p.origin,p.generation,i,kind,91)<probability:
            amount=p.kg*bias
            b['delivery'].append((self.t+sensor['latency_minutes'],amount,kind))
            if kind==0: b['observed_total_kg']+=amount

    def update_controls(self,dt):
        cfg=self.cfg;window=cfg['sensor']['rolling_window_minutes'];network=self.network_ok()
        if not network: self.flag('network_unavailable','all','Inter-band messages unavailable; local controls remain.',response='Verify local fallback and physical communications recovery.')
        for i,b in enumerate(self.bands):
            while b['delivery'] and b['delivery'][0][0]<=self.t:
                due,mass,kind=b['delivery'].popleft()
                (b['observed_events'] if kind==0 else b['pass_events']).append((due,mass))
            for key in ('true_events','observed_events','pass_events'):
                while b[key] and b[key][0][0]<self.t-window: b[key].popleft()
            b['true_flux']=sum(m for _,m in b['true_events'])*60/window
            blind=self.sensor_blind(i)
            b['observed_flux']=None if blind or i>=self.variant['bands'] else sum(m for _,m in b['observed_events'])*60/window+cfg['sensor']['false_alarm_rate_kg_h']
            if self.scenario=='false_alarms' and i>0 and 20<=self.t<100 and not blind and b['observed_flux'] is not None: b['observed_flux']+=150
            if self.scenario=='outer_false_alarm' and i==0 and 20<=self.t<100 and b['observed_flux'] is not None: b['observed_flux']+=150
            if i>=self.variant['bands']: b['active']=False;b['state']='disabled';continue
            if self.t>window+cfg['sensor']['latency_minutes'] and b['true_flux']>max(100,b['cfg']['activate_flux_kg_h']) and b['observed_flux'] is not None and b['observed_flux']<0.5*b['true_flux']:
                self.flag('observation_shortfall',b['cfg']['name'],'Offline truth audit shows observed flux below half of true probe flux. The controller cannot access this truth audit.',b['true_flux']-b['observed_flux'],'kg/hour','Separate latency/noise from systematic errors and calibrate with representative dense-load footage.')
            if blind: self.flag('missing_observation',b['cfg']['name'],'Missing sensor observation triggers local reserve readiness, not zero flux.',response='Evaluate sensor diversity and missing-data behavior with real sensors.')
            upstream=False
            if i>0 and network and self.variant['coordination']:
                previous=self.bands[i-1]
                upstream=self.collector_rate(i-1)==0 or sum(m for _,m in previous['pass_events'])*60/window>=b['cfg']['activate_flux_kg_h']
            request=i==0 or blind or upstream or b['observed_flux']>=b['cfg']['activate_flux_kg_h']
            b['persistence']=b['persistence']+dt if request else 0
            if request and (blind or upstream or b['persistence']>=cfg['sensor']['persistence_minutes']) and not b['active'] and b['ready'] is None:
                b['ready']=self.t+b['cfg']['activation_delay_minutes']
                self.events.append({'minute':round(self.t,2),'band':b['cfg']['name'],'code':'activation_requested','message':'Local observation or received upstream health/passage signal requests activation.'})
            if b['ready'] is not None and self.t>=b['ready']: b['active']=True;b['ready']=None
            load=b['net'].kg+b['guided_kg']
            b['idle']=b['idle']+dt if not request and load<1e-9 else 0
            if i>0 and b['idle']>=cfg['sensor']['idle_off_minutes']: b['active']=False;b['idle']=0
            b['state']='degraded' if b['active'] and self.collector_rate(i)==0 else 'active' if b['active'] else 'arming' if b['ready'] is not None else 'standby'
            if b['active']: b['active_minutes']+=dt
            self.band_kwh+=cfg['sensor']['power_kw_per_band']*dt/60
            if b['active'] and load>1e-9: self.band_kwh+=b['cfg']['collector_power_kw']*dt/60
            if b['active'] and self.collector_rate(i)==0: self.flag('collector_unavailable',b['cfg']['name'],'Collector stopped while guide/receiver may still retain biomass.',load,'kg','Assess degraded collection capacity and recovery; do not assume clearing one band is safe.')

        self.update_bubble_control(dt)

    def update_bubble_control(self,dt):
        if self.variant.get('bubble_activation','always')!='detected' or self.variant['bubble']=='off': return
        spec=self.cfg['bubble'];outer=self.bands[0]
        flux=outer['observed_flux']
        request=flux is not None and flux>=spec.get('activate_flux_kg_h',150)
        if request:
            self.bubble_idle=0.0;self.bubble_persistence+=dt
            if not self.bubble_command and self.bubble_ready is None and self.bubble_persistence>=spec.get('activate_persistence_minutes',1):
                self.bubble_ready=self.t+spec.get('activation_delay_minutes',1)
                self.events.append({'minute':round(self.t,2),'band':'outer','code':'bubble_activation_requested','message':'Upstream outer sensor flux crossed the illustrative trigger threshold.'})
        else:
            self.bubble_persistence=0.0;self.bubble_idle+=dt
            if self.bubble_ready is not None:
                self.events.append({'minute':round(self.t,2),'band':'outer','code':'bubble_activation_cancelled','message':'Outer sensor trigger cleared before the illustrative start delay elapsed.'})
                self.bubble_ready=None
        if self.bubble_ready is not None and self.t>=self.bubble_ready:
            self.bubble_command=True;self.bubble_ready=None
            self.events.append({'minute':round(self.t,2),'band':'outer','code':'bubble_activated','message':'Bubble command activated after the assumed detector persistence and start delay.'})
        if self.bubble_command and self.bubble_idle>=spec.get('idle_off_minutes',10):
            self.bubble_command=False
            self.events.append({'minute':round(self.t,2),'band':'outer','code':'bubble_deactivated','message':'Bubble command stopped after the illustrative no-detection timeout.'})

    def spawn(self,kg,origin=None,generation=0):
        if origin is None:
            origin=self.next_external_origin;self.next_external_origin+=1;identity=origin
        else:
            identity=1_000_000+self.next_id;self.next_id+=1
        g=self.cfg['geometry'];bio=self.cfg['biology'];water_depth=g['water_depth_m']
        zmin=bio['initial_depth_min_m'];zmax=min(water_depth-bio['bottom_clearance_m'],water_depth*bio['initial_depth_max_fraction'])
        if self.scenario=='deep_bloom': zmin=max(zmin,water_depth*0.65)
        z=zmin+(zmax-zmin)*uniform(self.seed,origin,generation,12)
        p=Particle(identity,origin,kg,g['source_x_m'],2+(g['width_m']-4)*uniform(self.seed,origin,generation,11),z,z,generation)
        self.particles.append(p)

    def arrivals(self,dt):
        if self.t<self.cfg['arrival_hours']*60:
            multiplier=3 if self.scenario=='overload' else 5 if self.scenario=='surge' and 60<=self.t<100 else 1
            horizon=min(dt,self.cfg['arrival_hours']*60-self.t)
            self.spawn_credit+=self.cfg['external_rate_kg_h']*multiplier*horizon/60
            while self.spawn_credit>=self.cfg['cohort_kg']-1e-9:
                self.spawn(self.cfg['cohort_kg']);self.external+=self.cfg['cohort_kg'];self.spawn_credit-=self.cfg['cohort_kg']
            if self.t+dt>=self.cfg['arrival_hours']*60 and self.spawn_credit>1e-9:
                self.spawn(self.spawn_credit);self.external+=self.spawn_credit;self.spawn_credit=0
        pending=[]
        for due,lot in self.pending_returns:
            if due<=self.t:
                self.released-=lot.kg;self.returned+=lot.kg
                self.spawn(lot.kg,lot.origin,lot.generation+1)
                self.lifecycle.append({'minute':round(self.t,2),'origin':lot.origin,'generation':lot.generation+1,'band':'sea','event':'returned','kg':lot.kg})
            else: pending.append((due,lot))
        self.pending_returns=pending

    def move(self,dt):
        g=self.cfg['geometry'];seconds=dt*60;diffusion=g['horizontal_dispersion_m2_s']
        for p in self.particles:
            if p.state not in ('free','guided'): continue
            if p.state=='guided':
                b=self.bands[p.band];a,z=b['cfg']['start'],b['cfg']['end'];length=math.dist(a,z)
                if self.scenario=='guide_escape' and 60<=self.t<180 and uniform(self.seed,p.id,int(self.t*60),29)<1-math.exp(-seconds/600):
                    b['guided_kg']-=p.kg;p.state='free';p.x+=2;p.y-=0.5
                    self.flag('guide_escape',b['cfg']['name'],'Scripted guide escape before collection; interception does not equal completed removal.',p.kg,'kg','Measure retention and contact under changing flow.')
                    continue
                speed=g['guide_transport_m_s'];u,v=self.velocity(p.x,p.y,self.t)
                speed+=max(0,(u*(z[0]-a[0])+v*(z[1]-a[1]))/length)
                remaining=math.dist((p.x,p.y),z);distance=min(remaining,speed*seconds)
                if remaining<=distance+1e-9:
                    p.x,p.y=z;b['guided_kg']-=p.kg
                    b['net'].add(Lot(p.kg,p.captured,p.origin,p.generation));p.state='inventory'
                    self.lifecycle.append({'minute':round(self.t+dt,2),'origin':p.origin,'generation':p.generation,'band':b['cfg']['name'],'event':'at_collector','kg':p.kg})
                else: p.x+=distance*(z[0]-p.x)/remaining;p.y+=distance*(z[1]-p.y)/remaining
                continue
            u,v=self.velocity(p.x,p.y,self.t)
            midx,midy=p.x+u*seconds/2,p.y+v*seconds/2
            midz=p.z+self.vertical_rate(p.x,p.y,p.z,self.t)*seconds/2
            down=self.cfg['biology'].get('assumed_downward_swimming_m_s',0.0)
            mu,mv=self.velocity(midx,midy,self.t+dt/2)
            mw=self.vertical_rate(midx,midy,midz,self.t+dt/2)
            # Independent finite horizontal and vertical diffusion increments.
            a=max(1e-12,uniform(self.seed,p.id,int(self.t*60),31));b=uniform(self.seed,p.id,int(self.t*60),32)
            radius=math.sqrt(-2*math.log(a))*math.sqrt(2*diffusion*seconds)
            nx=p.x+mu*seconds+radius*math.cos(2*math.pi*b);ny=p.y+mv*seconds+radius*math.sin(2*math.pi*b)
            ka=max(1e-12,uniform(self.seed,p.id,int(self.t*60),33));kb=uniform(self.seed,p.id,int(self.t*60),34)
            kz=self.cfg['geometry']['vertical_dispersion_m2_s']
            znoise=math.sqrt(-2*math.log(ka))*math.sqrt(2*kz*seconds)*math.cos(2*math.pi*kb)
            wup=self.bubble_path_average(p.x,p.y,nx,ny,midz,self.t+dt/2)
            nz=self.reflect_depth(p.z+(down-wup)*seconds+znoise)
            nz0=self.reflect_depth(p.z_no_bubble+down*seconds+znoise)
            if self.bubble_on(self.t) and self.variant['bubble']=='plume':
                wup=max(0.0,wup)
                self.bubble_upward_displacement_kg_m+=wup*seconds*p.kg
                if p.z>self.cfg['bands'][0]['skirt_depth_m'] and nz<=self.cfg['bands'][0]['skirt_depth_m'] and nz0>self.cfg['bands'][0]['skirt_depth_m'] and not p.lifted_by_bubble:
                    p.lifted_by_bubble=True;self.bubble_lifted_kg+=p.kg
            caught=False
            for i,band in enumerate(self.bands):
                spec=band['cfg'];probe=spec['start'][0]-(self.cfg['sensor'].get('approach_lookahead_m',15) if i==0 else 15);passline=spec['end'][0]+3
                if p.x<probe<=nx and i not in p.probes:
                    p.probes.add(i);self.record_observation(p,i,0)
                crossing=intersect(p.x,p.y,nx,ny,spec['start'],spec['end'])
                if crossing is not None:
                    p.encounters[i]=p.encounters.get(i,0)+1
                    fraction,along=crossing
                    z_cross=p.z+(nz-p.z)*fraction
                    z0_cross=p.z_no_bubble+(nz0-p.z_no_bubble)*fraction
                    if z_cross>spec['skirt_depth_m']:
                        self.flag('depth_bypass',spec['name'],'Cohort crossed below this surface boom’s modeled skirt depth.',p.kg,'kg','Measure vertical bloom distribution and size skirt depth from approved hydraulic and ecological constraints.')
                    load=band['net'].kg+band['guided_kg'];room=load+p.kg<=0.8*spec['capture_load_limit_kg'] and band['receiver'].kg<0.9*spec['receiver_capacity_kg']
                    efficiency=spec['intercept_probability']
                    if self.scenario=='storm' and 60<=self.t<180: efficiency*=0.5
                    if self.scenario=='bypass' and (along<0.15 or along>0.85): efficiency=0
                    if self.scenario=='animal_pause' and i==0 and 30<=self.t<90: efficiency=0
                    if self.variant['bubble']=='adverse' and i==0 and self.bubble_on(self.t): efficiency*=0.65
                    eligible=i<self.variant['bands'] and band['active'] and z_cross<=spec['skirt_depth_m']
                    if eligible and not room:
                        self.flag('capture_capacity_limited',spec['name'],'Capture-load or receiving limit prevents new interception. Load is not a hydraulic pressure-drop calculation.',load,'kg','Compare dedicated clearing, receiving and transport capacity before enlarging a barrier.')
                    if eligible and room and uniform(self.seed,p.origin,p.generation,i,p.encounters[i],21)<efficiency:
                        p.x=p.x+(nx-p.x)*fraction;p.y=p.y+(ny-p.y)*fraction;p.z=z_cross;p.z_no_bubble=z0_cross
                        p.state='guided';p.band=i;p.captured=self.t+fraction*dt
                        band['guided_kg']+=p.kg;band['intercepted_kg']+=p.kg;caught=True
                        self.lifecycle.append({'minute':round(p.captured,2),'origin':p.origin,'generation':p.generation,'band':spec['name'],'event':'intercepted','kg':p.kg})
                        break
                if p.x<passline<=nx and i not in p.passed:
                    p.passed.add(i);band['passed_kg']+=p.kg;self.record_observation(p,i,1)
                if nx<probe-10: p.probes.discard(i);p.passed.discard(i)
            if caught: continue
            p.x,p.y,p.z,p.z_no_bubble=nx,ny,nz,nz0
            if p.x>=g['length_m']:
                p.state='past_inner';self.residual+=p.kg
                self.flag('inner_passage','inner','Biomass crosses beyond the final simulated boundary. Plant screens are outside this model.',self.residual,'kg','Identify whether sensing, coverage, capture, collection or transport limited recovery.')
            elif p.x<0 or p.y<0 or p.y>g['width_m']:
                p.state='left_domain';self.left_domain+=p.kg
                self.flag('domain_exit','sea','Particles leave the illustrative domain; their later destination is unknown, not certified clearance.',self.left_domain,'kg','Extend the domain with native fields and investigate local flow/boundary assumptions.')

    def collect(self,dt):
        for i,b in enumerate(self.bands):
            room=max(0,b['cfg']['receiver_capacity_kg']-b['receiver'].kg)
            capacity=self.collector_rate(i)*dt/60 if b['active'] else 0
            for lot in b['net'].take(min(room,capacity)):
                b['receiver'].add(lot);b['collected_kg']+=lot.kg
                self.lifecycle.append({'minute':round(self.t+dt,2),'origin':lot.origin,'generation':lot.generation,'band':b['cfg']['name'],'event':'received','kg':lot.kg})
            load=b['net'].kg+b['guided_kg']
            b['peak_capture_load_kg']=max(b['peak_capture_load_kg'],load)
            b['peak_receiver_kg']=max(b['peak_receiver_kg'],b['receiver'].kg)
            guided_age=max((self.t+dt-p.captured for p in self.particles if p.state=='guided' and p.band==i),default=0)
            age=max(guided_age,b['net'].age(self.t+dt),b['receiver'].age(self.t+dt))
            b['max_age_minutes']=max(b['max_age_minutes'],age);self.peak_held_age=max(self.peak_held_age,age)
            if age>self.cfg['holding_flag_minutes']:
                self.flag('holding_age',b['cfg']['name'],'Illustrative holding-age flag exceeded; animal survival is not computed.',age,'minutes','Have an ecologist establish handling limits and inspect collector/transport/receiving bottlenecks.')
            if b['receiver'].kg>=0.9*b['cfg']['receiver_capacity_kg']:
                self.flag('receiver_near_full',b['cfg']['name'],'Receiving load reaches the capture-derating threshold.',b['receiver'].kg,'kg','Improve turnover and approved contingencies before adding storage alone.')
            if load>b['cfg']['capture_load_limit_kg']+1e-6 or b['receiver'].kg>b['cfg']['receiver_capacity_kg']+1e-6:
                raise ArithmeticError('Capacity accounting overflow')

    def set_boat_state(self,boat,state,duration):
        boat['state']=state;boat['remaining']=duration
        if boat['trip'] is not None: self.trips[boat['trip']]['phases'].append({'minute':round(self.t,2),'state':state})

    def boats_step(self,dt):
        v=self.cfg['vessel'];available=self.vessel_ok() and self.weather_ok()
        reserved={boat['band'] for boat in self.boats if boat['state']!='idle'}
        if not self.vessel_ok(): self.flag('vessels_unavailable','transport','Scripted outage stops vessel service; catch remains held.',response='Establish recovery resources and a finite outage envelope.')
        if not self.weather_ok(): self.flag('weather_transport_closure','transport','Illustrative wave/wind limits pause transport resources. Safe real vessel behavior is not simulated.',response='Obtain the vessel operating envelope and location-specific recovery/holding procedures.')
        if not self.release_open(): self.flag('release_unavailable','transport','Hypothetical release resource is closed; onboard cargo and receivers remain occupied.',response='Assess approved alternatives and maximum outage duration; holding indefinitely is not clearance.')
        for boat in self.boats:
            self.boat_kwh+=v['assumed_auxiliary_kw']*dt/60
            if available and boat['state'] in ('pickup_travel','release_travel','return'):
                self.boat_kwh+=v['assumed_propulsion_kw']*dt/60
            age=boat['cargo'].age(self.t+dt);self.peak_held_age=max(self.peak_held_age,age)
            if age>self.cfg['holding_flag_minutes']:
                self.flag('onboard_holding_age','transport','Onboard holding-age proxy exceeded; no survival calculation.',age,'minutes','Measure transport handling and assess release closures with the ecologist.')
            if boat['state']=='idle':
                if not available: continue
                candidates=[]
                for i,b in enumerate(self.bands):
                    if i in reserved or b['receiver'].kg<1e-6: continue
                    age=b['receiver'].age(self.t)
                    if b['receiver'].kg<v['minimum_dispatch_kg'] and age<self.cfg['holding_flag_minutes']/2: continue
                    free=b['cfg']['receiver_capacity_kg']-b['receiver'].kg
                    observed=b['observed_flux'] if b['observed_flux'] is not None else b['cfg']['collector_rate_kg_h']
                    estimated_fill=60*free/max(observed,1)
                    deadline=self.cfg['holding_flag_minutes']-age
                    candidates.append((min(estimated_fill,deadline),i))
                if not candidates: continue
                _,i=min(candidates);reserved.add(i);boat['band']=i
                self.trips.append({'boat':boat['id'],'band':self.bands[i]['cfg']['name'],'dispatch_minute':round(self.t,2),'loaded_kg':0.0,'released_kg':0.0,'release_minute':None,'completed_minute':None,'phases':[]})
                boat['trip']=len(self.trips)-1
                self.set_boat_state(boat,'pickup_travel',v['pickup_travel_minutes_by_band'][i]);continue
            if not available: continue
            if boat['state']=='unloading' and not self.release_open(): continue
            boat['remaining']-=dt
            if boat['remaining']>1e-9: continue
            i=boat['band'];trip=self.trips[boat['trip']]
            if boat['state']=='pickup_travel': self.set_boat_state(boat,'loading',v['loading_minutes'])
            elif boat['state']=='loading':
                for lot in self.bands[i]['receiver'].take(v['payload_kg']):
                    boat['cargo'].add(lot);self.bands[i]['transferred_kg']+=lot.kg;trip['loaded_kg']+=lot.kg
                    self.lifecycle.append({'minute':round(self.t,2),'origin':lot.origin,'generation':lot.generation,'band':self.bands[i]['cfg']['name'],'event':'onboard','kg':lot.kg})
                self.set_boat_state(boat,'release_travel',v['release_travel_minutes'])
            elif boat['state']=='release_travel': self.set_boat_state(boat,'unloading',v['unloading_minutes'])
            elif boat['state']=='unloading':
                fraction=0.6 if self.scenario=='high_return' else self.cfg['return_fraction']
                for lot in boat['cargo'].take(boat['cargo'].kg):
                    self.released+=lot.kg;self.gross_release+=lot.kg;trip['released_kg']+=lot.kg
                    self.lifecycle.append({'minute':round(self.t,2),'origin':lot.origin,'generation':lot.generation,'band':'sea','event':'hypothetical_release','kg':lot.kg})
                    if fraction>0:
                        self.pending_returns.append((self.t+self.cfg['return_delay_minutes'],Lot(lot.kg*fraction,lot.captured,lot.origin,lot.generation)))
                trip['release_minute']=round(self.t,2)
                self.set_boat_state(boat,'return',v['return_minutes'])
            elif boat['state']=='return':
                trip['completed_minute']=round(self.t,2);reserved.discard(i)
                self.set_boat_state(boat,'idle',0);boat['band']=None;boat['trip']=None
            if boat['cargo'].kg>v['payload_kg']+1e-6: raise ArithmeticError('Vessel payload exceeded')

    def accounting(self):
        free=sum(p.kg for p in self.particles if p.state=='free')
        guided=sum(p.kg for p in self.particles if p.state=='guided')
        net=sum(b['net'].kg for b in self.bands);received=sum(b['receiver'].kg for b in self.bands)
        onboard=sum(b['cargo'].kg for b in self.boats)
        accounted=free+guided+net+received+onboard+self.residual+self.left_domain+self.released
        error=abs(self.external-accounted);self.max_error=max(self.max_error,error)
        if error>max(1e-5,self.external*1e-9): raise ArithmeticError(f'Mass accounting discrepancy {error:.6g} kg')
        if self.released<-1e-6: raise ArithmeticError('Negative released account')
        return {'free_kg':free,'guided_kg':guided,'net_kg':net,'receiver_kg':received,'onboard_kg':onboard,'held_kg':guided+net+received+onboard,'residual_kg':self.residual,'unknown_domain_exit_kg':self.left_domain,'net_released_kg':self.released,'external_kg':self.external,'mass_error_kg':error}

    def snapshot(self,t,account):
        e=self.conditions(min(t,self.cfg['observation_hours']*60))
        row={'minute':round(t,2),**{k:round(v,5) for k,v in account.items()},'wave_height_m':round(e['wave_height'],3),'wind_m_s':round(e['wind_speed_10m'],3),'regional_current_m_s':round(math.hypot(e['current_u_east_m_s'],e['current_v_north_m_s']),4),'bubble_active':self.bubble_on(self.t),'band_kwh':round(self.band_kwh,4),'bubble_kwh':round(self.bubble_kwh,4),'boat_kwh':round(self.boat_kwh,4),'returned_kg':round(self.returned,4),'bands':[],'boats':[]}
        local_u,local_v=self.velocity(0,self.cfg['geometry']['width_m']/2,min(t,self.cfg['observation_hours']*60))
        row.update(local_u_m_s=round(local_u,4),local_v_m_s=round(local_v,4),regional_sea_level_m=round(e['sea_level_height_msl'],3))
        for b in self.bands:
            row['bands'].append({'name':b['cfg']['name'],'state':b['state'],'true_flux_kg_h':round(b['true_flux'],3),'observed_flux_kg_h':None if b['observed_flux'] is None else round(b['observed_flux'],3),'guided_kg':round(b['guided_kg'],4),'queued_kg':round(b['net'].kg,4),'receiver_kg':round(b['receiver'].kg,4),'intercepted_kg':round(b['intercepted_kg'],4),'collected_kg':round(b['collected_kg'],4),'transferred_kg':round(b['transferred_kg'],4),'max_age_minutes':round(b['max_age_minutes'],2)})
        for b in self.boats: row['boats'].append({'id':b['id'],'state':b['state'],'band':b['band'],'remaining_minutes':round(max(0,b['remaining']),2),'cargo_kg':round(b['cargo'].kg,4)})
        self.series.append(row)
        if self.detail:
            live=[p for p in self.particles if p.state in ('free','guided')]
            stride=max(1,math.ceil(len(live)/75))
            self.frames.append({'minute':round(t,2),'particles':[[p.id,round(p.x,2),round(p.y,2),round(p.z,2),p.band if p.state=='guided' else -1,round(p.kg,3),p.lifted_by_bubble,round(self.bubble_upwelling(p.x,p.y,p.z,t),5)] for p in live[::stride]],'live_cohorts':len(live),'displayed_cohorts':len(live[::stride]),'bubble_active':self.bubble_on(t),'diffuser_depth_m':round(self.cfg['geometry']['water_depth_m']-self.cfg['bubble']['diffuser_bottom_clearance_m'],3)})

    def run(self):
        dt=self.cfg['step_seconds']/60;horizon=self.cfg['observation_hours']*60;next_snapshot=0
        self.snapshot(0,self.accounting());next_snapshot=3
        while self.t<horizon-1e-9:
            step=min(dt,horizon-self.t)
            if self.scenario=='animal_pause' and 30<=self.t<90:
                self.flag('animal_review_pause','outer','Scripted handling pause for uncertain/non-target animals. No automatic sorting or bycatch survival is simulated.',response='Develop approved inspection and handling with the marine ecologist.')
            self.arrivals(step);self.update_controls(step)
            if self.bubble_on(self.t):
                self.bubble_kwh+=self.cfg['bubble']['compressor_power_kw']*step/60
                self.bubble_active_minutes+=step
            # RK2 substeps limit prescribed motion scale; full segments still intersect guides.
            e=self.conditions(self.t);g=self.cfg['geometry']
            speed_bound=abs(g['assumed_intakeward_component_m_s'])+g['regional_current_scale']*math.hypot(e['current_u_east_m_s'],e['current_v_north_m_s'])+self.cfg['bubble']['maximum_water_upwelling_m_s']+abs(self.cfg['biology'].get('assumed_downward_swimming_m_s',0.0))
            substeps=max(1,math.ceil(speed_bound*step*60/10));base=self.t
            for j in range(substeps):
                self.t=base+j*step/substeps;self.move(step/substeps)
            self.t=base
            self.collect(step);self.boats_step(step)
            account=self.accounting();self.t+=step
            if self.t>=next_snapshot-1e-9 or self.t>=horizon-1e-9:
                self.snapshot(self.t,account);next_snapshot+=3
        summary=self.accounting();denominator=max(self.external,1e-9)
        summary.update(residual_percent=100*self.residual/denominator,unknown_exit_percent=100*self.left_domain/denominator,held_percent=100*summary['held_kg']/denominator,net_released_percent=100*self.released/denominator,gross_release_kg=self.gross_release,returned_kg=self.returned,pending_return_kg=sum(l.kg for _,l in self.pending_returns),max_accounting_error_kg=self.max_error,oldest_holding_minutes=self.peak_held_age,band_kwh=self.band_kwh,bubble_kwh=self.bubble_kwh,bubble_active_minutes=self.bubble_active_minutes,bubble_duty_percent=100*self.bubble_active_minutes/horizon,bubble_activation_count=sum(e['code']=='bubble_activated' for e in self.events),bubble_lifted_kg=self.bubble_lifted_kg,bubble_lifted_percent=100*self.bubble_lifted_kg/denominator,bubble_upward_displacement_kg_m=self.bubble_upward_displacement_kg_m,bubble_gas_flow_m3_h=self.bubble_gas_flow_m3_h(),boat_kwh=self.boat_kwh,total_kwh=self.band_kwh+self.bubble_kwh+self.boat_kwh,completed_trips=sum(t['completed_minute'] is not None for t in self.trips),dispatched_trips=len(self.trips),supervisor_hours=self.cfg['vessel']['supervisors']*self.cfg['observation_hours'],initial_cohorts=self.next_external_origin,assumed_initial_animal_equivalent=self.external/self.cfg['assumed_individual_mass_kg'],numerical_held_age_flag=self.peak_held_age>self.cfg['holding_flag_minutes'])
        cost=self.cfg['cost']
        summary['partial_energy_staff_cost_aed']=None if cost['electricity_price_per_kwh'] is None or cost['staff_price_per_hour'] is None else summary['total_kwh']*cost['electricity_price_per_kwh']+summary['supervisor_hours']*cost['staff_price_per_hour']
        summary['kwh_per_net_released_tonne']=summary['total_kwh']/(self.released/1000) if self.released>1e-9 else None
        if summary['held_kg']>1e-6: self.flag('unfinished_handling','all','Biomass remains held at the observation horizon; this is not completed clearance.',summary['held_kg'],'kg','Extend observation and investigate resources/approved contingencies rather than hiding backlog.')
        if self.returned>0: self.flag('release_return','sea','Scenario assumes released biomass returns and may be handled repeatedly.',self.returned,'kg','Use native drift and local evidence to assess release arrangements.')
        stats=[]
        for b in self.bands:
            stats.append({k:v for k,v in b.items() if k in ('arrived_kg','intercepted_kg','collected_kg','passed_kg','transferred_kg','observed_total_kg','peak_capture_load_kg','peak_receiver_kg','max_age_minutes','active_minutes')}|{'name':b['cfg']['name']})
        return {'scenario':self.scenario,'variant':self.variant['id'],'window':self.forcing.window['label'],'seed':self.seed,'summary':summary,'bands':stats,'series':self.series,'frames':self.frames,'trips':self.trips,'events':self.events,'gaps':list(self.gaps.values()),'lifecycle':self.lifecycle if self.detail else [],'forcing':self.forcing.metadata(),'assumptions':{'geometry':'illustrative','local_flow':'prescribed intakeward component plus projected regional point forcing','capture':'uncalibrated','bubble':self.variant['bubble'],'bubble_physics':'reduced-order point-plume superposition using buoyancy-flux/slip-regime scalings; diffuser flow, radius coefficient, spreading and local conditions are uncalibrated','vertical_geometry':'explicit depth coordinate and boom skirt; water depth and source depth are illustrative inputs','release':'hypothetical availability; actual release location unapproved','perception':'error emulator, not trained AI or CV','vessel':'scheduled resources, not navigation/docking dynamics','individual_mass':'assumed conversion; weighted cohorts are not individuals'}}

def simulate(cfg,forcing,scenario='reference',variant='three_off',seed=20261011,detail=False):
    if scenario not in dict(SCENARIOS): raise ValueError('Unknown scenario')
    result=Simulation(cfg,forcing,scenario,variant,seed,detail).run()
    result['config']=copy.deepcopy(cfg)
    return result
