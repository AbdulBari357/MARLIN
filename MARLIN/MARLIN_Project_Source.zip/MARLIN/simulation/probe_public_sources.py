"""Inspect public endpoints without downloading whole global archives."""
import json
import requests
from pathlib import Path
from fathomnet.api import images
import inspect

targets = {
    "ceda_dds": "https://dap.ceda.ac.uk/bodc/gebco/global/gebco_2025/ice_surface_elevation/netcdf/GEBCO_2025.nc.dds",
    "gbif": "https://api.gbif.org/v1/occurrence/search?taxonKey=2264506&mediaType=StillImage&limit=1",
    "wind": "https://archive-api.open-meteo.com/v1/archive?latitude=24.125&longitude=52.25&start_date=2024-01-01&end_date=2024-01-02&hourly=wind_speed_10m,wind_direction_10m,pressure_msl&models=era5&timezone=GMT&wind_speed_unit=ms&cell_selection=sea&elevation=nan",
    "waves": "https://marine-api.open-meteo.com/v1/marine?latitude=24.125&longitude=52.25&start_date=2024-01-01&end_date=2024-01-02&hourly=wave_height,wave_direction,wave_period&models=era5_ocean&timezone=GMT",
    "smoc": "https://marine-api.open-meteo.com/v1/marine?latitude=24.125&longitude=52.25&start_date=2024-01-01&end_date=2024-01-02&hourly=ocean_current_velocity,ocean_current_direction,sea_level_height_msl&models=meteofrance_seamless&timezone=GMT",
    "obis": "https://api.obis.org/v3/occurrence?scientificname=Catostylus%20mosaicus&size=1",
}
for name, url in targets.items():
    try:
        r=requests.get(url, timeout=(15,40))
        print(name, r.status_code, r.headers.get('Content-Type'), r.text[:650], flush=True)
    except Exception as e:
        print(name, type(e).__name__, str(e)[:160], flush=True)
print("fathomnet_find", inspect.getsource(images.find_by_concept), flush=True)
import re
ceda=requests.get('https://data.ceda.ac.uk/bodc/gebco/global/gebco_2025/ice_surface_elevation/netcdf/',timeout=30)
print('ceda_links', [x for x in re.findall(r'href=[\"\']([^\"\']+)',ceda.text) if any(w in x.lower() for w in ['dap','subset','nc','json'])],flush=True)
print('fathomnet_classes', inspect.getsource(images.Images), flush=True)
for concept in []:
    try:
        found=images.find_by_concept(concept)
        print('concept',concept,len(found),str(found[:1])[:1400],flush=True)
    except Exception as e:
        print('concept',concept,type(e).__name__,str(e)[:120],flush=True)
html=requests.get('https://open-meteo.com/en/docs/marine-weather-api',timeout=30).text
print('marine_models', sorted(set(re.findall(r'meteofrance[a-z_]+',html))),flush=True)
for model in ['meteofrance_currents','meteofrance_smoc']:
    p={'latitude':24.125,'longitude':52.25,'start_date':'2024-01-01','end_date':'2024-01-02','hourly':'ocean_current_velocity,ocean_current_direction,sea_level_height_msl','models':model,'timezone':'GMT'}
    r=requests.get('https://marine-api.open-meteo.com/v1/marine',params=p,timeout=30)
    print('model_probe',model,r.status_code,r.text[:950],flush=True)
