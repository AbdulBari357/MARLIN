"""Uncalibrated MARLIN mass-flow/queue model. Never controls real equipment."""
from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import random
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path


DISCLAIMER = "ILLUSTRATIVE OPERATIONS MODEL — NOT SITE PERFORMANCE, CFD, ANIMAL-SURVIVAL EVIDENCE OR FIELD RELIABILITY"


@dataclass
class Lot:
    kg: float
    captured_minute: float


class Queue:
    def __init__(self):
        self.lots: deque[Lot] = deque()
        self.total = 0.0

    def add(self, lots):
        for lot in lots:
            if lot.kg <= 1e-12:
                continue
            if self.lots and self.lots[-1].captured_minute == lot.captured_minute:
                self.lots[-1].kg += lot.kg
            else:
                self.lots.append(Lot(lot.kg, lot.captured_minute))
            self.total += lot.kg

    def take(self, requested):
        remaining = min(max(requested, 0.0), self.total)
        result = []
        while remaining > 1e-10 and self.lots:
            head = self.lots[0]
            amount = min(head.kg, remaining)
            result.append(Lot(amount, head.captured_minute))
            head.kg -= amount
            self.total -= amount
            remaining -= amount
            if head.kg <= 1e-10:
                self.lots.popleft()
        if not self.lots:
            self.total = 0.0
        return result

    def age(self, minute):
        return max(0.0, minute - self.lots[0].captured_minute) if self.lots else 0.0


@dataclass
class Band:
    cfg: dict
    net: Queue = field(default_factory=Queue)
    receiver: Queue = field(default_factory=Queue)
    active: bool = False
    ready_at: float | None = None
    persistence: float = 0.0
    idle: float = 0.0
    stats: dict = field(default_factory=lambda: {
        "arrived_kg": 0.0, "captured_kg": 0.0, "collected_kg": 0.0,
        "passed_kg": 0.0, "transferred_kg": 0.0, "peak_net_kg": 0.0,
        "peak_receiver_kg": 0.0, "oldest_held_minutes": 0.0,
        "active_minutes": 0.0, "equipment_electricity_kwh": 0.0,
    })


SCENARIOS = [
    {"id": "reference", "label": "Reference continuous bloom", "description": "Synthetic reference load; no imposed fault."},
    {"id": "sustained_overload", "label": "Sustained overload", "description": "External loading is four times the configured reference rate."},
    {"id": "short_surge", "label": "Short extreme surge", "description": "Sixfold incoming load from minute 120 to 180."},
    {"id": "outer_outage", "label": "Outer collector unavailable", "description": "Outer unloading stops from minute 120 to 240; passive interception can still accumulate mass."},
    {"id": "all_outage", "label": "All collectors unavailable", "description": "All unloading stops from minute 120 to 180."},
    {"id": "network_loss", "label": "Inter-band network loss", "description": "Supervisor fault notifications unavailable from minute 90 to 240; local synthetic sensors remain."},
    {"id": "sensor_blind", "label": "Middle / inner missing detections", "description": "Both reserve flux observations missing from minute 90 to 210; conservative local readiness requested."},
    {"id": "sensor_bias", "label": "Reserve detectors underestimate", "description": "Reserve flux observations are only 5% of actual arrivals throughout the event."},
    {"id": "common_sea_state", "label": "Common sea-state degradation", "description": "All interception fractions reduced to 35% of their reference assumptions, minute 90 to 300. No wave physics."},
    {"id": "depth_bypass", "label": "Depth and side bypass", "description": "All interception fractions reduced to 60% of reference for the whole event. No depth geometry."},
    {"id": "debris", "label": "Debris reduces collection", "description": "All unloading rates reduced to 35%, minute 60 to 300; debris itself is not modelled."},
    {"id": "release_closed", "label": "No permitted release window", "description": "Shared transport/release service unavailable from minute 120 to 300."},
    {"id": "high_return", "label": "High return after release", "description": "60% of transfer/release mass re-enters after the configured delay. Assumed stress input."},
    {"id": "animal_hold", "label": "Outer uncertain-animal pause", "description": "Outer new interception and unloading paused minute 60 to 90. No animal-survival or bycatch calculation."},
    {"id": "maintenance_full", "label": "Maintenance request at reference load", "description": "Reserve pre-armed; request to take outer capture out of service at minute 120 is guarded by capacity and load checks."},
    {"id": "maintenance_lull", "label": "Maintenance request during lull", "description": "External load is 30% of reference; same guarded maintenance request."},
    {"id": "compound", "label": "Compound failure", "description": "Outer unloading outage minute 60–300, release closed minute 60–360, common interception reduction minute 90–300."},
]


def validate(cfg):
    numeric_values = [v for v in cfg.values() if isinstance(v, (int, float))]
    numeric_values += [v for b in cfg["bands"] for v in b.values() if isinstance(v, (int, float))]
    if any(not math.isfinite(v) for v in numeric_values):
        raise ValueError("All numeric inputs must be finite")
    if len(cfg["bands"]) != 3 or [b["name"] for b in cfg["bands"]] != ["outer", "middle", "inner"]:
        raise ValueError("Exactly outer, middle and inner band definitions are required.")
    for key in ("step_minutes", "input_duration_hours", "observation_duration_hours", "return_delay_minutes", "holding_limit_minutes"):
        if cfg[key] <= 0:
            raise ValueError(f"{key} must be positive")
    if cfg["observation_duration_hours"] < cfg["input_duration_hours"]:
        raise ValueError("Observation horizon cannot end before external arrivals stop.")
    for key in ("external_rate_kg_h", "transport_release_rate_kg_h", "sensor_power_kw_per_band", "activation_persistence_minutes", "reserve_idle_minutes"):
        if cfg[key] < 0:
            raise ValueError(f"{key} must be nonnegative")
    if not 0 <= cfg["release_return_fraction"] <= 1:
        raise ValueError("Return fraction must be between 0 and 1")
    for key in ("loading_derate_fraction", "receiving_derate_fraction"):
        if not 0 < cfg[key] <= 1:
            raise ValueError(f"{key} must be in (0,1]")
    for i, b in enumerate(cfg["bands"]):
        if not 0 <= b["efficiency"] <= 1:
            raise ValueError("Interception fractions must be in [0,1]")
        for key in ("net_capacity_kg", "receiver_capacity_kg"):
            if b[key] <= 0:
                raise ValueError(f"{key} must be positive")
        for key in ("collector_rate_kg_h", "activate_flux_kg_h", "activation_delay_minutes", "travel_to_next_minutes", "collector_power_kw"):
            if b[key] < 0:
                raise ValueError(f"{key} must be nonnegative")
        if i < 2 and b["travel_to_next_minutes"] <= 0:
            raise ValueError("Inter-band travel delay must be positive")
    for key in ("sensitivity_input_range", "sensitivity_capacity_range", "sensitivity_efficiency_offset_range"):
        a, b = cfg[key]
        if not math.isfinite(a) or not math.isfinite(b) or a > b:
            raise ValueError(f"Invalid range: {key}")
    if cfg["sensitivity_input_range"][0] < 0 or cfg["sensitivity_capacity_range"][0] < 0:
        raise ValueError("Rate/capacity multipliers must be nonnegative")


def sampled_config(cfg, seed):
    """Synthetic shared and individual variations; not calibrated priors."""
    c = copy.deepcopy(cfg)
    rng = random.Random(seed)
    c["external_rate_kg_h"] *= rng.uniform(*c["sensitivity_input_range"])
    common_capacity = rng.uniform(*c["sensitivity_capacity_range"])
    common_efficiency = rng.uniform(*c["sensitivity_efficiency_offset_range"])
    c["transport_release_rate_kg_h"] *= rng.uniform(*c["sensitivity_capacity_range"])
    for b in c["bands"]:
        b["collector_rate_kg_h"] *= common_capacity * rng.uniform(0.9, 1.1)
        b["efficiency"] = min(1.0, max(0.0, b["efficiency"] + common_efficiency + rng.uniform(-0.03, 0.03)))
    return c


def simulate(cfg, scenario="reference", variant="three_band", keep_series=True):
    validate(cfg)
    if scenario not in {s["id"] for s in SCENARIOS}:
        raise ValueError("Unknown scenario")
    if variant not in ("three_band", "outer_only"):
        raise ValueError("Unknown variant")
    bands = [Band(copy.deepcopy(b)) for b in cfg["bands"]]
    bands[0].active = True  # Existing alert assumed at start; physical deployment not simulated.
    transit = []
    return_queue = []
    external = released_at_sea = residual = historical_release = returned = max_error = 0.0
    alerts = []
    alarm_minutes = {}
    series = []
    maintenance_decided = False
    maintenance_until = -1.0
    maintenance_permitted = False
    horizon = cfg["observation_duration_hours"] * 60
    input_end = cfg["input_duration_hours"] * 60
    minute = 0.0

    def alarm(key, detail, dt):
        if key not in alarm_minutes:
            alerts.append({"minute": round(minute, 3), "code": key, "detail": detail})
            alarm_minutes[key] = 0.0
        alarm_minutes[key] += dt

    while minute < horizon - 1e-9:
        dt = min(cfg["step_minutes"], horizon - minute)
        incoming = [0.0, 0.0, 0.0]
        load_factor = 4.0 if scenario == "sustained_overload" else 0.3 if scenario == "maintenance_lull" else 1.0
        if scenario == "short_surge" and 120 <= minute < 180:
            load_factor = 6.0
        input_dt = max(0.0, min(minute + dt, input_end) - minute)
        new_mass = cfg["external_rate_kg_h"] * load_factor * input_dt / 60
        external += new_mass
        incoming[0] += new_mass
        future = []
        for due, kg in return_queue:
            if due <= minute + 1e-9:
                released_at_sea -= kg
                returned += kg
                incoming[0] += kg
            else:
                future.append((due, kg))
        return_queue = future
        future = []
        for due, index, kg in transit:
            if due <= minute + 1e-9:
                incoming[index] += kg
            else:
                future.append((due, index, kg))
        transit = future
        network_ok = not (scenario == "network_loss" and 90 <= minute < 240)
        if not network_ok:
            alarm("supervisor_link_unavailable", "Inter-band notifications are unavailable; local readiness/sensing remains independent in this model.", dt)
        release_open = not ((scenario == "release_closed" and 120 <= minute < 300) or (scenario == "compound" and 60 <= minute < 360))
        rates = [b.cfg["collector_rate_kg_h"] for b in bands]
        efficiency_factor = [1.0, 1.0, 1.0]
        if scenario == "outer_outage" and 120 <= minute < 240:
            rates[0] = 0.0
        if scenario == "all_outage" and 120 <= minute < 180:
            rates = [0.0] * 3
        if scenario == "common_sea_state" and 90 <= minute < 300:
            efficiency_factor = [0.35] * 3
        if scenario == "depth_bypass":
            efficiency_factor = [0.6] * 3
        if scenario == "debris" and 60 <= minute < 300:
            rates = [r * 0.35 for r in rates]
        if scenario == "compound":
            if 60 <= minute < 300:
                rates[0] = 0.0
            if 90 <= minute < 300:
                efficiency_factor = [0.5] * 3
        if scenario == "animal_hold" and 60 <= minute < 90:
            rates[0] = 0.0
            efficiency_factor[0] = 0.0
            alarm("outer_animal_hold", "Scripted human-review pause; animal outcomes are not modelled.", dt)

        if scenario.startswith("maintenance_") and 115 <= minute < 120 and variant == "three_band":
            if not bands[1].active and bands[1].ready_at is None:
                bands[1].ready_at = minute + bands[1].cfg["activation_delay_minutes"]
        if scenario.startswith("maintenance_") and minute >= 120 and not maintenance_decided:
            maintenance_decided = True
            expected_rate = incoming[0] * 60 / dt
            reserve = bands[1]
            ready = reserve.active or (reserve.ready_at is not None and minute >= reserve.ready_at)
            free_space = reserve.cfg["receiver_capacity_kg"] - reserve.receiver.total
            maintenance_permitted = (variant == "three_band" and ready and rates[1] >= expected_rate
                                    and cfg["transport_release_rate_kg_h"] >= expected_rate and release_open
                                    and bands[0].net.total < 0.1 * bands[0].cfg["net_capacity_kg"]
                                    and free_space >= expected_rate * 5 / 60)
            if maintenance_permitted:
                maintenance_until = minute + 20
                alarm("maintenance_permitted", "Simplified permit: low primary load, reserve ready, and model capacity/space available.", dt)
            else:
                alarm("maintenance_refused", "Reserve readiness, rate, primary loading or receiving/logistics checks failed; no automatic downstream dump.", dt)
        if minute < maintenance_until:
            efficiency_factor[0] = 0.0  # Existing retained mass is not dumped; collection can continue.

        passed_rates = []
        for i, b in enumerate(bands):
            mass = incoming[i]
            arrival_rate = mass * 60 / dt
            b.stats["arrived_kg"] += mass
            if scenario == "sensor_blind" and i > 0 and 90 <= minute < 210:
                observation = None
                alarm(f"{b.cfg['name']}_sensor_missing", "Missing flux observation; reserve requested, not interpreted as zero biomass.", dt)
            else:
                observation = arrival_rate * (0.05 if scenario == "sensor_bias" and i > 0 else 1.0)
            enabled = i == 0 or variant == "three_band"
            upstream_fault = (i > 0 and network_ok and rates[i - 1] == 0)
            if i > 0 and enabled:
                request = observation is None or observation >= b.cfg["activate_flux_kg_h"] or upstream_fault
                b.persistence = b.persistence + dt if request else 0.0
                if upstream_fault or observation is None:
                    b.persistence = cfg["activation_persistence_minutes"]
                if request and b.persistence >= cfg["activation_persistence_minutes"] and not b.active and b.ready_at is None:
                    b.ready_at = minute + b.cfg["activation_delay_minutes"]
                if b.ready_at is not None and minute >= b.ready_at:
                    b.active = True
                    b.ready_at = None
                if b.active:
                    b.idle = b.idle + dt if not request and b.net.total < 1e-9 else 0.0
                    if b.idle >= cfg["reserve_idle_minutes"]:
                        b.active = False
                        b.idle = 0.0
            if not enabled:
                b.active = False
            if enabled:
                b.stats["equipment_electricity_kwh"] += cfg["sensor_power_kw_per_band"] * dt / 60
            active_fraction = 1.0 if b.active else 0.0
            if b.active and rates[i] == 0:
                # Passive guide may still intercept during an actuator trip; uncalibrated assumption.
                active_fraction *= 0.5
                alarm(f"{b.cfg['name']}_collector_unavailable", "Interception can accumulate while unloading is unavailable; passive factor is assumed.", dt)
            collection_room = max(0.0, b.cfg["receiver_capacity_kg"] - b.receiver.total)
            headroom = max(0.0, cfg["loading_derate_fraction"] * b.cfg["net_capacity_kg"] - b.net.total)
            allowance = headroom + min(rates[i] * dt / 60, collection_room)
            if b.receiver.total >= cfg["receiving_derate_fraction"] * b.cfg["receiver_capacity_kg"]:
                allowance = 0.0
                alarm(f"{b.cfg['name']}_receiver_derate", "Receiving load constrains new capture; increased downstream passage remains possible.", dt)
            wanted = mass * b.cfg["efficiency"] * efficiency_factor[i] * active_fraction
            captured = max(0.0, min(wanted, allowance))
            if captured + 1e-8 < wanted:
                alarm(f"{b.cfg['name']}_capture_limited", "Assumed accumulation limit reduces capture; this does not prove hydraulic safety.", dt)
            b.net.add([Lot(captured, minute)])
            b.stats["captured_kg"] += captured
            passed = max(0.0, mass - captured)
            b.stats["passed_kg"] += passed
            passed_rates.append(passed * 60 / dt)
            if i < 2 and passed > 1e-12:
                transit.append((minute + b.cfg["travel_to_next_minutes"], i + 1, passed))
            elif i == 2:
                residual += passed
            transfer = b.net.take(min(rates[i] * dt / 60, collection_room)) if b.active else []
            collected = sum(l.kg for l in transfer)
            b.receiver.add(transfer)
            b.stats["collected_kg"] += collected
            b.stats["peak_net_kg"] = max(b.stats["peak_net_kg"], b.net.total)
            b.stats["peak_receiver_kg"] = max(b.stats["peak_receiver_kg"], b.receiver.total)
            age = max(b.net.age(minute), b.receiver.age(minute))
            b.stats["oldest_held_minutes"] = max(b.stats["oldest_held_minutes"], age)
            if age > cfg["holding_limit_minutes"]:
                alarm(f"{b.cfg['name']}_holding_age_flag", "Illustrative holding-time flag exceeded; no survival or safe holding limit is inferred.", dt)
            if b.active:
                b.stats["active_minutes"] += dt
                nominal_rate = b.cfg["collector_rate_kg_h"]
                utilization = min(1.0, collected / (nominal_rate * dt / 60)) if nominal_rate > 0 else 0.0
                if rates[i] > 0:
                    b.stats["equipment_electricity_kwh"] += b.cfg["collector_power_kw"] * (0.2 + 0.8 * utilization) * dt / 60
            # Unprocessed capture can briefly exceed derating headroom but not absolute storage.
            if b.net.total > b.cfg["net_capacity_kg"] + 1e-6 or b.receiver.total > b.cfg["receiver_capacity_kg"] + 1e-6:
                raise AssertionError("Model storage capacity exceeded; reduce timestep or correct transfer logic.")

        service = cfg["transport_release_rate_kg_h"] * dt / 60 if release_open else 0.0
        if not release_open and any(b.receiver.total > 1e-9 for b in bands):
            alarm("release_unavailable", "No model release service; finite storage and holding limits still apply.", dt)
        return_fraction = 0.6 if scenario == "high_return" else cfg["release_return_fraction"]
        while service > 1e-9:
            available = [b for b in bands if b.receiver.lots]
            if not available:
                break
            b = min(available, key=lambda x: x.receiver.lots[0].captured_minute)
            amount = min(service, b.receiver.lots[0].kg)
            out = b.receiver.take(amount)
            actual = sum(l.kg for l in out)
            service -= actual
            b.stats["transferred_kg"] += actual
            historical_release += actual
            released_at_sea += actual
            if actual * return_fraction > 1e-12:
                return_queue.append((minute + cfg["return_delay_minutes"], actual * return_fraction))
        stored = sum(b.net.total + b.receiver.total for b in bands) + sum(v[2] for v in transit)
        error = abs(external - (stored + released_at_sea + residual))
        max_error = max(max_error, error)
        if error > max(1e-6, external * 1e-9):
            raise AssertionError(f"Mass conservation failed: {error}")
        if keep_series and (minute % 5 < dt or minute + dt >= horizon):
            row = {"minute": round(minute, 3), "external_rate_kg_h": new_mass * 60 / dt,
                   "residual_rate_kg_h": passed_rates[2], "released_at_sea_kg": released_at_sea,
                   "cumulative_residual_kg": residual, "in_transit_kg": sum(v[2] for v in transit)}
            for i, b in enumerate(bands):
                prefix = b.cfg["name"]
                row.update({f"{prefix}_arriving_kg_h": incoming[i] * 60 / dt,
                            f"{prefix}_held_kg": b.net.total + b.receiver.total,
                            f"{prefix}_retained_kg": b.net.total,
                            f"{prefix}_receiver_kg": b.receiver.total,
                            f"{prefix}_passed_kg_h": passed_rates[i],
                            f"{prefix}_active": b.active})
            series.append({k: round(v, 6) if isinstance(v, float) else v for k, v in row.items()})
        minute += dt

    held = sum(b.net.total + b.receiver.total for b in bands)
    in_transit = sum(v[2] for v in transit)
    summary = {"external_kg": external, "residual_beyond_inner_kg": residual,
               "residual_percent_external": 100 * residual / external if external else 0.0,
               "held_at_end_kg": held, "in_transit_at_end_kg": in_transit,
               "released_at_sea_account_kg": released_at_sea,
               "unresolved_percent_external": 100 * (residual + held + in_transit) / external if external else 0.0,
               "historical_transfer_release_kg": historical_release, "returned_kg": returned,
               "pending_return_kg": sum(v[1] for v in return_queue),
               "equipment_electricity_kwh": sum(b.stats["equipment_electricity_kwh"] for b in bands),
               "max_mass_balance_error_kg": max_error,
               "holding_age_flag": any("holding_age_flag" in k for k in alarm_minutes),
               "maintenance_permitted": maintenance_permitted,
               "alarm_types": len(alerts)}
    return {"scenario": scenario, "variant": variant, "summary": summary,
            "bands": [{"name": b.cfg["name"], "stats": b.stats,
                       "retained_at_end_kg": b.net.total, "received_at_end_kg": b.receiver.total} for b in bands],
            "alerts": alerts, "alarm_minutes": alarm_minutes, "series": series}


def quantile(values, probability):
    values = sorted(values)
    position = probability * (len(values) - 1)
    low = int(position)
    high = min(low + 1, len(values) - 1)
    return values[low] + (values[high] - values[low]) * (position - low)


def main():
    parser = argparse.ArgumentParser(description=DISCLAIMER)
    parser.add_argument("--config", type=Path, default=Path(__file__).resolve().parents[1] / "config/model.json")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "outputs")
    parser.add_argument("--samples", type=int, default=24)
    parser.add_argument("--seed", type=int, default=20261010)
    args = parser.parse_args()
    if args.samples < 1:
        parser.error("--samples must be at least 1")
    cfg = json.loads(args.config.read_text(encoding="utf-8"))
    validate(cfg)
    representative = []
    sensitivity = []
    for scenario in SCENARIOS:
        for variant in ("three_band", "outer_only"):
            representative.append(simulate(cfg, scenario["id"], variant))
            samples = [simulate(sampled_config(cfg, args.seed + i), scenario["id"], variant, False)["summary"]
                       for i in range(args.samples)]
            sensitivity.append({"scenario": scenario["id"], "variant": variant, "synthetic_samples": args.samples,
                                "residual_p10_percent": quantile([s["residual_percent_external"] for s in samples], 0.1),
                                "residual_p50_percent": quantile([s["residual_percent_external"] for s in samples], 0.5),
                                "residual_p90_percent": quantile([s["residual_percent_external"] for s in samples], 0.9),
                                "unresolved_p90_percent": quantile([s["unresolved_percent_external"] for s in samples], 0.9),
                                "samples_with_holding_age_flag": sum(s["holding_age_flag"] for s in samples)})
    payload = {"disclaimer": DISCLAIMER, "model_version": cfg["version"], "seed": args.seed,
               "samples_per_case": args.samples, "input_config": cfg, "scenarios": SCENARIOS,
               "runs": representative, "sensitivity": sensitivity}
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    for filename, rows in (("scenario_summary.csv", [{"scenario": r["scenario"], "variant": r["variant"], **r["summary"]} for r in representative]),
                           ("sensitivity.csv", sensitivity)):
        with (args.output / filename).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    from report import write_report
    write_report(payload, args.output)
    print(DISCLAIMER)
    print(f"Completed {len(representative)} representative cases and {len(sensitivity) * args.samples} synthetic sensitivity runs.")
    print(f"Outputs: {args.output.resolve()}")
    for r in representative:
        if r["variant"] == "three_band":
            s = r["summary"]
            print(f"{r['scenario']}: residual={s['residual_percent_external']:.2f}% unresolved={s['unresolved_percent_external']:.2f}% holding_flag={s['holding_age_flag']}")


if __name__ == "__main__":
    main()
