"""Run the standalone v0.2 research simulator and write offline review artifacts."""
import argparse
import copy
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import sys

from engine import DISCLAIMER, SCENARIOS, VARIANTS, simulate
from forcing import Forcing

ROOT=Path(__file__).resolve().parents[2]
EVIDENCE=[
 {'id':'E01','area':'Local hydraulics and moorings','status':'UNRESOLVED','needed':'Survey/flow evidence and appropriate hydraulic/structural validation. Queue mass is not head loss.'},
 {'id':'E02','area':'Capture and guide movement','status':'ASSUMED','needed':'Measured throughput, load, deformation, pinning and escape behavior; guide transport is prescribed.'},
 {'id':'E03','area':'Marine welfare and bycatch','status':'UNRESOLVED','needed':'Ecologist-reviewed holding limits, handling and post-release survival/bycatch studies.'},
 {'id':'E04','area':'Bubble mechanism and thresholds','status':'ASSUMED','needed':'Species/site trials; no validated automatic enable thresholds or bubble fluid mechanics.'},
 {'id':'E05','area':'AI detector accuracy','status':'NOT TRAINED','needed':'Expert-reviewed boxes/videos, held-out Gulf conditions, dense-load and non-target evaluation.'},
 {'id':'E06','area':'Boat, docking and release route','status':'HYPOTHETICAL','needed':'Actual transfer times, approved release arrangements and supervised vessel trials; no navigation dynamics.'},
 {'id':'E07','area':'Native regional fields','status':'PENDING SIGN-IN','needed':'Prepared GLORYS/SMOC/WAVERYS grids; point records do not resolve the local channel.'},
 {'id':'E08','area':'Lifecycle cost','status':'QUOTES MISSING','needed':'Prices, installation, maintenance, staffing, recovery and lifetime. Partial energy is not a total cost.'},
 {'id':'E09','area':'Bloom biomass and biology','status':'ASSUMED','needed':'Observed arrival, size, depth and behavior; regional weather does not measure jellyfish density.'}
]

def dump(path,value): path.write_text(json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')),encoding='utf-8')
def csv_write(path,rows):
    if not rows: return
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def summarize(run):
    return {'window':run['window'],'scenario':run['scenario'],'variant':run['variant'],'seed':run['seed'],**run['summary']}

def morris(cfg,forcing,trajectories,seed):
    # Four-level Morris trajectories; delta=2/3. All intervals are uncalibrated.
    definitions=[('external_rate_kg_h',600,1800),('outer_intercept_probability',0.65,0.95),('vessel_payload_kg',300,900),('guide_transport_m_s',0.1,0.3)]
    rng=random.Random(seed);effects={name:{'residual_percent':[],'oldest_holding_minutes':[]} for name,_,_ in definitions};runs=[]
    def configuration(position):
        c=copy.deepcopy(cfg)
        values=[lo+(hi-lo)*x for (_,lo,hi),x in zip(definitions,position)]
        c['external_rate_kg_h']=values[0];c['bands'][0]['intercept_probability']=values[1]
        c['vessel']['payload_kg']=values[2];c['geometry']['guide_transport_m_s']=values[3]
        return c
    for trajectory in range(trajectories):
        directions=[rng.choice([-1,1]) for _ in definitions]
        x=[rng.choice([0,1/3]) if d>0 else rng.choice([2/3,1]) for d in directions]
        order=list(range(len(definitions)));rng.shuffle(order);paired_seed=seed+trajectory
        before=simulate(configuration(x),forcing,seed=paired_seed);runs.append(summarize(before)|{'trajectory':trajectory,'step':0})
        for step,index in enumerate(order,1):
            old=x[index];x[index]+=directions[index]*2/3
            after=simulate(configuration(x),forcing,seed=paired_seed);runs.append(summarize(after)|{'trajectory':trajectory,'step':step})
            for metric in effects[definitions[index][0]]:
                effects[definitions[index][0]][metric].append((after['summary'][metric]-before['summary'][metric])/(x[index]-old))
            before=after
    rows=[]
    for name,lo,hi in definitions:
        for metric,values in effects[name].items():
            rows.append({'parameter':name,'range_low':lo,'range_high':hi,'metric':metric,'mu':statistics.mean(values),'mu_star':statistics.mean(abs(v) for v in values),'sigma':statistics.stdev(values) if len(values)>1 else 0,'trajectories':trajectories,'interpretation':'Elementary effects over assumed normalized parameter ranges; reference scenario only, not field uncertainty/probability.'})
    return rows,runs

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',type=Path,default=ROOT/'config/model_v2.json')
    p.add_argument('--output',type=Path,default=ROOT/'outputs/v2')
    p.add_argument('--suite',choices=['full','quick'],default='full')
    p.add_argument('--samples',type=int,default=4)
    p.add_argument('--morris-trajectories',type=int,default=4)
    args=p.parse_args()
    if args.samples<0 or args.morris_trajectories<0: p.error('Counts must be nonnegative')
    cfg=json.loads(args.config.read_text(encoding='utf-8'));forcing=Forcing(ROOT)
    selected={w['label']:forcing.select(w['label'],cfg['observation_hours']) for w in forcing.windows}
    first=forcing.windows[0]['label'];runs=[]
    cases=SCENARIOS if args.suite=='full' else [s for s in SCENARIOS if s[0] in ('reference','outer_outage','compound')]
    variants=VARIANTS if args.suite=='full' else [v for v in VARIANTS if v['id'] in ('three_off','outer_off','three_assist','three_zero','three_adverse')]
    for scenario,_ in cases:
        for variant in variants:
            detail=scenario=='reference' or variant['id']=='three_off'
            r=simulate(cfg,selected[first],scenario,variant['id'],cfg['seed'],detail)
            runs.append(r)
        print('Scenario completed:',scenario,flush=True)
    if args.suite=='full':
        for label,f in selected.items():
            if label==first: continue
            for v in VARIANTS: runs.append(simulate(cfg,f,'reference',v['id'],cfg['seed'],v['id']=='three_off'))
            print('Environmental window completed:',label,flush=True)
    uncertainty=[]
    for sample in range(args.samples):
        rng=random.Random(cfg['seed']+sample+1000);c=copy.deepcopy(cfg)
        c['external_rate_kg_h']*=rng.uniform(0.7,1.4)
        common=rng.uniform(-0.15,0.05)
        for b in c['bands']:
            b['intercept_probability']=max(0,min(1,b['intercept_probability']+common))
            b['collector_rate_kg_h']*=rng.uniform(0.7,1.2)
        for s in ['reference','outer_outage','compound']:
            for v in ['three_off','three_assist']:
                r=simulate(c,selected[first],s,v,cfg['seed']+1000+sample)
                uncertainty.append(summarize(r)|{'sample':sample})
        print('Uncalibrated ensemble completed:',sample+1,flush=True)
    screening,screen_runs=(morris(cfg,selected[first],args.morris_trajectories,cfg['seed']+5000) if args.morris_trajectories else ([],[]))
    resources=[]
    for count in [1,2,3]:
        c=copy.deepcopy(cfg);c['vessel']['count']=count
        for s in ['reference','outer_outage','release_closed']:
            r=simulate(c,selected[first],s,'three_off',cfg['seed'])
            resources.append(summarize(r)|{'vessel_count':count})
    output=args.output;output.mkdir(parents=True,exist_ok=True)
    payload={'version':'0.2','built_at_utc':datetime.now(timezone.utc).isoformat(),'disclaimer':DISCLAIMER,'config':cfg,'scenarios':[{'id':i,'label':label} for i,label in cases],'variants':variants,'windows':forcing.windows,'runs':runs,'uncalibrated_ensemble':uncertainty,'morris':screening,'resource_sweep':resources,'evidence':EVIDENCE,'run_counts':{'representative':len(runs),'ensemble':len(uncertainty),'morris':len(screen_runs),'resource_sweep':len(resources)},'config_sha256':hashlib.sha256(args.config.read_bytes()).hexdigest()}
    dump(output/'results.json',payload)
    csv_write(output/'scenario_summary.csv',[summarize(r) for r in runs])
    csv_write(output/'ensemble.csv',uncertainty);csv_write(output/'morris_screening.csv',screening);csv_write(output/'morris_runs.csv',screen_runs);csv_write(output/'vessel_capacity_sweep.csv',resources)
    csv_write(output/'gap_register.csv',[{'window':r['window'],'scenario':r['scenario'],'variant':r['variant'],'seed':r['seed'],**g} for r in runs for g in r['gaps']])
    csv_write(output/'evidence_gaps.csv',EVIDENCE)
    timeline=[];trips=[];lifecycle=[]
    for r in runs:
        identity={k:r[k] for k in ['window','scenario','variant','seed']}
        for point in r['series']:
            row=identity|{k:v for k,v in point.items() if k not in ('bands','boats')}
            for b in point['bands']:
                row.update({b['name']+'_'+k:v for k,v in b.items() if k!='name'})
            row['vessel_states']='; '.join(f"V{b['id']+1}:{b['state']}:{b['cargo_kg']:.3f}kg" for b in point['boats'])
            timeline.append(row)
        trips.extend(identity|{k:v for k,v in trip.items() if k!='phases'}|{'phases':json.dumps(trip['phases'],separators=(',',':'))} for trip in r['trips'])
        lifecycle.extend(identity|e for e in r['lifecycle'])
    csv_write(output/'timelines.csv',timeline);csv_write(output/'vessel_trips.csv',trips);csv_write(output/'lifecycle_events.csv',lifecycle)
    # Single-file offline report. Large detailed lifecycle audit remains in CSV/JSON.
    browser_payload=copy.deepcopy(payload)
    for r in browser_payload['runs']: r.pop('lifecycle',None)
    data=json.dumps(browser_payload,ensure_ascii=False,allow_nan=False,separators=(',',':')).replace('</','<\\/')
    template=(Path(__file__).parent/'dashboard.html').read_text(encoding='utf-8')
    css=(Path(__file__).parent/'dashboard.css').read_text(encoding='utf-8');js=(Path(__file__).parent/'dashboard.js').read_text(encoding='utf-8')
    (output/'report.html').write_text(template.replace('__STYLE__',css).replace('__DATA__',data).replace('__SCRIPT__',js),encoding='utf-8')
    write_notes(output,payload)
    print(json.dumps({'output':str(output.resolve()),'cases':payload['run_counts'],'max_mass_error_kg':max(r['summary']['max_accounting_error_kg'] for r in runs)},indent=2),flush=True)

def write_notes(output,payload):
    first=payload['windows'][0]['label'];lookup={(r['scenario'],r['variant']):r for r in payload['runs'] if r['window']==first}
    lines=['# MARLIN simulation v0.2 — actual run report','',DISCLAIMER,'',f"Completed runs: {payload['run_counts']}. Seed: {payload['config']['seed']}.",'','## Initial-window mechanical reference','', '| Scenario | Beyond inner kg (%) | Still held kg | Unknown domain exit kg | Net release account kg | Oldest holding min |', '|---|---:|---:|---:|---:|---:|']
    for s,_ in SCENARIOS:
        if (s,'three_off') not in lookup: continue
        a=lookup[s,'three_off']['summary']
        lines.append(f"| {s} | {a['residual_kg']:.1f} ({a['residual_percent']:.2f}%) | {a['held_kg']:.1f} | {a['unknown_domain_exit_kg']:.1f} | {a['net_released_kg']:.1f} | {a['oldest_holding_minutes']:.1f} |")
    lines+=['','## Bubble comparison in the reference scenario','','| Variant | Beyond inner % | Unknown domain exit % | Still held kg | Bubble kWh | Total kWh |','|---|---:|---:|---:|---:|---:|']
    for v in VARIANTS:
        if ('reference',v['id']) not in lookup: continue
        a=lookup['reference',v['id']]['summary']
        lines.append(f"| {v['label']} | {a['residual_percent']:.2f} | {a['unknown_exit_percent']:.2f} | {a['held_kg']:.1f} | {a['bubble_kwh']:.1f} | {a['total_kwh']:.1f} |")
    lines+=['','## Interpretation and remaining work','',
      '- Initial 4-hour synthetic bloom arrivals; 8-hour observation horizon. Biomass density is assumed, not derived from weather.',
      '- Wind, waves and surface-current records now drive illustrative forcing/availability. Quarterly cases use the first 8 hours of their selected week; high-wave/current cases choose the strongest mean 8-hour interval inside the selected week. These are not observed bloom events or certified extremes.',
      '- Local flow adds a prescribed intakeward component to projected regional velocity; transverse velocity is scaled by 0.15. The 360 × 120 m domain and all three lines are invented engineering scenarios, not ENEC geometry. Sea level is inspected but not a hydraulic boundary solution; GEBCO does not resolve this channel.',
      '- Particles represent weighted cohorts. RK2 advection and assumed along-guide motion are illustrative. This is not bubble CFD, pressure-drop, net-deformation or animal-swimming validation.',
      '- Guide interception, collector receipt, vessel transfer and hypothetical release are separate. Unknown domain exits and retained catch are never counted as successful removal. Net released account includes scheduled future returns beyond the finite horizon and says nothing about survival.',
      '- Sensor truth is hidden from controllers. Detection probabilities, biases, latency and optical obstruction are assumed; no real detector or tracking model is trained.',
      '- Vessels are finite scheduled resources. Phase durations include service pauses; payload stability, navigation, safe storm responses, collision avoidance and actual docking are not modeled.',
      '- Monetary rates are missing, so AED cost is null. Reported electricity/staffing are partial assumed quantities and exclude installation, maintenance, recovery, embodied cost and handling equipment not specified.',
      '- Morris screening is a four-level elementary-effects exercise over declared assumed parameter ranges in the reference case; its ranking is conditional on those ranges and sampled trajectories. Sobol analysis is not implemented.',
      '- Representative cases use matched forcing/load seeds. Outer-only comparison has less installed hardware; coordination comparison uses the same hardware. Synthetic ensemble frequencies do not estimate field success probability.',
      '- Runtime mass/capacity checks are executed as part of simulation. No separate unit-test suite, UI test suite, or physical validation was run for v0.2.',
      '- Native regional grids, local hydraulics, real perception, ecological handling and approved operating/release arrangements remain future work.',
      '',f"Maximum representative per-step accounting discrepancy: {max(r['summary']['max_accounting_error_kg'] for r in payload['runs']):.4g} kg.",
      '', 'See `gap_register.csv` for scenario-triggered findings and `evidence_gaps.csv` for unresolved evidence. A numerical run does not close an engineering risk.']
    (output/'RUN_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

if __name__=='__main__': main()
