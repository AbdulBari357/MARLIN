'use strict';
const model=JSON.parse(document.getElementById('model-data').textContent);
const $=id=>document.getElementById(id), colors=['#127f8c','#a36b11','#785193'];
const fmt=(v,d=1)=>v==null?'Unavailable':Number(v).toLocaleString('en',{minimumFractionDigits:d,maximumFractionDigits:d});
const title=s=>String(s).replaceAll('_',' ').replace(/^\w/,c=>c.toUpperCase());
const scenarioLabels=Object.fromEntries(model.scenarios.map(s=>[s.id,s.label]));
const variantLabels=Object.fromEntries(model.variants.map(s=>[s.id,s.label]));
const windowLabels={quarter_1_first_complete_week:'January seasonal window',quarter_2_first_complete_week:'April seasonal window',quarter_3_first_complete_week:'July seasonal window',quarter_4_first_complete_week:'October seasonal window',high_wave_week:'High-wave window',high_current_week:'High-current window'};
let run=null,playing=false,lastTick=0,animation=0;
function el(tag,text,cls){const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;}
function options(select,values,label){const previous=select.value;select.replaceChildren();for(const value of values){const o=el('option',label(value));o.value=value;select.append(o);}if(values.includes(previous))select.value=previous;}
function unique(values){return [...new Set(values)];}
function stop(){playing=false;cancelAnimationFrame(animation);$('play').textContent='Play';}
function selectRun(){
 stop();
 const window=$('window').value;
 options($('scenario'),unique(model.runs.filter(r=>r.window===window).map(r=>r.scenario)),s=>scenarioLabels[s]||title(s));
 options($('variant'),unique(model.runs.filter(r=>r.window===window&&r.scenario===$('scenario').value).map(r=>r.variant)),s=>variantLabels[s]);
 run=model.runs.find(r=>r.window===window&&r.scenario===$('scenario').value&&r.variant===$('variant').value);
 $('time').max=run.series.length-1;$('time').value=Math.min(30,run.series.length-1);
 $('horizon').textContent=`${model.config.observation_hours} hours observed; ${model.config.arrival_hours} hours of assumed arrivals`;
 const start=new Date(run.forcing.interval_start_utc);const end=new Date(start.getTime()+run.forcing.used_hours*3600000);
 $('interval').textContent=`${scenarioLabels[run.scenario]} · ${start.toISOString().slice(0,16).replace('T',' ')} to ${end.toISOString().slice(0,16).replace('T',' ')} UTC. Regional environmental records; bloom loading is synthetic.`;
 renderSummary();renderComparisons();renderGaps();renderProvenance();renderTime();
}
function current(){return run.series[Number($('time').value)];}
function renderSummary(){
 const s=run.summary;const strip=$('account-strip');strip.replaceChildren();
 for(const[label,value,note]of [['Initial biomass',s.external_kg,'Unique external input'],['Beyond inner',s.residual_kg,`${fmt(s.residual_percent,2)}% of initial biomass`],['Still held',s.held_kg,'Guided, queued, received or onboard'],['Unknown exit',s.unknown_domain_exit_kg,'Destination outside domain unresolved'],['Net release account',s.net_released_kg,'Hypothetical releases minus returned mass']]){
  const n=el('div',null,'account-item');n.append(el('span',label),el('b',`${fmt(value,0)} kg`),el('small',note));strip.append(n);
 }
 $('account-note').textContent=`Free in domain at end: ${fmt(s.free_kg,0)} kg. Returned: ${fmt(s.returned_kg,0)} kg. Pending assumed returns: ${fmt(s.pending_return_kg,0)} kg. Oldest holding proxy: ${fmt(s.oldest_holding_minutes,0)} min. No animal-survival estimate. Maximum accounting discrepancy: ${Number(s.max_accounting_error_kg).toExponential(1)} kg.`;
 $('trip-count').textContent=`${s.completed_trips} completed / ${s.dispatched_trips} dispatched trips`;
}
function renderTime(){
 const point=current();$('clock').textContent=`${Math.floor(point.minute/60)}h ${String(Math.round(point.minute%60)).padStart(2,'0')}m`;
 const bubble=$('bubble-status');bubble.textContent=point.bubble_active?'Experimental bubbles active':'Bubbles off';bubble.className=`pill ${point.bubble_active?'on':'off'}`;
 const ledger=$('band-ledger');ledger.replaceChildren();
 point.bands.forEach((b,i)=>{
  const spec=model.config.bands[i];const row=el('div',null,'band-row');row.style.setProperty('--c',colors[i]);
  const h=el('h3');h.append(el('span',title(b.name),'band-title'),el('span',title(b.state),`state ${b.state}`));row.append(h);
  const nums=el('div',null,'band-numbers');
  for(const[label,value]of [['True arrivals',`${fmt(b.true_flux_kg_h,0)} kg/h`],['Observed',b.observed_flux_kg_h==null?'Missing / disabled':`${fmt(b.observed_flux_kg_h,0)} kg/h`],['Guided + queued',`${fmt(b.guided_kg+b.queued_kg,0)} kg`],['Receiver',`${fmt(b.receiver_kg,0)} kg`]]){
   const item=el('div',label);item.append(el('b',value));nums.append(item);
  }row.append(nums);
  for(const[k,capacity,cls,label]of [[b.guided_kg+b.queued_kg,spec.capture_load_limit_kg,'','Capture-load limit'],[b.receiver_kg,spec.receiver_capacity_kg,'receiving','Receiver capacity']]){
   const track=el('div',null,`meter ${cls}`);track.title=`${label}: ${fmt(k,1)} / ${capacity} kg`;const fill=el('span');fill.style.width=`${Math.min(100,100*k/capacity)}%`;track.append(fill);row.append(track);
  }ledger.append(row);
 });
 $('environment').textContent=`Regional wave: ${fmt(point.wave_height_m,2)} m. Wind: ${fmt(point.wind_m_s,1)} m/s. Surface current magnitude: ${fmt(point.regional_current_m_s,3)} m/s. Prescribed local x velocity: ${fmt(point.local_u_m_s,3)} m/s.`;
 const boats=$('boat-ledger');boats.replaceChildren();
 for(const boat of point.boats){const row=el('div',null,'boat-entry');row.append(el('strong',`Vessel ${boat.id+1}`),el('span',title(boat.state)),el('span',boat.band==null?'At service base':`${title(model.config.bands[boat.band].name)} assignment`),el('span',`${fmt(boat.cargo_kg,0)} kg onboard`));boats.append(row);}
 drawScene();drawFlux();drawTrips();
}
function drawScene(){
 const canvas=$('scene'),ctx=canvas.getContext('2d'),ratio=window.devicePixelRatio||1;
 const w=canvas.clientWidth,h=canvas.clientHeight;canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);ctx.scale(ratio,ratio);
 const g=model.config.geometry,point=current();const left=27,top=40,width=w-54,height=Math.min(width*g.width_m/g.length_m,h-145);
 const X=x=>left+x/g.length_m*width,Y=y=>top+y/g.width_m*height;
 ctx.fillStyle='#e8f4f7';ctx.fillRect(0,0,w,h);ctx.fillStyle='#f9fdfe';ctx.fillRect(left,top,width,height);ctx.strokeStyle='#c9e0e7';ctx.strokeRect(left,top,width,height);
 ctx.font='12px "Segoe UI",sans-serif';ctx.fillStyle='#365a6d';ctx.fillText(`Assumed ${g.length_m} m × ${g.width_m} m domain; not a site map`,left,21);
 ctx.save();ctx.strokeStyle='#d9e9ee';ctx.lineWidth=1;
 for(let x=60;x<g.length_m;x+=60){ctx.beginPath();ctx.moveTo(X(x),top);ctx.lineTo(X(x),top+height);ctx.stroke();}
 for(let y=30;y<g.width_m;y+=30){ctx.beginPath();ctx.moveTo(left,Y(y));ctx.lineTo(left+width,Y(y));ctx.stroke();}ctx.restore();
 const direction=point.local_u_m_s>=0?1:-1;
 ctx.strokeStyle='#aeced9';ctx.lineWidth=1.6;
 for(let x=35;x<g.length_m-20;x+=60){for(let y=30;y<g.width_m;y+=40){const px=X(x),py=Y(y);ctx.beginPath();ctx.moveTo(px-10*direction,py);ctx.lineTo(px+10*direction,py);ctx.lineTo(px+6*direction,py-3);ctx.moveTo(px+10*direction,py);ctx.lineTo(px+6*direction,py+3);ctx.stroke();}}
 model.config.bands.forEach((b,i)=>{
  const active=point.bands[i].state!=='disabled';ctx.strokeStyle=active?colors[i]:'#a7bdc6';ctx.lineWidth=active?4:2;ctx.setLineDash(active?[]:[4,4]);
  ctx.beginPath();ctx.moveTo(X(b.start[0]),Y(b.start[1]));ctx.lineTo(X(b.end[0]),Y(b.end[1]));ctx.stroke();ctx.setLineDash([]);
  ctx.fillStyle=active?colors[i]:'#a7bdc6';ctx.fillRect(X(b.end[0])-9,Y(b.end[1])-4,18,11);
  ctx.fillStyle='#254c60';ctx.font='11px "Segoe UI",sans-serif';ctx.fillText(title(b.name),X(b.start[0])-16,top-8);
  if(i===0&&point.bubble_active){ctx.strokeStyle='#76c3d0';ctx.fillStyle='#f9fdfe';ctx.lineWidth=1;
   for(let j=0;j<18;j++){const f=j/18,bx=b.start[0]+(b.end[0]-b.start[0])*f-8,by=b.start[1]+(b.end[1]-b.start[1])*f;ctx.beginPath();ctx.arc(X(bx),Y(by),2+(j%3)*0.6,0,Math.PI*2);ctx.fill();ctx.stroke();}
  }
 });
 ctx.strokeStyle='#b8403a';ctx.lineWidth=2;ctx.setLineDash([4,3]);ctx.beginPath();ctx.moveTo(X(g.length_m),top);ctx.lineTo(X(g.length_m),top+height);ctx.stroke();ctx.setLineDash([]);
 ctx.fillStyle='#395d6f';ctx.font='10px "Segoe UI",sans-serif';ctx.fillText('Source',left,top+height+20);ctx.textAlign='right';ctx.fillText('Beyond inner boundary',left+width,top+height+20);ctx.textAlign='left';
 const frame=run.frames.length?run.frames[Number($('time').value)]:null;
 if(frame){for(const[id,x,y,band,kg,depth]of frame.particles){ctx.beginPath();ctx.arc(X(x),Y(y),band<0?3:3.5,0,Math.PI*2);ctx.fillStyle=band<0?'#3597b1':colors[band];ctx.strokeStyle=band<0?'#5c93a7':colors[band];if(depth){ctx.fillStyle='#fff';ctx.fill();ctx.stroke();}else ctx.fill();}}
 const base=[15,g.width_m+35],release=[70,g.width_m+35];
 ctx.strokeStyle='#a7c4cf';ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(X(base[0]),Y(base[1]));ctx.lineTo(X(release[0]),Y(release[1]));ctx.stroke();ctx.setLineDash([]);
 ctx.fillStyle='#536a75';ctx.font='10px "Segoe UI",sans-serif';ctx.fillText('Service base',X(base[0]),Y(base[1])+19);ctx.fillText('Hypothetical release resource',X(release[0])+9,Y(release[1])+4);
 point.boats.forEach(boat=>{
  let position=base;if(boat.band!=null){const b=model.config.bands[boat.band],end=b.end;let a=base,z=end,total=model.config.vessel.pickup_travel_minutes_by_band[boat.band];
   if(boat.state==='loading'){a=end;z=end;total=1;}
   if(boat.state==='release_travel'){a=end;z=release;total=model.config.vessel.release_travel_minutes;}
   if(boat.state==='unloading'){a=release;z=release;total=1;}
   if(boat.state==='return'){a=release;z=base;total=model.config.vessel.return_minutes;}
   const progress=Math.max(0,Math.min(1,1-boat.remaining_minutes/total));position=[a[0]+(z[0]-a[0])*progress,a[1]+(z[1]-a[1])*progress];
  }
  const x=X(position[0])+boat.id*7,y=Y(position[1]);ctx.fillStyle='#17394e';ctx.beginPath();ctx.moveTo(x+6,y);ctx.lineTo(x,y-4);ctx.lineTo(x-6,y);ctx.lineTo(x,y+4);ctx.closePath();ctx.fill();ctx.font='9px "Segoe UI",sans-serif';ctx.fillText(`V${boat.id+1}`,x-5,y-8);
 });
 $('frame-note').textContent=frame?`Showing ${frame.displayed_cohorts} of ${frame.live_cohorts} moving cohorts at this time. Each dot carries variable biomass; dot size is not jellyfish size. Guided cohorts move toward their band's dedicated collector.`:'Particle frames were not stored for this comparison. Inventory and sensor timelines are available; select the three-band bubbles-off configuration to inspect trajectories.';
}
const NS='http://www.w3.org/2000/svg';
function svgNode(svg,name,attributes,text){const n=document.createElementNS(NS,name);for(const[k,v]of Object.entries(attributes))n.setAttribute(k,v);if(text!=null)n.textContent=text;svg.append(n);return n;}
function chartBase(id){const svg=$(id),w=Math.max(svg.clientWidth,300),h=220;svg.replaceChildren();svg.setAttribute('viewBox',`0 0 ${w} ${h}`);return{svg,w,h};}
function drawFlux(){
 const{svg,w,h}=chartBase('flux-chart'),index=Number($('sensor-band').value),points=run.series,left=51,right=15,top=23,bottom=31;
 const maximum=Math.max(100,...points.flatMap(p=>[p.bands[index].true_flux_kg_h,p.bands[index].observed_flux_kg_h||0]))*1.08;
 const X=t=>left+t/(model.config.observation_hours*60)*(w-left-right),Y=v=>h-bottom-v/maximum*(h-top-bottom);
 svgNode(svg,'title',{},`Simulator truth and emulated ${model.config.bands[index].name} observations`);
 for(let i=0;i<=3;i++){const v=maximum*i/3;svgNode(svg,'line',{x1:left,x2:w-right,y1:Y(v),y2:Y(v),stroke:'#dbe7ec'});svgNode(svg,'text',{x:left-8,y:Y(v)+3,'text-anchor':'end','font-size':10,fill:'#536a75'},fmt(v,0));}
 for(let hour=0;hour<=model.config.observation_hours;hour+=2)svgNode(svg,'text',{x:X(hour*60),y:h-10,'text-anchor':'middle','font-size':10,fill:'#536a75'},`${hour}h`);
 svgNode(svg,'text',{x:left,y:13,'font-size':10,fill:'#536a75'},'kg/hour');
 for(const[key,color,dash]of [['true_flux_kg_h','#17394e',''],['observed_flux_kg_h','#3597b1','4 2']]){
  let group=[];const flush=()=>{if(group.length)svgNode(svg,'polyline',{points:group.join(' '),fill:'none',stroke:color,'stroke-width':2,'stroke-dasharray':dash});group=[];};
  for(const p of points){const v=p.bands[index][key];if(v==null){flush();continue;}group.push(`${X(p.minute)},${Y(v)}`);}flush();
 }
 svgNode(svg,'line',{x1:X(current().minute),x2:X(current().minute),y1:top,y2:h-bottom,stroke:'#b07515','stroke-dasharray':'2 3'});
}
function drawTrips(){
 const{svg,w}=chartBase('trip-chart'),left=66,right=15,width=w-left-right;const X=t=>left+t/(model.config.observation_hours*60)*width;
 const palette={pickup_travel:'#96c9d9',loading:'#d9b878',release_travel:'#548ea5',unloading:'#6fa494',return:'#bed8e2'};
 for(let boat=0;boat<model.config.vessel.count;boat++){const y=40+boat*62;svgNode(svg,'text',{x:7,y:y+16,'font-size':11,fill:'#365a6d'},`Vessel ${boat+1}`);svgNode(svg,'rect',{x:left,y,width,height:25,fill:'#eef5f7'});
  for(const trip of run.trips.filter(t=>t.boat===boat)){trip.phases.forEach((phase,i)=>{if(phase.state==='idle')return;const end=trip.phases[i+1]?.minute??trip.completed_minute??model.config.observation_hours*60;
   const rect=svgNode(svg,'rect',{x:X(phase.minute),y,width:Math.max(.8,X(end)-X(phase.minute)),height:25,fill:palette[phase.state]||'#9eb9c6',stroke:'white','stroke-width':.6});const t=document.createElementNS(NS,'title');t.textContent=`${title(phase.state)} ${fmt(phase.minute,0)}–${fmt(end,0)} min; ${trip.band}; ${fmt(trip.loaded_kg,0)} kg loaded`;rect.append(t);
  });}
 }
 for(let hour=0;hour<=model.config.observation_hours;hour+=2)svgNode(svg,'text',{x:X(hour*60),y:194,'text-anchor':'middle','font-size':10,fill:'#536a75'},`${hour}h`);
 svgNode(svg,'line',{x1:X(current().minute),x2:X(current().minute),y1:26,y2:177,stroke:'#b07515','stroke-dasharray':'2 3'});
 svgNode(svg,'text',{x:left,y:215,'font-size':10,fill:'#536a75'},'Travel → load → release transit → unload → return');
}
function comparisonRows(){return model.runs.filter(r=>r.window===run.window&&r.scenario===run.scenario);}
function renderComparisons(){
 const body=$('comparisons').querySelector('tbody');body.replaceChildren();
 for(const r of comparisonRows()){
  const tr=el('tr');if(r.variant===run.variant)tr.className='selected';const td=el('td');const button=el('button',variantLabels[r.variant],'table-button');button.type='button';button.onclick=()=>{$('variant').value=r.variant;selectRun();};td.append(button);tr.append(td);
  const s=r.summary;for(const v of [`${fmt(s.residual_percent,2)}%`,`${fmt(s.unknown_exit_percent,2)}%`,`${fmt(s.held_kg,0)} kg`,`${fmt(s.net_released_kg,0)} kg`,`${fmt(s.bubble_kwh,1)} kWh`,`${fmt(s.total_kwh,1)} kWh`])tr.append(el('td',v,'number'));body.append(tr);
 }
}
function renderGaps(){
 const body=$('gap-table').querySelector('tbody');body.replaceChildren();
 for(const g of run.gaps){const row=el('tr'),first=el('td'),button=el('button',`${fmt(g.first_minute,0)} min`,'time-link');button.type='button';button.onclick=()=>{stop();let closest=0;for(let i=1;i<run.series.length;i++)if(Math.abs(run.series[i].minute-g.first_minute)<Math.abs(run.series[closest].minute-g.first_minute))closest=i;$('time').value=closest;renderTime();$('scene').scrollIntoView({block:'center'});};first.append(button);row.append(first,el('td',title(g.band)),el('td',g.meaning),el('td',g.response));body.append(row);}
 if(!run.gaps.length){const row=el('tr'),td=el('td','No scenario flags in this run. Physical and ecological evidence gaps remain open.','empty');td.colSpan=4;row.append(td);body.append(row);}
}
function renderProvenance(){const box=$('provenance');box.replaceChildren();
 box.append(el('p',run.forcing.mapping));
 for(const[name,source]of Object.entries(run.forcing.sources))box.append(el('p',`${title(name)}: point ${source.point_id}, ${source.latitude}° N / ${source.longitude}° E. ${source.path}. SHA-256 ${source.sha256}.`));
 for(const[name,value]of Object.entries(run.assumptions))box.append(el('p',`${title(name)}: ${value}.`));
 box.append(el('p',`Configuration SHA-256: ${model.config_sha256}. Seed: ${run.seed}. Guide/contact parameters, weather limits, holding threshold and energy powers are scenario assumptions. Monetary rates are missing. Each cohort has an assumed initial weight of ${model.config.cohort_kg} kg; animal-equivalent conversion assumes ${model.config.assumed_individual_mass_kg} kg per animal.`));
}
function renderResearch(){
 const names={external_rate_kg_h:'Arrival biomass rate',outer_intercept_probability:'Outer interception assumption',vessel_payload_kg:'Vessel payload',guide_transport_m_s:'Along-guide transport speed'};
 const rows=model.morris.filter(r=>r.metric==='residual_percent').sort((a,b)=>b.mu_star-a.mu_star);const max=Math.max(1,...rows.map(r=>r.mu_star));
 $('morris').replaceChildren();for(const r of rows){const row=el('div',null,'sensitivity-row'),heading=el('div');heading.append(el('span',names[r.parameter]||title(r.parameter)),el('span',`${fmt(r.mu_star,2)} pp`));const track=el('div',null,'sensitivity-track'),bar=el('span');bar.style.width=`${r.mu_star/max*100}%`;track.append(bar);row.append(heading,track,el('span',`Assumed range ${r.range_low}–${r.range_high}; ${r.trajectories} trajectories`,'caption'));$('morris').append(row);}
 if(!rows.length)$('morris').append(el('p','Morris screening was not included in this run.','caption'));
 $('ensemble-note').textContent=`${model.uncalibrated_ensemble.length} additional seeded runs vary arrival, shared interception and collection assumptions. These are scenario samples, not field reliability probabilities. Sobol analysis is not implemented.`;
 const body=$('resources').querySelector('tbody');body.replaceChildren();for(const r of model.resource_sweep){const tr=el('tr');for(const v of [String(r.vessel_count),scenarioLabels[r.scenario]||title(r.scenario),`${fmt(r.residual_percent,2)}%`,`${fmt(r.held_kg,0)} kg`,`${fmt(r.oldest_holding_minutes,0)} min`])tr.append(el('td',v));body.append(tr);}
 const ledger=$('evidence-ledger');ledger.replaceChildren();for(const e of model.evidence){const d=el('div',null,'evidence-item');d.append(el('h3',e.area),el('span',title(e.status.toLowerCase()),'evidence-status'),el('p',e.needed,'caption'));ledger.append(d);}
}
function downloadCSV(filename,rows){if(!rows.length)return;const keys=unique(rows.flatMap(r=>Object.keys(r)));const quote=v=>'"'+String(v??'').replaceAll('"','""')+'"';const text=[keys.map(quote).join(','),...rows.map(r=>keys.map(k=>quote(r[k])).join(','))].join('\r\n');const url=URL.createObjectURL(new Blob([text],{type:'text/csv;charset=utf-8'}));const link=el('a');link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('window').addEventListener('change',selectRun);$('scenario').addEventListener('change',selectRun);$('variant').addEventListener('change',selectRun);$('time').addEventListener('input',()=>{stop();renderTime();});$('sensor-band').addEventListener('change',drawFlux);
$('export-comparison').onclick=()=>downloadCSV('marlin-comparison.csv',comparisonRows().map(r=>({window:r.window,scenario:r.scenario,variant:r.variant,...r.summary})));
$('export-gaps').onclick=()=>downloadCSV('marlin-findings.csv',run.gaps);
function tick(timestamp){if(!playing)return;if(timestamp-lastTick>350){lastTick=timestamp;if(Number($('time').value)>=run.series.length-1){stop();return;}$('time').value=Number($('time').value)+1;renderTime();}animation=requestAnimationFrame(tick);}
$('play').onclick=()=>{if(playing){stop();return;}if(Number($('time').value)>=run.series.length-1)$('time').value=0;playing=true;lastTick=0;$('play').textContent='Pause';animation=requestAnimationFrame(tick);};
let resizeTimer;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(renderTime,100);});
$('run-count').textContent=`${model.run_counts.representative} representative runs; ${Object.values(model.run_counts).reduce((a,b)=>a+b,0)} total calculations`;
$('built-date').textContent=new Intl.DateTimeFormat('en',{dateStyle:'medium',timeZone:'Asia/Kolkata'}).format(new Date(model.built_at_utc));
options($('window'),unique(model.runs.map(r=>r.window)),w=>windowLabels[w]||title(w));selectRun();renderResearch();
