"""Run the current two-layer, sensor-triggered bubble screening scenarios.

This is a scenario-model experiment, not trained ML, field validation or a
production control system. See the generated run report before interpreting it.
"""
import copy
import csv
import json
from pathlib import Path

from engine import DISCLAIMER, SCENARIOS, VARIANTS, simulate
from forcing import Forcing

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / 'config/model_two_layer_triggered.json'
OUTPUT = ROOT / 'outputs/v2/current-two-layer'

OFF = 'two_off'
POS = 'two_trigger_positive'
ZERO = 'two_trigger_zero'
ADVERSE = 'two_trigger_adverse'
OPTICAL = 'two_trigger_optical'
ALWAYS = 'two_always_positive'

CASES = {
    'reference': [OFF, ALWAYS, POS, ZERO, ADVERSE, OPTICAL],
    'overload': [OFF, POS, ADVERSE],
    'surge': [OFF, POS, ADVERSE],
    'outer_outage': [OFF, POS, ADVERSE],
    'sensor_blind': [OFF, POS],
    'false_alarms': [OFF, POS],
    'outer_false_alarm': [OFF, POS],
    'reversal': [OFF, POS],
    'storm': [OFF, POS, ADVERSE],
    'compound': [OFF, POS, ADVERSE],
}


def csv_write(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    forcing = Forcing(ROOT)
    window = forcing.windows[0]['label']
    flow = forcing.select(window, cfg['observation_hours'])
    variants = {item['id']: item for item in VARIANTS}
    scenarios = dict(SCENARIOS)
    records = []
    raw_runs = []

    for scenario, variant_ids in CASES.items():
        for variant_id in variant_ids:
            run_cfg = copy.deepcopy(cfg)
            if scenario == 'outer_false_alarm':
                # Detector-only false-alarm stress test: no actual bloom input.
                run_cfg['external_rate_kg_h'] = 0
            result = simulate(run_cfg, flow, scenario, variant_id, cfg['seed'], detail=True)
            summary = result['summary']
            first_activation = min((e['minute'] for e in result['events'] if e['code'] == 'bubble_activated'), default=None)
            first_outer_interception = min((e['minute'] for e in result['lifecycle'] if e['band'] == 'outer' and e['event'] == 'intercepted'), default=None)
            activation_lead = None if first_activation is None or first_outer_interception is None else round(first_outer_interception - first_activation, 2)
            bands = {band['name']: band for band in result['bands']}
            records.append({
                'scenario': scenario,
                'scenario_label': scenarios.get(scenario, scenario),
                'variant': variant_id,
                'variant_label': variants[variant_id]['label'],
                'external_kg': round(summary['external_kg'], 3),
                'outer_intercepted_kg': round(bands.get('outer', {}).get('intercepted_kg', 0), 3),
                'second_intercepted_kg': round(bands.get('second', {}).get('intercepted_kg', 0), 3),
                'beyond_second_kg': round(summary['residual_kg'], 3),
                'beyond_second_percent': round(summary['residual_percent'], 3),
                'unknown_domain_exit_kg': round(summary['unknown_domain_exit_kg'], 3),
                'unknown_domain_exit_percent': round(summary['unknown_exit_percent'], 3),
                'held_kg': round(summary['held_kg'], 3),
                'net_released_kg': round(summary['net_released_kg'], 3),
                'bubble_kwh': round(summary['bubble_kwh'], 3),
                'bubble_active_minutes': round(summary['bubble_active_minutes'], 2),
                'bubble_duty_percent': round(summary['bubble_duty_percent'], 3),
                'bubble_activation_count': summary['bubble_activation_count'],
                'first_bubble_command_minute': first_activation,
                'first_outer_interception_minute': first_outer_interception,
                'activation_lead_to_first_outer_capture_minutes': activation_lead,
                'total_kwh': round(summary['total_kwh'], 3),
                'max_accounting_error_kg': summary['max_accounting_error_kg'],
                'gap_codes': '; '.join(sorted({gap['code'] for gap in result['gaps']})),
            })
            raw_runs.append(result)
        print(f"Completed {scenario}", flush=True)

    OUTPUT.mkdir(parents=True, exist_ok=True)
    csv_write(OUTPUT / 'scenario_summary.csv', records)
    payload = {
        'model': 'MARLIN two-layer, sensor-triggered bubble screening experiment',
        'disclaimer': DISCLAIMER,
        'config': cfg,
        'window': flow.metadata(),
        'case_variants': CASES,
        'runs': raw_runs,
    }
    (OUTPUT / 'results.json').write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(',', ':')), encoding='utf-8')

    by_key = {(r['scenario'], r['variant']): r for r in records}
    reference_ids = [OFF, ALWAYS, POS, ZERO, ADVERSE, OPTICAL]
    lines = [
        '# MARLIN current two-layer simulation — triggered-bubble screening',
        '',
        '**Interpretation status: illustrative conditional model only.** It uses regional forcing and assumed local geometry, bloom load, sensor performance, capture efficiencies and bubble effects. The “triggered” controller is a threshold-and-persistence proxy, not a trained ML model.',
        '',
        f"Forcing window: `{window}`. Synthetic bloom: {cfg['external_rate_kg_h']} kg/h for {cfg['arrival_hours']} h; observation horizon: {cfg['observation_hours']} h. The outer detector is placed {cfg['sensor']['approach_lookahead_m']} m upstream of the outer guide in the schematic model. Trigger, persistence, delay and weather limits are unvalidated assumptions.",
        '',
        '## Reference case',
        '',
        '| Bubble policy | Beyond second layer (%) | Unknown domain exit (%) | Held (kg) | Bubble energy (kWh) | Active time (min) | Activations | First activation → outer capture (min) |',
        '|---|---:|---:|---:|---:|---:|---:|---:|',
    ]
    for variant_id in reference_ids:
        r = by_key[('reference', variant_id)]
        lead = '—' if r['activation_lead_to_first_outer_capture_minutes'] is None else str(r['activation_lead_to_first_outer_capture_minutes'])
        lines.append(f"| {variants[variant_id]['label']} | {r['beyond_second_percent']:.2f} | {r['unknown_domain_exit_percent']:.2f} | {r['held_kg']:.1f} | {r['bubble_kwh']:.1f} | {r['bubble_active_minutes']:.1f} | {r['bubble_activation_count']} | {lead} |")
    lines += ['', '## Stress cases: bubble off vs detected-bloom activation', '', '| Scenario | Variant | Beyond second (%) | Held (kg) | Bubble energy (kWh) | Active time (min) | Gaps flagged |', '|---|---|---:|---:|---:|---:|---|']
    for scenario in [key for key in CASES if key != 'reference']:
        for variant_id in CASES[scenario]:
            if variant_id not in (OFF, POS, ADVERSE):
                continue
            r = by_key[(scenario, variant_id)]
            lines.append(f"| {r['scenario_label']} | {variants[variant_id]['label']} | {r['beyond_second_percent']:.2f} | {r['held_kg']:.1f} | {r['bubble_kwh']:.1f} | {r['bubble_active_minutes']:.1f} | {r['gap_codes'] or 'none'} |")
    lines += [
        '',
        '## What this run can and cannot establish',
        '',
        '- It can compare internal behavior of this simplified model: two sequential guides, upstream detector lead, thresholded bubble start/stop, environmental interlocks, two residual-recovery sensors and a finite capture/transport lifecycle.',
        '- It cannot establish a field capture percentage, ML accuracy, physical bubble lift/deflection, hydraulic intake impact, bycatch, jellyfish welfare, validated energy savings or Barakah operating reliability.',
        '- The positive, zero-effect, adverse-effect and optical-interference bubble branches are sensitivity cases, not measured probabilities. The bubble-effect speed terms are assumed and do not solve bubble-fluid mechanics.',
        '- Public wind/wave/current data are regional point forcing. They do not supply channel-scale flow or local jellyfish biomass. Unknown exits are not counted as successful removal; held catch and hypothetical release remain separate.',
        '- A low bubble duty cycle supports an energy-saving hypothesis only for the assumed detector, threshold and bloom timing. The result must be retested against missed detections, false alarms, lead-time distributions and measured site conditions.',
        '',
        'Maximum mass-accounting discrepancy across runs: ' + f"{max(r['max_accounting_error_kg'] for r in records):.3e} kg.",
        '',
        'See `scenario_summary.csv` for all run metrics and `results.json` for the full time series and lifecycle events.',
    ]
    (OUTPUT / 'RUN_REPORT.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'output': str(OUTPUT.resolve()), 'runs': len(records), 'max_mass_error_kg': max(r['max_accounting_error_kg'] for r in records)}, indent=2))


if __name__ == '__main__':
    main()
