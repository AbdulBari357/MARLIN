# Dashboard design direction

Subject: a marine interception simulation for the MARLIN engineering team. Primary task: follow catch and explain failure causes, rather than display an unexplained success score.

Palette: deep marine blue #123b50, shallow-water blue #e8f4f7, outer teal #127f8c, middle amber #a36b11, inner purple #785193, failure red #b8403a. White carries the report background; colors encode bands and flags, not ranking or certification.

Type: Bahnschrift for the MARLIN wordmark on Windows, Segoe UI/system sans-serif for readable content and tabular numbers. No remote fonts or dependencies.

Layout: the large schematic is the focal element, with three band ledgers beside it. Below: sensing comparison, vessel phases, paired outcomes and findings. Controls stay above the diagram; explicit evidence/assumptions stay visible and expandable. All content is left aligned except numeric columns.

Review against brief: three sequential colored guides are meaningful architecture, not decoration. A map tile would imply site accuracy the model lacks, so use an explicitly assumed channel schematic. Avoid a generic collection of KPI cards; show lifecycle totals as one accounting strip, including unknown domain exits and held catch. Play is user-triggered. Provide focus states, mobile stacking, readable contrast, empty-state explanations and offline exports.
