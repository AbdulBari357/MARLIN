# MARLIN public research data

This repository copy contains selected processed 2024 regional wind, wave, and surface-current tables; candidate environmental windows; missing-interval records; and acquisition metadata. Consult [DATA_REPORT.md](DATA_REPORT.md) for coverage, provenance, caveats, and licensing notes, and [../docs/PUBLIC_DATA_PLAN.md](../docs/PUBLIC_DATA_PLAN.md) for provider sources and retrieval steps.

The large raw-data ZIP, downloaded jellyfish image files, and NetCDF source subsets are not in this repository. The available public samples are not ENEC operating data, do not establish local intake hydraulics, and do not provide ground-truth jellyfish biomass or validated capture performance. The v4 screening runs use explicit scenario assumptions rather than claiming trained computer vision or field-calibrated environmental forcing.
