# MARLIN public-data acquisition report

Reviewed 11 October 2026. Initial research collection; not a calibrated or validated site model.

## Actual downloaded data

| Source | Files/coverage acquired | Intended use | Limits |
|---|---|---|---|
| ERA5 wind via Open-Meteo | Three points, all 8,784 UTC hours of 2024; wind speed/direction and pressure; raw JSON and CSV | Seasonal/weather forcing and vessel interruption scenarios | Provider-processed point subset, approximately 0.25-degree native grid; no local wind validation |
| ERA5-Ocean waves via Open-Meteo | Three points, all 8,784 hourly slots of 2024; height/direction/period; raw JSON and CSV | Rough/calm conditions and optional bubble trial scenarios | Approximately 0.5-degree native grid; hourly output is not proof of hourly native information; no bubble-effectiveness measurement |
| SMOC currents/sea level via Open-Meteo | Three points, 8,784 slots of 2024; 96 missing hours per current variable per point, 168 per sea-level point | Surface current direction/speed and regional water-level forcing | Missing intervals preserved. Approximately 1/12-degree native grid. Cannot reconstruct three-dimensional channel flow from three points |
| GEBCO_2025 elevation and matching TID | Two 480 × 720 NetCDF subsets, 23–25° N / 51–54° E, native 15-arc-second spacing | Regional domain depth and source provenance | Roughly 400–460 m spacing; not navigation, anchors or intake survey data |
| GBIF Catostylus mosaicus photo records | 1,420 occurrence records, 2,688 media candidates | Traceable image candidates and species context | Original records/media licences differ; occurrence licence does not automatically licence image |
| GBIF linked species photographs | 100 image files; 100 unique file hashes; 60 occurrence groups | Initial species-image annotation exercise | Not yet an expert-labelled detector dataset; {'AU': 100} geography is unlike local deployment |
| OBIS species occurrence query | 4,769 global records; 1 in broad Gulf/adjacent bounding box | Biological context and review of species evidence | No abundance/bloom time series; regional record has quality flags described below |
| FathomNet | 115 returned metadata/annotation entries across queries; 114 unique identifiers | Supplemental underwater object and non-target annotation review | Image assets have NOT been downloaded; queries may overlap; exact Catostylus mosaicus query returned zero |

Point indices identify different returned grid locations for each source. These are not three coincident observation stations. Exact request/returned coordinates, units, source URLs, retrieval dates and SHA-256 hashes are in `manifest.json`. Downloads and file checks do not establish physical accuracy.

## Checks and findings

- Verified 123 unique manifest artifacts against recorded hashes and byte counts; 198.5 MB of original/derived artifacts.
- All environmental timestamps are contiguous, unique UTC hours for 2024. Wind/waves have no missing values for the requested variables.
- 8,520 hours have all requested values at all three points across all three products. Missing values remain blank in CSV; they are never converted to calm water or zero current. See `processed/missing_intervals.csv`.
- Wind direction is meteorological FROM; wind components use the negative sine/cosine convention. SMOC direction is TO; raw velocity in km/h is converted to m/s for east/north components. Raw units remain intact.
- SMOC includes tidal/wave contributions as documented by the provider; do not blindly add separate Stokes drift to the same current convention.
- GEBCO marine cells: 129,240. TID marine counts: 16: 23,318 (optical light sensor depth measurement), 17: 24,193 (combined direct measurements), 40: 1,911 (gravity-guided prediction/interpolation), 41: 79,585 (algorithmic interpolation), 43: 201 (ENC contours), 44: 32 (mixed measured/derived gridded sources). These classifications are source types, not uncertainty bounds. No local dredged-channel geometry is established.
- Six complete seven-day windows are selected reproducibly in `processed/environment_windows.json`: one per quarter plus high-mean-wave and high-mean-current windows at each product's point 0. They are candidate forcing scenarios, NOT recorded blooms or certified worst cases.
- Images decode successfully and have retained per-image attribution/licence. Split images by occurrence/source/deployment, never randomly across repeated photographs of one occurrence. Expert identity and box annotation review remain pending.
- FathomNet query counts: {'Catostylus mosaicus': 0, 'Chrysaora': 13, 'Chrysaora fuscescens': 50, 'Scyphozoa': 2, 'Sebastes': 50}. Counts are bounded returned subsets, not full catalogue totals or independent samples.
- The one regional OBIS return is a 2019 Dubai citizen-science observation, with `ON_LAND` and `NO_DEPTH` flags and a CC BY-NC licence. It is not reliable evidence of a bloom at Barakah. Retain it for review; do not use it to calibrate bloom density. Global GBIF/OBIS records can overlap.
- HYCOM metadata was retrieved, but its regional field download stalled. No HYCOM current dataset is included. An alternative public SMOC point subset was acquired.

## Prepared, not downloaded

`pending_copernicus_requests.json` and `../simulation/prepare_copernicus.py` prepare bounded 2024 requests for GLORYS depth-dependent physics, native SMOC regional hourly currents and WAVERYS waves/Stokes drift. These require free sign-in and catalogue/variable checks. Native grid downloads remain necessary before a defensible regional particle-transport experiment; additional local hydraulics remains unresolved even then. Reanalysis/current products sharing sources are not independent validation observations.

## Integration status

The current MARLIN operations model still uses synthetic arrivals, capture efficiencies and fault assumptions. These downloads are NOT already driving it. Next: obtain native grids → inspect masks/depth/time/velocity conventions → build regional transport plus explicitly assumed local boundary scenarios → derive arrival flux → feed operations model → compare designs and faults. Report assumed jellyfish buoyancy/swimming/size, vertical distribution and mass conversion separately. Public data do not measure guide-net collection, bubble deflection, bycatch or survival.

## Source documentation and terms

- [Open-Meteo historical weather](https://open-meteo.com/en/docs/historical-weather-api) and [marine documentation](https://open-meteo.com/en/docs/marine-weather-api): processed environmental data, attribution and API use limits. Retain ECMWF/Copernicus and Meteo-France attribution. Free API use is for non-commercial research; review production terms.
- [GEBCO_2025 and TID code definitions](https://www.gebco.net/data-products-gridded-bathymetry-data/gebco2025-grid); cite GEBCO Compilation Group (2025), doi:10.5285/37c52e96-24ea-67ce-e063-7086abc05f29. Public domain with acknowledgement; not navigation data.
- [GBIF media guidance](https://techdocs.gbif.org/en/openapi/images), [OBIS access](https://portal.obis.org/data/access/) and [FathomNet terms](https://www.fathomnet.org/terms). Preserve original dataset/asset citations. This research package has mixed licences, not one blanket commercial licence.
- [GLORYS](https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_PHY_001_030/services), [native SMOC](https://data.marine.copernicus.eu/product/GLOBAL_ANALYSISFORECAST_PHY_001_024/services), [WAVERYS](https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_WAV_001_032/services).

## Reproduce

From the project root, use the local research interpreter:

```powershell
marlin-development/.venv-data/Scripts/python.exe marlin-development/simulation/acquire_public_data.py wind waves smoc bathymetry tid biology imagery
marlin-development/.venv-data/Scripts/python.exe marlin-development/simulation/inspect_public_data.py
marlin-development/.venv-data/Scripts/python.exe marlin-development/simulation/prepare_copernicus.py --month 1
```

The last command is a dry run. Actual account-dependent retrieval is a separate step. Re-running acquisition uses cached environmental/GBIF/OBIS responses; external catalogues and imagery may change.
