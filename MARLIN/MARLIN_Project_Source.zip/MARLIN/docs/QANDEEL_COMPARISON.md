# MARLIN and Qandeel: comparison protocol

The reviewed Qandeel pipeline describes a Python prediction simulation using public ocean/wind forcing, proposed bubble interception, proposed uncrewed herding/transport, and later camera/control development. Its document discloses that the hardware and camera/boat control are not operationally demonstrated. The source PDF is the team's supplied reference; it has not been altered.

MARLIN v0.2 now adds regional public forcing, illustrative 2D cohort movement, angled-guide encounters, finite collector/receiver and vessel-trip accounting, sensor-error scenarios, bubble-effect branches, matched baseline runs and triggered evidence gaps to the v0.1 operations model. This improves the scope of model-based comparison; it is not proof that MARLIN outperforms Qandeel in nature.

| Dimension | Current position | Next evidence |
|---|---|---|
| Geographic forcing and arrival prediction | Qandeel's document describes more specific prediction machinery; MARLIN v0.2 uses regional surface records with an assumed local-flow component and synthetic bloom arrivals. | Validate local forcing and develop a response-planning interface without duplicating the existing warning function. |
| Finite collection/receiving/logistics | MARLIN explicitly models three local collectors, finite buffers and shared transfer capacity. | Measured capacities and realistic vessel turnaround. |
| Leakage-triggered reserve response | MARLIN models local observations, activation delay and faults. | Bench-tested sensors/actuators and measured downstream response. |
| Marine welfare | Both remain unvalidated for proposed high-volume handling. | Comparable approved handling and survival trials. |
| Hydraulic effect | MARLIN v0.2 still does not compute intake-channel hydraulics; Qandeel's site-specific estimates cannot validate MARLIN. | Appropriate hydraulic model and measurements. |
| Energy/cost | MARLIN electricity is partial and synthetic; monetary fields await quotations. | Comparable full-event and lifecycle accounting. |
| Novelty | Three nets, bubbles and automatic recovery already have published precedent. | Explain and substantiate a differentiated control/handling contribution; no legal novelty conclusion. |
| Production readiness | Neither is established as operational hardware by the available evidence. | Authorized pilot and engineering/environmental review. |

Use the same incoming loads, depths, sea states, durations and residual threshold. Account for installed redundancy, operator work, capital, vessel availability, fuel, compressor power, damage, return after release and unprocessed catch. Publish uncertainty and failure conditions. A paired outer-only baseline isolates the contribution of MARLIN's reserve stages; it does not represent Qandeel's complete design.
