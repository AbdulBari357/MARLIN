# MARLIN engineering specification v0.1

## 1. Purpose and design boundary

Develop sustainable management after an existing early-warning notification. The reference architecture is external marine interception and handling equipment with three distinct response stages. Exact siting is unresolved; satellite imagery does not establish channel function, water depth, operating flow, mooring suitability, navigation rights, or an approved release route.

No instruction in this package authorizes installation, plant-system modification, live-animal trials, or equipment operation. ENEC operational/environmental requirements and relevant permissions must determine the design envelope.

The objective is to reduce measured jellyfish load reaching the existing protection while maintaining acceptable water-flow effects, marine welfare, handling capacity and maintenance effort. These constraints must be agreed before optimization. A capture percentage alone is not the objective.

## 2. Full process architecture

```mermaid
flowchart LR
  A[Existing early warning] --> C[Supervised response coordinator]
  O[Outer guide and capture pockets] --> OC[Dedicated outer wet collector]
  OC --> OR[Outer receiving modules]
  O -->|Measured escape| M[Middle reserve guide and capture pockets]
  M --> MC[Dedicated middle wet collector]
  MC --> MR[Middle receiving modules]
  M -->|Measured residual| I[Inner residual interception module]
  I --> IC[Dedicated inner wet collector]
  IC --> IR[Inner receiving modules]
  I -->|Uncaptured residual| S[Existing protection and operator escalation]
  OR --> T[Supervised transport and receiving-module exchange]
  MR --> T
  IR --> T
  T --> R[Approved release with assessed return risk]
  C -.-> O
  C -.-> M
  C -.-> I
  R --> V[Monitoring and model correction]
```

**Each band can collect independently. Shared transport remains an explicit dependency.** Local storage only absorbs bounded surges; it cannot replace sustained transport/release capacity.

## 3. Outer band: main load management

### Proposed hardware

- Segmented angled guide modules sized through hydraulic and mooring analysis.
- Capture pockets serving dedicated collector modules, with independent loading measurements.
- First collector prototype: slow soft-pocket wet transfer mechanism. Geometry, contact pressure, residence time and unloading interface are unresolved until welfare tests.
- Alternating water-filled receiving modules with controlled exchange and handling access.
- Bubble assist as an optional, condition-specific mode; mechanical guidance and collection are the reference model's core. No compressor or bubble efficacy is assumed in the first simulator.

### Duties and measurements

Guide the principal arriving load, continuously unload retained jellyfish, estimate residual flux, and report available receiving/transport capacity. Record inlet/outlet flux estimates, uncertainty, direction/depth observations, net loading, collector performance and receiving occupancy.

### Operating limits

Do not continue accumulating biomass when handling space or animal conditions are unacceptable. Derating capture can increase downstream load: reserve response and operator escalation must accompany it. A design that protects net loading by sending all animals downstream has not solved clearance.

## 4. Middle band: recovery and maintenance reserve

### What physically happens to escaped jellyfish

1. Depth-aware upstream observations estimate the incoming escape stream and its uncertainty.
2. Previously prepared guide segments lead intercepted animals laterally into a local capture pocket. The pocket is a short transfer location, not a long-term holding net.
3. A dedicated middle collector transfers them to its own wet receiving module.
4. The receiving module enters the same supervised logistics plan as outer-band modules, while preserving sufficient reserve receiving space.
5. Transport takes the catch to an approved marine release procedure; the middle band does not discharge into the flow leading toward the inner band.

These are proposed physical functions. The lateral transport, avoidance of pinning/entanglement, depth coverage, and wet-transfer survival require testing. No arbitrary angle, mesh, speed, depth or full-scale throughput is prescribed here.

### Activation

Prepare after early warning. Activate on persistent local residual flux; outer collector fault; outer saturation; planned primary maintenance; or a supervisor command permitted by the local controller. Local sensing can initiate response without a working inter-band network. Do not assume instant deployment after first detection.

Let the credible travel time between the detection region and collection region exceed sensing latency + decision latency + mechanical readiness time + agreed margin. Determine this with local currents and biological transport uncertainty. Fixed illustrative delays in the simulation are not valid siting distances.

### Capacity and availability

Size for the measured residual distribution and explicitly declared outer-stage interruption duration. If it cannot temporarily manage the full arriving load, quantify its reduced-service envelope; do not claim full primary redundancy. Dedicated collection and receiving prevent a single primary collector jam disabling both stages. Shared towing/transport, common moorings or common power routes still need separate consideration.

## 5. Inner band: independent residual extraction

### Proposed module

Prototype a compact sectional moving capture surface transferring animals into a dedicated wet receiver, operated with local loading limits and a supervised stop. Its full-scale form depends on acceptable approach flow and ecological tests. It must be located within an approved external marine boundary; existing plant equipment is not modified by this concept.

Mesh is selected for the target organism and ecological consequences. Progressively finer nets are not a default prescription: fine mesh may add restriction and capture smaller organisms. Depth and side coverage must be tested with net deformation and local flow.

### What happens to the final residuals

Intercepted animals are continuously transferred from the capture module to the local wet receiver and then to supervised transport. **No routine local dump, wash-back toward the intake, grinding, or unvalidated suction transfer is assumed.** Uncaptured residuals are measured where feasible and passed to the existing approved site response; their fate cannot be claimed as solved by this package.

### Independence

Provide local control, an independently assessed alarm/power arrangement, separate receiving availability, and operator access. Readiness persists throughout the bloom response. An inner collection failure triggers escalation even if the network says the outer stage is healthy. New local observation can override a stale supervisor estimate.

## 6. Transport, wet handling and release

Alternate receiving modules only where stability, lifting/towing loads, water exchange, secure couplings, biosecurity, navigation and welfare have been assessed. Keep associated non-target animals in the handling assessment. Define maximum crowding and holding time through ecological work, not the simulation defaults.

For sustained conditions, the bottleneck is the smallest of safe collection, receiving turnover, transport and permitted release rates. For a brief surge, required additional storage is the integral of the excess rate over the relevant duration; reserve capacity must include uncertainty and water-quality limits. A finite receiver cannot accommodate an indefinite closure of the release route.

Release permissions and current observations govern transport. Assess risk of re-entry over a declared horizon; drift forecasts require validation. Neither a fixed compass direction nor a fixed offshore distance is a sufficient release rule. Release near warm discharge, sensitive habitats or a different ecological community requires assessment. Reject unassessed routes; report the consequences of delayed release rather than silently holding indefinitely.

Direct current-assisted diversion is an optional later mode. It needs a verified outward route with acceptable return risk and no harmful flow effects. It is not implemented in the first operations model.

## 7. Control states and interlocks

| State | Entry | Equipment intent | Exit / unresolved case |
|---|---|---|---|
| Standby | No active alert | Service and baseline monitoring | Existing warning initiates prepare |
| Prepared | Active warning | Verify local sensors, mechanical readiness and receiving/transport slots | Readiness confirmed or unavailable escalation |
| Intercept | Observed arrivals or approved early deployment | Guide and collect within confirmed limits | Low arrival hysteresis, overload or fault |
| Derated | Loading/receiving/welfare limit approached | Limit new accumulation while clearing existing load where allowed | Reserve capacity available or escalate |
| Reserve active | Upstream escape/fault/approved servicing | Dedicated local capture and unload | Confirmed recovery with hysteresis |
| Maintenance pending | Service requested | Verify local low load, downstream readiness, free receiving space and logistics | Permit, defer, or cancel |
| Fault / ecological hold | Jam, severe conditions, uncertain animal, invalid sensing | Site-specific safe response and human review | Verified recovery; no blind automatic restart |
| Release pending | Received live catch | Observe holding limits and secure transport | Approved release or explicit capacity/welfare escalation |
| Recovery | Bloom ending | Clear bounded residuals, inspect, log, service | Accounted catch and approved return to standby |

A universal "fail open" is inappropriate: releasing a loaded net may create a downstream surge. A universal "fail closed" may worsen blockage and welfare. Safe configurations require joint hydraulic, mechanical and operator decisions for each fault. Do not open a loaded section solely because a software queue threshold is exceeded.

The first operations simulator represents a limited subset: readiness delays, local reserve activation, simple loading/receiving derating, collector faults, shared logistics closure, and maintenance refusal. It is not an implementation of every state or physical interlock.

## 8. Sensing, AI and communications

Use an appropriately tested combination of camera/sonar, current/depth observations, and physical loading measurements. Their sensing volumes differ; calibration must link local counts/density to transport through a measured cross section. Timestamp readings; report field of view, blind regions, uncertainty, missed detections and drift. A two-dimensional image count is not automatically a whole-channel flux estimate.

AI classifies observed objects and estimates local abundance. Physics and operational constraints inform decisions. A conventional local controller validates commands. Unknown animals, poor visibility and sensor disagreement must be explicit states; do not label them as zero jellyfish. No trained detector is included in this package.

Signal schema: `timestamp_utc`, `band_id`, `sequence`, `sensor_health`, `flux_estimate_kg_h`, `flux_uncertainty`, `depth_coverage`, `class_confidence`, `net_load`, `collector_state`, `receiving_occupancy`, `oldest_hold_minutes`, `water_quality`, `release_slot_status`, `command_ack`, `operator_override`. Some fields may remain unknown; they must not be replaced with reassuring zeros.

Use authenticated commands, bounded setpoints, stale-message rejection, event logs and physical operator controls. Supervisor failure must not defeat local protection. Cybersecurity and software assurance require a separate review before field use.

## 9. Work allocation

| Role | Required outputs |
|---|---|
| Ecologist / jellyfish specialist | Species confirmation; bycatch/associated-fish survey; welfare protocol; receiving/transport limits; release and monitoring plan |
| Hydraulic/coastal engineer | Local forcing and depth; combined-barrier hydraulic effects; blocked/deformed cases; mooring conditions; release-return assessment |
| Mechanical engineer | Collector mechanism; safe contact/transfer tests; capacities; jam recovery; receiver exchange; loads and serviceability |
| AI engineer | Labelled local data; held-out conditions; detection/flux calibration; uncertainty and sensor-health behavior |
| Controls/robotics engineer | State machine; independent local response; interlocks; communications fault handling; maintenance permit logic |
| Operations/cost lead | Staffing; sustained turnover; service times; spare strategy; vessel availability; quotations and lifecycle cost |
| ENEC / relevant contacts | Permitted boundary; operating limits; approved response and release interfaces; pilot requirements |

## 10. Acceptance requirements still open

Assign numeric limits only after obtaining appropriate evidence: acceptable downstream residual flux; acceptable hydraulic impact; operating sea-state/load envelope; sustained clearing rate; non-target contact and survival outcomes; maximum handling duration; communication availability; degraded-service duration; energy and staff effort; release-return risk over a specified horizon.

Physical band functionality, acceptable animal outcomes and readiness for production are not established by a successful software run. See the risk register and validation plan for the evidence gates.
