# Validation and deployment gates

**All gates below are pending. Software verification is distinct from physical validation. No test in this package certifies the system for live animals, an ENEC intake, or production.**

## Gate 1 — boundaries, observations and requirements

Confirm target species and ranges; bathymetry and channel functions; representative current/depth/wave conditions; biomass flux; non-target animals; maintenance access; mooring constraints; navigation and environmental requirements; authorized release conditions; acceptable effect on water flow. Request clarification through appropriate contacts; do not infer these from map colors or public dimensions of another channel.

Outputs: signed-off design boundary, parameter evidence register, quantitative acceptance limits, and a baseline response description. Until available, labelled illustrative assumptions are acceptable for a concept submission.

## Gate 2 — operations-model verification

Verify conservation, bounded storage, no negative mass, delayed arrivals, actuator and observation separation, refused unsafe maintenance, release closure, re-entry accounting, overflow exposure and reproducibility. Review simplifications. Run paired outer-only/three-band trials. Halve the timestep and review any material changes. Remaining mass must be reported at the end of every run.

Passing proves software accounting/logic properties only. It does not validate illustrative capacities or survival.

## Gate 3 — hydraulic and mechanical prototypes without animals

Use jellyfish-shaped compliant surrogates in a controlled flume. Surrogates are not proof of biological behavior. Test different sizes/buoyancy/compliance/depths, cross-flow, waves, reversals, debris, partial blockage, guide deformation and collector jams. Measure approach velocity, water-level/pressure difference, structural loads, escaped surrogate flux and sustained collected rate.

Test each band independently and the entire cascade. Test collector changeover; downstream response latency; outer outage; all collector outages; communications loss; simulated unknown-animal stop; receiver unavailable; and maintenance refusal. Confirm that actual safe configurations do not create unacceptable flow restriction or dump a dangerous surge downstream.

Determine statistical replication from observed variance and the engineering decision; do not select a token trial count to imply reliability. Preserve runs, calibration records, failures and photos/video.

## Gate 4 — ecological handling review and approved trials

With appropriate expert review and authorization, assess contact/abrasion, bell and oral-arm injury, stress indicators suited to the species, post-handling survival over a specified follow-up, feeding/pulsation recovery, crowding, water exchange and storage time. Include relevant non-target organisms and associated juvenile fish; no automatic sorting claim without evidence. Test soft-pocket collector options against an appropriate minimally handled reference.

Stop criteria and adverse outcomes must be defined in advance. Do not conclude that an animal is unharmed simply because it was released or continued pulsating immediately after handling.

## Gate 5 — sensing and local controls

Build a labelled local dataset spanning day/night, turbidity, bubbles, dense clusters, fouling and debris. Test on held-out events/conditions. Quantify missed detections, false alarms, depth blind zones and conversion of observations to flux, with uncertainty.

Bench test stale data, wrong timestamps, sensor blindness, drift, packet loss, malicious/out-of-range command rejection, controller restarts, lost power, local override and disagreement. Check that missing data is not converted to zero arrivals. Test actual actuator response, braking, limits and acknowledgement.

## Gate 6 — authorized limited field pilot

Demonstrate one safe handling module first in a permitted environment. Verify hydraulic effects and catch outcomes. Expand to coordinated reserve response only after review. Validate movement/release assumptions with suitable observations and track return over a stated period. Account for animals left in storage and biomass with unknown fate.

Record event-level staffing, energy, towing/transport, failures, fouling, retrieval effort, maintenance and quotations. Model lifecycle cost rather than excluding expensive offshore work.

## Gate 7 — deployment decision

Require engineering/environmental acceptance of the actual operating envelope, transport availability, loss-of-capacity responses, maintenance and incident arrangements, ownership, cybersecurity and independent review appropriate to the installation. Unresolved critical issues block a production claim. No production deployment is part of this package.

## Comparison protocol

Compare agreed baselines under matched forcing, biomass distribution and duration. Show residual biomass/flux, unresolved held mass, animal outcomes, hydraulic effects, staff effort, total energy, availability, infrastructure footprint and lifecycle cost. If comparing Qandeel, obtain its parameter/code definitions or clearly label any approximate reproduction. Do not present a bubble-only baseline as a full implementation of Qandeel.
