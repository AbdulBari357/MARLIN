# MARLIN simulation v0.2 — implementation record and remaining evidence

Prepared 11 October 2026. The v0.2 research simulator is implemented in `simulation/v2/`; its actual run artifacts are in `outputs/v2/full/`. This is an illustrative, uncalibrated scenario model, not production software or a field-performance result. The implementation does not include a trained detector, equipment controller, bubble-fluid solver, local hydraulic model, animal-welfare model, or autonomous navigation.

## Implemented in v0.2

- Reads the prepared regional wind, wave, and surface-current records into six explicitly selected environmental windows. The point data do not resolve local intake-channel flow or jellyfish abundance.
- Moves weighted 2D cohorts with midpoint RK2 and segment-based angled-guide encounters through an invented domain and assumed local-flow component.
- Accounts separately for guided/captured material, finite collectors and receiving modules, vessel payload/trips, hypothetical releases and returns, inner-boundary residuals, and unknown exits.
- Emulates noisy, delayed, missing, biased, and false sensor observations; uses limited local readiness/coordination logic and exposes relevant faults as scenario gaps.
- Compares three bands with an outer-only reference, local-control operation, and bubble-off, assumed-benefit, zero-benefit, adverse-effect, and optical-obstruction branches.
- Runs scripted overload, surge, equipment/logistics/sensor/network faults, current reversal, storm, bypass, debris, handling pause, guide escape, and high-return scenarios, plus uncalibrated ensemble and Morris screens.
- Produces an offline dashboard, run report, scenario/uncertainty tables, sensitivity records, vessel-capacity sweep, and lifecycle/gap registers. Runtime mass and capacity accounting checks are part of each simulation run; they are not a separate verification suite.

The implementation ledger is not a validation claim. See the actual result report and `evidence_gaps.csv` for assumptions and unresolved evidence. No model result closes a physical or ecological risk.

## Original intended scope and remaining boundaries

The planned core is now implemented: an auditable Python simulation of three bands with dedicated collectors/receivers, explicit vessel trips, noisy observations, limited local controls and a separate truth record; an illustrative two-dimensional particle view; regional forcing scenarios; and optional outer bubble branches compared with bubbles off, zero benefit and adverse effects. The actual implementation and outputs are listed above. The plan still describes intended methods and limits, not independently validated performance.

No fourth band, autonomous animal release approval, production installation geometry or trained Gulf detector is established by v0.2. These would need separate evidence and design decisions.

## Algorithm catalogue and boundaries

| Task | Proposed algorithm | Reason and implementation boundary |
|---|---|---|
| Public data ingestion | UTC alignment, mask/coverage checks, unit/direction conversion, explicit scenario selection | Reuse inspected files and six complete weekly windows. Missing values are not zero current; interpolation is not improved physical resolution. Do not interpolate three disparate source points into a supposedly resolved channel field. |
| Particle movement | Second-order Runge–Kutta midpoint advection; optional random-walk dispersion with increments proportional to sqrt(2 K dt) | Lightweight and inspectable for an illustrative 2D field. Diffusivity and biological behavior remain scenario assumptions. Substep movement and intersect entire motion segments with barriers so particles cannot jump through a band undetected. |
| Regional drift, later | OpenDrift OceanDrift with native ocean fields and an explicitly selected integration scheme | Requires native grids, masks, depth/time conventions and configured biology. OpenDrift is a trajectory framework, not a local hydraulic solver or an automatic jellyfish model. Do not copy a generic wind-drift factor into this species. |
| Guide-net interaction | Motion-segment intersection with angled segments; along-guide transport and separate bypass/pinning/escape scenarios | Geometry supplies a proposed diversion path. Sliding/retention and maximum loads are uncalibrated mechanism assumptions, not solved fluid/contact physics. Side/depth bypass must remain represented. Do not teleport intercepted animals into a receiver. |
| Collection and storage | Finite queues with dedicated service resources and chronological holding-age accounting | Extend existing v0.1 logic. Arrival, interception, collection, receiver transfer and release are separate events. Full receivers and stalled collectors cause consequences rather than disappearing mass. |
| Band coordination | Finite-state machines, persistence/hysteresis, timestamped alerts and local fallback | Local readiness and alarms survive unavailable inter-band messages. Use observed rather than hidden true flux. AI does not override interlocks or approve release. Do not set production thresholds without calibration. |
| Vessel logistics | Explicit trips and finite resources; urgency based on time to fullness and holding deadline | Model payload, transit, handling/docking, unloading/release availability and weather delays separately. Count staff and recovery costs. Initial routes/permissions are scenario inputs; no autonomous navigation is implied. |
| AI perception, initially | Separate observation emulator for misses, false alarms, bias, occlusion, latency and common sensor failure | The simulator knows truth; the controller does not. These error assumptions are not measured detector accuracy. Track confidence and sensor disagreement; a simulation cannot invent a trained AI system. |
| Detector and tracking, later | Evaluate an official RT-DETR implementation as a candidate; Kalman prediction and gated Hungarian association as a tracking baseline | Requires reviewed target/non-target boxes and representative videos. Re-identification after occlusion and dense-bloom counting remain uncertain. Do not use artificial simulation IDs as evidence that cameras can track every animal across three bands. |
| Uncertainty and gap discovery | Seeded scenario ensembles, parameter sweeps, Morris screening; Sobol analysis only with suitable sampling/assumptions | Rank which uncertainties dominate outcomes. Keep common faults and shared parameters correlated where appropriate. Standard independent-input Sobol indices should not be applied blindly to dependent variables. Simulated sample frequencies are not field reliability probabilities. |
| Design comparison | Matched forcing/load/fault seeds and multi-objective tradeoff tables | Compare inner leakage, completed release, unresolved holdings, energy, staffing and quoted cost. Do not select a design solely for low leakage if it traps animals indefinitely or has unresolved flow/welfare constraints. |

Start with the explicit local controller and queue/logistics model. Model predictive control, reinforcement learning, robotic fleets and automatic animal sorting are not necessary for the first useful comparison; they should be added only against a demonstrated limitation and measured evidence.

## Flow and geometry evidence levels

### Level A: initial public-data scenario model

Available: three regional 2024 point extracts per environmental product, GEBCO/TID regional grids, species image seeds and occurrence context. These support scenario selection and an explicitly simplified flow illustration. The returned points differ between products; they are not three coincident instrument stations. Maintain scenario cases for flow direction, reversals, local speed scaling, side/depth bypass and transport interruption. Do not label any inferred channel flow as observed at Barakah.

An idealised flow illustration can use prescribed currents and reversal/recirculation scenarios. It cannot compute intake suction, breakwater effects, net-induced flow restriction, turbulence from bubbles, mooring loads or a definitive offshore release route. Report unknown local conditions prominently, not only in a footnote.

### Level B: regional native-field transport

Prepared but not downloaded: native SMOC hourly currents, GLORYS depth-dependent physics, WAVERYS waves/Stokes drift. After acquisition and metadata checks, use native water masks and regional transport fields. Check whether velocities already include wave/tide contributions before adding Stokes drift. Track assumed jellyfish depth/buoyancy/swimming separately from water transport. This remains regional transport, not local barrier hydraulics.

### Level C: local engineering and ecological evidence

Needs appropriate local geometry/flow evidence, hydraulic/structural analysis, collector prototypes and ecological trials. Missing information should remain an evidence gap even when numerical results look favorable. A particle animation and queue occupancy cannot establish safe pressure drop, animal survival, bycatch clearance or real boat navigation.

## Bubble-curtain decision

**Include an optional, segmented outer-band bubble assist. Keep the primary reference with bubbles off.** The middle and inner stages retain their own mechanical collection and do not rely on bubbles in the first design comparison.

An angled guide plus local collector remains the proposed primary mechanism. A bubble curtain produces a water plume and can affect trajectories; it is not a solid wall or a proven fear/repulsion response. A 2021 field/flume study found variable effects across conditions and jellyfish types. It does not establish adult Catostylus mosaicus performance at ENEC.

First simulation branches:

1. Bubbles off: mechanical reference.
2. Experimental bubble effect: clearly assumed deflection/advection parameters and compressor consumption.
3. Zero incremental benefit: compressor consumes energy while transport remains unchanged.
4. Adverse effect: more passage or problematic accumulation/contact in selected scenarios.
5. Equipment/sensing interactions: compressor unavailable; bubbles obstruct the chosen optical sensor; common rough-water degradation.

Do not assign a fixed percentage improvement or infer performance from wave height alone. More air need not mean better exclusion. Operating bounds, air delivery, diffuser depth/spacing and species-specific response require trials. Until those bounds exist, the real controller cannot be described as ready to enable bubbles automatically. A simulated experimental branch is not equipment authorization.

Bubble fluid mechanics and physical animal effects are excluded from the first prototype. Its parameters should be swept to establish how much *measured* incremental benefit would justify the energy/cost and extra failure modes. Production acceptance requires adequate mechanical-only performance under its agreed degraded envelope.

## Marine animals and lifecycle accounting

Each band: guide/intercept → capture pocket → finite wet collector → its receiver → supervised transfer/transport → approved release arrangement. Model captures that escape before collection and catch that remains held. Do not discharge middle/inner catch next to the intake as successful release.

Track weighted virtual cohorts/particles explicitly. Distinguish unique initial biomass from repeated arrivals and handling after return. Particle-number weights and the assumed body-mass conversion must be recorded separately. Tag particle/cohort status: free, guided, queued, received, in transport, released, returned, passed inner boundary, stranded/unknown. A simulated identity is a truth identifier, not a camera tracking achievement.

Include non-target encounter and handling-pause scenarios. Holding/crowding deadlines must be assumptions pending biological approval. Simulated contact, age and workload indicators are evidence to investigate, not calculated mortality rates. Never count a retained animal as safely released.

## How simulation will identify gaps

| Gap | Experiment or indicator | What remains outside this simulator |
|---|---|---|
| Middle/inner cannot recover outer failure | Outer outage across arrival-load and outage-duration sweeps; receiver saturation; inner passage | Measured collector throughput and approved degraded operating envelope |
| Diversion still leaves side/depth gaps | Different guide geometry, flow directions, reversals and explicit bypass classes | Surveyed depths, net deformation and species depth distribution |
| Shared transport overwhelms all bands | Finite trips, blocked release, docking delays and vessel outage | Real transfer time, payload stability, handling protocol and permitted release arrangements |
| More interception causes dangerous loading | Queue accumulation/contact proxies; separate clean/blocked hydraulic cases when an appropriate solver exists | No hydraulic safety pass from queue mass alone |
| Detector failure conceals leakage | Bias, miss/false-alarm rates, latency, correlated blindness, bubbles and stale alerts | Measured AI accuracy and representative site data |
| Bubble benefits do not justify cost | Same input with off/positive/zero/adverse branches and compressor energy | Species-specific physical trials and ecological effects |
| Three bands share a failure cause | Coupled storm/debris/power/comms/logistics cases | Actual hardware redundancy and recovery behavior |
| Released animals repeatedly return | Explicit return route/delay scenarios and repeated handling counts | Verified local drift and approved release decisions |
| Results depend on invented assumptions | Screening/range sweeps, numerical resolution checks and evidence provenance | More simulation cannot replace missing measurements |

Each reported issue should have: scenario/seed, time of first warning, affected band, backlog/escaped biomass, triggering assumption, unresolved evidence and proposed design response. Mark a finding as simulated rather than physically confirmed. Do not automatically close the risk register because a mitigation improved a chart.

## Comparison plan

- Outer-only mechanical reference versus three-band mechanical system: same outer equipment, forcing, arrival cohort and transport assumptions. Disclose additional reserve hardware/cost; this is not an equal-budget comparison.
- Three-band mechanical versus the same system with optional bubble assistance: include compressor/sensing effects and zero/adverse effects.
- Same three-band hardware under local-only versus coordinated supervision: isolate the incremental coordination value; local fallback remains in both designs.
- Dedicated collector availability and shared vessel/communications/power failures: identify remaining common dependencies.

Keep all scenarios, including unfavorable ones, in the report. No generic comparison proves superiority to Qandeel or all other competition entries.

## Outputs and definition of completion for the first build

1. Reproducible Python commands, configuration and source-provenance references. No equipment control or credential files.
2. Clearly labelled 2D illustrative animation and a separate operations dashboard for outer/middle/inner status.
3. CSV/JSON timelines for true versus observed flux, escapes, collection, receiving inventory, actual transfers and release/return.
4. Bubble-off/experimental comparisons and explicit compressor energy; unknown monetary rates remain unknown, not zero.
5. Dedicated vessel trip timeline, full-receiver/holding alerts and outage effects.
6. Automatically produced simulated-gap register with unresolved hydraulic/ecological evidence retained.
7. Numerical integrity and conservation checks; seeded replay; timestep/particle-resolution comparisons when the build is verified.
8. An evidence ledger separating public forcing, measured future inputs and scenario assumptions. No 99.99% field-performance label.

## Recommended build sequence

1. Confirm this scope and bubble-off reference/optional outer assist.
2. Extend ingestion, observed-versus-true state, finite trips and gap reports around the existing operations core.
3. Add illustrative particles/angled guidance and optional bubble scenarios without pretending to solve local hydraulics.
4. Run matched environmental/scenario sweeps and record failures/design tradeoffs.
5. Add native regional transport when authenticated datasets are available.
6. Develop real perception and local hydraulic/ecological validation as separate evidence workstreams.

## Primary sources checked

- [Bubble-curtain field/flume study, Aquaculture (2021)](https://doi.org/10.1016/j.aquaculture.2020.735915): condition/species dependence, not target/site proof.
- [OpenDrift documentation](https://opendrift.github.io/) and [integration examples](https://opendrift.github.io/gallery/example_double_gyre_advection_schemes.html): particle-trajectory framework and numerical schemes.
- [Official RT-DETR repository](https://github.com/lyuwenyu/RT-DETR): detector candidate and implementation/code licence; no MARLIN accuracy claim. Review checkpoint and training-data licences separately.
- [SALib sampling documentation](https://salib.readthedocs.io/en/main/api/SALib.sample.html): appropriate Sobol sampling and dependence limitations.
- Local acquired-data details: [DATA_REPORT.md](../data/DATA_REPORT.md). Existing model boundaries: [SIMULATION_AND_EVIDENCE.md](SIMULATION_AND_EVIDENCE.md).
