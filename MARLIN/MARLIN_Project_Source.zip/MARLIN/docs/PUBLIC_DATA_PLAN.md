# Public-data plan for MARLIN

Reviewed: 11 October 2026.

**Status: initial public collection downloaded and inspected. See the [acquisition report](../data/DATA_REPORT.md) for actual files, coverage, missing periods and licences. Native Copernicus grid requests are prepared but not downloaded. The existing operations model has not been connected to these files; its inputs remain synthetic.**

The [ENEC brief](https://challengeon.atrc.ae/en/challenges/atp2026/pages/enec-challenge-statement?lang=en) permits publicly available information and clearly stated assumptions; internal operational data and detailed facility design information will not be supplied. Public environmental records can support simulation forcing. They cannot supply unmeasured MARLIN capture, handling or hydraulic performance.

## Recommended sources

### Current acquisition status

The initial collection contains three 2024 point series each for ERA5 wind, ERA5-Ocean waves and SMOC currents/sea level, downloaded through Open-Meteo; regional GEBCO_2025 elevation and matching TID NetCDF grids; 100 linked GBIF species photographs with attribution; GBIF/OBIS occurrence responses; and bounded FathomNet metadata/annotation queries. The environmental point series are a practical initial subset, not a replacement for regional native grids. All 100 image seeds are from Australia and lack expert-reviewed detector labels. The exact FathomNet target query returned zero images. The one broad-Gulf OBIS return is a flagged Dubai observation, not plant bloom evidence.

GLORYS, native SMOC and WAVERYS requests requiring free sign-in are in [pending_copernicus_requests.json](../data/pending_copernicus_requests.json). Public HYCOM metadata was acquired, but the regional field retrieval stalled; no HYCOM velocity field is included. The repository includes selected processed environmental CSVs, missing-interval records, source metadata and candidate scenario windows. The full raw archive and downloaded image files are intentionally excluded because of their size; use the provider links and acquisition notes in this plan to retrieve them.

### 1. Regional ocean physics: historical baseline

[Copernicus Marine Global Ocean Physics Reanalysis / GLORYS12V1](https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_PHY_001_030/description), product `GLOBAL_MULTIYEAR_PHY_001_030`.

Request eastward/northward currents, temperature, salinity and sea level at relevant available depths. The product provides daily/monthly fields on approximately 1/12-degree grids with 50 depth levels, from 1993 onward. Use it for regional seasonal/current scenarios and boundary forcing, not velocity immediately beside a net or intake. Daily averaging does not resolve within-day tidal reversals. Access through the product's Data access tab or Copernicus Marine Toolbox; save the exact dataset ID, version and variables returned by the current catalogue.

### 2. Regional ocean physics: recent hourly scenarios

[Copernicus Marine Global Ocean Physics Analysis and Forecast](https://data.marine.copernicus.eu/product/GLOBAL_ANALYSISFORECAST_PHY_001_024/description), product `GLOBAL_ANALYSISFORECAST_PHY_001_024`.

Use archived hourly surface currents/sea level and available subsurface current products for recent event replay and response-latency experiments. Horizontal resolution is also approximately 1/12 degree. Confirm the actual archive and valid water cells before selecting dates. Hourly timestamps do not themselves establish accurate local tidal currents, intake suction or sheltered-channel circulation. Do not treat the forecast/reanalysis pair as independent observations validating each other.

### 3. Wind forcing

[ECMWF/Copernicus ERA5 hourly single-level data](https://cds.climate.copernicus.eu/datasets/reanalysis-era5-single-levels?tab=overview).

Request 10-metre eastward/northward wind and mean sea-level pressure. Atmospheric fields are available hourly on a 0.25-degree grid. Use winds for regional forcing and weather stress scenarios; do not prescribe direct jellyfish drift equal to a fixed fraction of wind without justification. Use the CDS download form or CDS API. [API access](https://cds.climate.copernicus.eu/en/how-to-api) requires an account and manual acceptance of the dataset terms.

### 4. Wave conditions and surface wave drift

[Copernicus Marine Global Ocean Waves Reanalysis / WAVERYS](https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_WAV_001_032/description), product `GLOBAL_MULTIYEAR_WAV_001_032`.

Request significant wave height, period, direction and Stokes-drift components. The documented native series is 0.2-degree / three-hourly (`cmems_mod_glo_wav_my_0.2deg_PT3H-i`); inspect downloaded metadata where catalogue fields differ. Use it to select regional rough/calm conditions, transport interruption scenarios and optional bubble-assist trial conditions. It does not compute sheltered waves, mooring loads or bubble efficacy. Add Stokes drift only after checking the current product's velocity convention and organism depth assumptions.

### 5. Regional seabed depth

[GEBCO_2025 grid and Type Identifier grid](https://www.gebco.net/data-products-gridded-bathymetry-data/gebco2025-grid), obtained through the [regional download application](https://download.gebco.net/downloads).

The grid is 15 arc-seconds, approximately 400–460 metres around this latitude. Download regional NetCDF/GeoTIFF subsets and the TID source-type layer. Use these for regional domain depth and to inspect data provenance. They cannot establish net clearance, anchors, breakwater geometry or recently dredged channels. Inspect interpolated/predicted cells and datum assumptions. No installation specification should be derived from this grid alone.

### 6. Annotated underwater imagery

[FathomNet database](https://database.fathomnet.org/), with [MBARI's image/annotation download example](https://docs.mbari.org/deepsea-ai/notebooks/fathomnet_train/).

Query suitable jellyfish taxa and fish/non-target categories; download images, bounding boxes and metadata through the API. Audit actual species counts before deciding if a usable target set exists. Use this as an initial underwater detection benchmark, not evidence of performance on adult Catostylus mosaicus in Gulf intake conditions. Geographic, lighting and camera differences matter. Follow the per-asset and annotation licences described in the [current terms](https://www.fathomnet.org/terms); there is no single licence covering every asset.

### 7. Optional biological context and species-image supplementation

[OBIS access portal](https://portal.obis.org/data/access/) provides marine occurrence records through its mapper/API; [GBIF](https://www.gbif.org/) provides occurrence records and links to associated media. Query Catostylus mosaicus and regional marine taxa. Audit records and geographic coverage before claiming Gulf observations.

Use OBIS for a preliminary ecological species list and GBIF media to investigate a target-species image supplement. Occurrences are not continuous bloom-density measurements; missing records do not establish absence. GBIF image links require separate [media-licence checks](https://techdocs.gbif.org/en/openapi/images), and images may need expert review and new bounding boxes. OBIS/GBIF may contain overlapping records: deduplicate. Neither source validates handling survival or bycatch rates.

## Initial acquisition and processing workflow

1. Begin with a regional southern-Gulf extraction around the public Barakah location. An illustrative first box is 23–25 degrees north, 51–54 degrees east; it is a data subset, not a final hydrodynamic domain. Check that valid offshore cells exist rather than selecting a nearest land/masked cell.
2. Start with a manageable common historical year, such as 2024, after checking all required variables and dates. Add further years and recent hourly windows as scope permits. Calm/adverse environmental windows are not automatically observed jellyfish bloom events.
3. Store originals unchanged with a manifest: provider, product/dataset ID, version, request, geographic/depth/time bounds, units, licence, citation, retrieval date and file checksum. Credentials remain outside version control.
4. Convert timestamps to UTC; validate longitude convention, masks, units, depth levels, missing values and direction conventions. Interpolation must not silently bridge land or manufacture higher physical resolution.
5. Use ocean/weather fields as regional forcing for a separate particle/coastal-flow model. Local channel geometry, tidal behavior and suction remain unresolved inputs. The current MARLIN queue model cannot ingest NetCDF directly and contains no hydrodynamic solver.
6. Derive a time series of arrivals crossing the proposed outer boundary from that model. Report particle-number flux and assumed biomass conversion separately. Feed arrivals to the three-band operations model to test capacities, latency, outages and release closures.
7. Keep capture efficiencies, handling limits and bubble effects labelled as assumptions until experiments support them. Public weather cannot turn an assumed removal rate into measured efficacy.
8. For imagery, deduplicate and group train/validation/test splits by deployment/video/source; avoid nearby frames or the same animal leaking across splits. Report precision, recall, missed-detection rate and condition-specific results. Record whether annotations are exhaustive; unlabelled animals must not automatically become negative examples.
9. Reserve time periods/locations for evaluation. Independent local measurements or approved prototype trials are needed for physical validation; replaying the same public model fields is a simulation exercise.

Copernicus Marine access is [free with sign-in](https://help.marine.copernicus.eu/en/articles/4220332-how-to-register-for-copernicus-marine-service). Public availability does not mean that all sources need no account or that every image can be redistributed freely.

## Explicit gaps

- Intake-scale depths, local tidal reversals, suction and net-induced flow restriction.
- A verified, adequately sized Catostylus mosaicus Gulf underwater detector test set; a public jellyfish sonar dataset suitable for this site has not been verified.
- Actual jellyfish concentration, size-to-biomass relationship and vertically resolved arrivals.
- Collector capacity/jam behavior, injury/bycatch outcomes and approved holding conditions.
- Vessel turnaround, permitted release windows and local release-return observations.
- Empirical bubble-curtain performance for the target species and operating envelope.

Represent these through disclosed scenario ranges for the competition concept, and obtain evidence through the validation plan before deployment claims. Do not tune assumptions solely to obtain a favorable clearance percentage.

