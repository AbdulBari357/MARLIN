# Boat control and remaining evidence gaps

Decision recommendation, 11 October 2026. These are design intentions, not approved equipment or an authorization to operate a boat.

## Boat operating concept

Automate the fixed band collectors and capacity monitoring first. Use a conventional crewed vessel for initial receiving-module exchange and live-catch transport trials. The development target is an unmanned vessel with a remote human operator/supervisor, tested automatic route following, and an assessed operator takeover/recovery procedure. Fully autonomous navigation and mechanical docking are later options requiring their own evidence.

An unmanned vessel can still be human-controlled from shore. "Unmanned" describes the absence of people on board; it does not establish autonomous judgment or zero staffing cost. The operating crew, communications, recovery boat, maintenance and supervision belong in lifecycle cost.

The operator confirms available receiving space, handling status, approved transport/release window and the applicable site operating envelope. AI may estimate arrivals and recommend dispatch priority; it must not independently approve a release location or override navigation/handling interlocks. Any future automated receiver exchange needs separately tested alignment, coupling verification and leak/animal-escape controls. Manual exchange remains a practical initial alternative.

Design separate responses for communications loss, unreliable position, propulsion fault, obstacle detection, bad weather and receiver failure. Do not assume that stopping, returning to base or holding station is safe in every location. Evaluate the specific safe state and recovery access. Include these faults in future vessel simulation and physical trials.

The existing operations model represents transport with a single aggregate kg/hour service rate. It does not yet simulate boats, payload stability, fuel/battery use, routes, docking, vessel turnaround, collisions or remote-control latency. Its release-closure scenario approximates unavailable logistics but cannot validate an unmanned vessel.

## When can gaps be found or resolved?

| Issue | What to do now | What simulation can investigate | Evidence still required |
|---|---|---|---|
| Public grids too coarse for bands/intake | Record resolution, missing coastal cells and unknown channel geometry | Sensitivity to boundary flow and hypothetical geometry | Local depth/flow evidence and appropriate coastal/hydraulic validation |
| Tidal reversals and jellyfish return | Avoid assuming permanently outward flow or a universal release distance | Reversal/return scenarios and drift under stated assumptions | Local observations, approved release assessment and drifter/handling trials |
| Biological load unknown | Keep density, body size and biomass conversion separate from weather | Broad load, duration, depth and size scenarios | Jellyfish arrival/size observations; weather does not measure bloom biomass |
| Guide/collector performance unknown | Treat capture fractions and handling rates as assumed | Capacity, delay and overload sensitivities | Flume/prototype trials, deformation/loading measurements |
| Water-flow restriction and mooring failure | Assess combined and blocked barriers before claiming safe placement | A separate hydraulic/structural model with defensible boundary conditions | Engineering review and appropriate physical evidence; current queue model is insufficient |
| AI misses, false alarms and domain change | Audit target species, labels, licences and deployment-level splits | Measured detector errors and simulated sensor faults | Held-out representative local imagery/sonar and real sensor calibration |
| Marine welfare and associated fish | Establish species/handling assessment and holding protocol | Only time/capacity flags until biological models are supported | Approved handling/survival/bycatch studies; a low residual rate is not a welfare result |
| Receiving/transport bottleneck | Define exchange time, vessel capacity, staffing and route availability | Vessel schedules, downtime, queues and release windows | Payload, water exchange, real transfer times, weather envelope and cost quotations |
| Common power/comms/weather failure | Identify shared dependencies across all bands | Fault injection and degradation scenarios | Hardware-in-loop and physical failure/recovery tests |
| Boat autonomy and docking | Keep supervised operation and manual handling as initial baseline | Route following, latency, failed docking, navigation-sensor uncertainty | Approved vessel trials and applicable operating permissions |

## Evaluation sequence

1. Identify known design and data gaps before simulation; assign owners and assumptions.
2. Inspect downloaded data for units, time coverage, masks, source grids and licensing.
3. Use simulation to discover additional interactions and quantify sensitivity within its assumptions.
4. Update the risk register and design based on adverse cases, including unresolved catch and logistics failure.
5. Verify physical and ecological behavior through the validation plan before deployment claims.

We should not wait for simulation to discover already identifiable gaps. Successful numerical output cannot resolve unmodelled animal injury, net entanglement, safe hydraulics or real navigation behavior.
