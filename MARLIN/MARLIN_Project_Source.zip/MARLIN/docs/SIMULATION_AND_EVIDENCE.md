# Operations model, assumptions and evidence

## Purpose

Explore whether three finite-capacity interception/collection stages and shared transport can manage illustrative continuous loads and faults. This is a **queue and mass-flow model**, not hydrodynamic CFD, a particle trajectory prediction, or field reliability analysis.

## Model workflow

1. Load and validate a versioned JSON configuration.
2. Generate an explicitly synthetic input profile for an eight-hour event followed by a four-hour observation/drain period.
3. Deliver delayed escape streams to the middle and inner stage.
4. Form synthetic sensor observations; apply local activation, delay and supervisory fault signals.
5. Admit finite retained mass according to assumed interception fraction and loading/receiving headroom. Pass uncollected residual downstream.
6. Clear retained mass into each dedicated wet receiver, subject to its collector rate and space.
7. Allocate a shared transport/release rate by oldest capture time across receivers when the assumed release permission gate is open.
8. Schedule a specified fraction of released mass to re-enter after a fixed illustrative delay.
9. Check mass conservation every minute; record residual, retained, received and release-at-sea mass, events and loading/time-limit proxies.
10. Repeat with seeded variations. Compare outer-only and three-band variants with paired forcing/parameter draws.

## Accounting

For each stage, arriving mass equals new retained mass plus downstream escape. Retained mass changes by admitted capture minus collection. Receiving mass changes by collection minus transport/release. When an assumed released fraction re-enters, it is removed from the release-at-sea account and enters the outer stage again; it is not counted as fresh external biomass.

Global invariant:

`external biomass = retained + received + inter-band transit + released-at-sea account + downstream residual`

Historical capture and historical release totals can exceed unique external mass because the same material can be handled again after return. They are not percentages of unique biological success. Model "released" means an accounting destination; it provides no evidence of survival, habitat suitability or permit compliance.

The conservative finite-horizon unresolved fraction is `(downstream residual + all mass still in system) / external biomass`. Its complement is the release-at-sea account fraction at that instant, not permanent exclusion or ecological success.

## Numerical assumptions

All configuration values, including interception fractions, rates, capacities, activation thresholds, delays, loading limits, storage-time flags, motor power and return fractions, are **illustrative, uncalibrated assumptions**. They are not sourced measurements. Units are in JSON field names. Document these inputs whenever showing outputs.

- `efficiency` represents the fraction routed into a capture queue under reference model conditions. It does not mean removal efficiency validated for Catostylus or a Gulf installation.
- `net_capacity_kg` is an abstract accumulation limit. It is not net strength, safe hydraulic blockage, approved crowding or receiver volume.
- `holding_limit_minutes` is a scenario flag, not a biologically safe holding duration.
- Input multiplier and capacity/efficiency variation are synthetic sensitivity distributions. Their sample quantiles are not confidence intervals or probabilities of real-world success.
- Reduced interception under common sea-state/depth cases is imposed as a factor; there is no wave, velocity, deformation or swimming computation.
- Hourly transport capacity aggregates vessel turnaround, transfers and release into one service rate. Discrete vessel travel, downtime, bad weather, docking and actual release windows are not resolved.
- Ground-truth biomass is internal to the simulator. Local reserve activation uses synthetic observations, not direct access to true flux. Collector and receiving load are assumed instrumented for queue control; their measurement faults require later work.
- Synthetic sensor blindness sets the observation to missing and raises an alarm. It does not represent a trained AI detector.
- Water exchange, temperature, oxygen, animal injury/survival and non-target catches are not simulated. Holding-age breaches are only operational proxies.
- Bubble curtains are excluded from this reference calculation. Collector/control electricity excludes compressors, vessels, towing, installation, cleaning, offboard sensing and manufacture.
- Existing plant screens and response are outside the model. Mass crossing the inner stage is reported, never silently treated as captured by backup screens.

## Scenarios

Reference continuous bloom; sustained overload; short surge; outer collector outage; all-collector outage; network outage; simultaneous middle/inner detector blindness; common sea-state degradation; depth/side bypass; debris-related collection reduction; closed release route; high return fraction; uncertain-animal handling pause; coordinated maintenance request; prolonged logistics outage combined with outer collection failure.

These cases are illustrative stress inputs, not exhaustive hazard coverage. The run reports where capacity and activation fail. Safety/production acceptance thresholds remain open; the software does not award a safety pass or score a competition win.

## Evidence and limitations

| Source | Supported statement | What it does not establish |
|---|---|---|
| [Official ENEC brief](https://challengeon.atrc.ae/en/challenges/atp2026/pages/enec-challenge-statement?lang=en) | The scope is management after notification; the concept must address marine protection, practicality, cost and sustained volume. | Internal site dimensions, flows, permitted installation or promised funding. |
| [2021 bubble-curtain field/flume experiment](https://www.sciencedirect.com/science/article/pii/S0044848620315118) | Performance varied with conditions and jellyfish; wave effects mattered. | Effectiveness on adult Blue Blubber at ENEC. |
| [2016 fish–jellyfish study](https://pmc.ncbi.nlm.nih.gov/articles/PMC4936048/) | Juvenile fish were associated with 32% of 62 sampled C. mosaicus in an Australian field sample. | UAE bycatch rate or outcomes from MARLIN handling. |
| [Sonar analysis study](https://arxiv.org/abs/2103.04068) | The authors reported difficulty generalizing a jellyfish detector to different underwater environments. | Performance of an unbuilt MARLIN detector. |
| [Patent CN220666133U](https://patents.google.com/patent/CN220666133U/en) | Published descriptions include three interception nets, bubbles and automatic collection. | Field effectiveness, novelty of our control details or a legal conclusion. |
| [Patent JP4527855B2](https://patents.google.com/patent/JP4527855B2/en) | Nets, alternating collection and proposed live transport already have published precedent. | Welfare or reliable performance for MARLIN hardware. |
| [2025 pre-filtration study](https://www.frontiersin.org/journals/energy-research/articles/10.3389/fenrg.2025.1703175/full) | It explicitly analyzes hydraulic and cleaning capacity for an intake pre-filter design. | Transferability of its dimensions or results to Barakah. |

Some publisher pages were inaccessible during retrieval; the previously retrieved abstract supported the bubble-curtain summary. No inaccessible full-text results are asserted here.

## Replacing assumptions with data

Preserve each version and record provenance: measurement method, species, location, dates, sample count, sea conditions, uncertainty, operator and equipment configuration. First calibrate local flux and collector turnover. Then calibrate depth/bypass behavior, stage delays, reserve capacity, logistics, and release-return behavior. Hydraulic and ecological acceptance require separate models/experiments, not parameter tuning until this operations model looks favorable.

Match time-stamped observations to predictions using held-out bloom events and sea conditions. Check discretization by halving the timestep. Run fault-injection on the real control prototype separately. Report missing evidence alongside plots.
