# Verification record — MARLIN v0.1

Date: 10 October 2026. This record verifies software behavior and report presentation. It does not verify marine equipment, animal outcomes, site hydraulics or production reliability.

## Completed checks

| Check | Actual scope | Outcome |
|---|---|---|
| Model unit tests | 11 tests covering conservation, finite capacities, complete interception, absent release service, recapture accounting, primary outage, local response during missing sensing/network loss, maintenance permits, zero input, reproducibility, timestep refinement and invalid inputs | Passed |
| Representative scenarios | 17 scenarios, each with three-band and outer-only configurations: 34 runs | Completed; stress scenarios expose failures |
| Synthetic sensitivity | 24 parameter samples for each scenario/configuration: 816 runs; seed 20261010 | Completed; ranges are synthetic, not field confidence intervals |
| Design tradeoffs | Four illustrative designs across 17 scenarios: 68 runs | Completed; reserve and logistics capacity changes are disclosed separately |
| Biomass accounting | Minute-by-minute checks in representative runs | Maximum numerical balance error 3.42e-10 kg |
| Desktop report | Headless Edge; scenario/architecture selection, clickable table, SVG plots and warning updates | Passed; no JavaScript errors observed |
| Mobile report | 360-pixel viewport, stacked layout, report width and scrolling tables | Passed; no page-wide horizontal overflow observed |

Browser screenshots are saved locally under `../tmp/report-review/`. The browser check used an isolated temporary profile. It did not operate equipment or a personal browser profile.

## What these checks establish

All three modeled stages have distinct incoming flow, retained biomass, collection, receiving and residual accounting. A reserve can respond locally during modeled communication loss. Unsafe modeled maintenance can be refused. Closed release service cannot disappear biomass or produce unlimited storage. Returning animals are tracked without counting them as new external arrivals.

The finite simulation horizon and approximated transport service remain material limitations. An empty receiver at the end does not erase an earlier holding-time flag. The model's holding-time threshold is not a biologically approved limit.

## Still pending

Hydraulic and structural analysis; collector prototypes; live-handling and associated-fish studies; site-calibrated detection and flux estimates; actual vessel scheduling; approved release and return observations; quotations and lifecycle cost; hardware/control fault tests; and an approved field pilot. See [validation plan](VALIDATION_PLAN.md).

No test in this record establishes 99.99% effectiveness, failure probability, competition superiority, patent novelty or readiness to deploy.
