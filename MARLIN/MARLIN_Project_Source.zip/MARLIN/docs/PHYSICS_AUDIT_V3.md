# MARLIN model physics audit — v3 transition

## Corrections made

- The prior 2D model had no depth coordinate. A `depth_bypass` Bernoulli flag made 8% of cohorts bypass every boom regardless of actual depth. The new screening version assigns cohort depth explicitly and tests each crossing against each boom's skirt depth.
- The prior bubble “positive” case added a fixed horizontal velocity tangent to the outer guide. It did not calculate a vertical airlift. The new version removes that horizontal bubble boost and represents an array of diffuser point plumes. Gas flow sets buoyancy flux; the closure uses published classical-plume and slip-plume scalings, applies a Gaussian cross-section, shifts plume centers with ambient current during ascent, and adds vertical cohort motion.
- Bloom detection is still only a noisy, delayed flux observation that requests activation. It does not set the plume velocity or claim trained ML/CV performance.
- Bubble gas flow and energy are now reported separately. Energy remains a fixed compressor-power assumption, so energy per gas flow is not a validated equipment result.
- The lift metric compares each actual plume trajectory to a paired no-bubble trajectory with the same vertical-mixing draws. Background random mixing alone is therefore not called airlift.

## Model-by-model status

| Submodel | Current representation | Main unverified physics / data gap |
|---|---|---|
| Regional forcing | Public hourly surface wind, waves and currents; projected into a prescribed field | Not channel-scale; depth-independent; intake flow, shear, tide interaction and local wave transformation unresolved |
| Jellyfish arrivals | Synthetic weighted cohorts at a constant rate | No Barakah biomass flux, seasonal frequency, species-confirmed abundance or depth distribution |
| Jellyfish motion | Horizontal prescribed advection plus random walk; vertical position now explicit | Adult active swimming, pulsation, orientation, vertical buoyancy, bell size/drag and response to bubbles not calibrated |
| Airlift / bubble wall | Reduced-order multi-plume closure, low/nominal/high gas-flow sensitivity | No measured diffuser flow/pressure, bubble-size distribution, site salinity/stratification, plume PIV, crossflow/wave validation, diffuser interference or fouling model |
| Boom contact | Plan-view guide crossing, constrained by actual simulated depth and skirt depth; Bernoulli interception remains | No net/skirt deformation, current loading, gap geometry, jellyfish flexibility, contact injury or non-target separation |
| Detection and controls | Threshold, persistence, latency, weather interlock and alarm scenarios | No labeled site video/sonar, trained model, precision/recall, depth observability, bubble occlusion or real actuator feedback |
| Collector and receiver | Finite assumed capacities and rates | No pump/screen pressure drop, clogging curve, debris mixture, wet handling trial or biomass-density data |
| Vessel and release | Finite schedule and queueing model | No navigation, docking, actual crewed/autonomous safety case, approved release area or survival/return evidence |
| Energy and cost | Fixed component power multiplied by simulated run time | No compressor curve, pressure loss, installed cost, service cost or measured labor baseline |

## Biology reference caveat

The attached slide's 30–45 cm bell-size and swimming statements should be treated as claims to verify. The available *Catostylus mosaicus* jet-paddling study used small laboratory medusae (reported in the paper at roughly 2.3–4.6 cm bell diameter), so its speed cannot be transferred to 30–45 cm Blue Blubber adults. The model therefore does not convert bell size to mass or assert adult swimming speed.

## Source papers behind the plume closure

- McCarver et al. (2022), “Experiments on fluid entrainment and slip in continuous bubble plumes,” Journal of Fluid Mechanics. The study reports classical-plume and slip-dominated scaling, including a liquid-flux coefficient near 0.21 and bubble slip speeds around 0.2–0.3 m/s for 1–10 mm bubbles. Those are laboratory observations, not site-specific constants.
- Neil and Askew (2018), “Jet-paddling jellies: swimming performance in the Rhizostomeae jellyfish Catostylus mosaicus,” Journal of Experimental Biology. The study establishes active jet-paddling but tested much smaller medusae than the 30–45 cm size claim on the attached slide.

## Interpretation

The paired lift metric compares each plume trajectory to a no-bubble trajectory with the same vertical-mixing draws; background random mixing alone is not called airlift. A single narrow diffuser row exposes a cohort to the plume briefly as intakeward flow carries it past. If substantial lift from deep water is required, test a longer or multi-row lift zone against compressor demand and intake hydraulics before treating a bubble curtain as the main capture mechanism.

This version is more physically structured than the old proxy; it is not “correct for Barakah” yet. It can test whether stated diffuser assumptions produce plausible lifting patterns and reveal sensitivity to depth and gas flow. Use the flume validation sequence in `outputs/v3/two-layer-plume/RUN_REPORT.md` before presenting simulated percentages as expected field effectiveness.
