# Decisions and unresolved design choices

## Decisions adopted for concept development

1. All three bands have defined capture and extraction paths, dedicated collection availability and local receiving space. The inner band is more than an alarm.
2. Inter-band messaging supplements local controls; it is not the only way a reserve can respond.
3. Receiving mass remains unprocessed until transfer/release is accounted for. Re-entering animals are not fresh biomass and can incur repeated handling.
4. Mechanical capture is the first reference mechanism; bubble assistance requires demonstrated incremental benefit.
5. Collector selection remains conditional. A slow soft-pocket wet mechanism is a first prototype candidate; an appropriate fish-pump alternative may be compared in authorized handling work. Neither is assumed harmless or high-throughput without testing.
6. No permanent escape corridor, fixed offshore distance, compass release direction or actual band position is selected from public map imagery.
7. A service request requires downstream readiness and capacity. A jam/fault has its own approved physical response; there is no universal net-opening rule.
8. No automatic sorting, full-depth sensor coverage, zero bycatch, 99.99% performance, guaranteed win or production readiness is claimed.

## Model findings translated into engineering work

### Primary unavailability

The illustrative reference middle collector is smaller than the external arrival rate. The model accordingly refuses a primary-maintenance request at the reference load. This is intentional honesty, not a final sizing choice. For full temporary primary replacement, middle sustained collection/receiving/logistics must cover the agreed primary-outage load and duration. Alternatively declare a reduced-service envelope and approved escalation.

### Closed release route

Larger local buffers delay saturation but cannot justify indefinite holding. Establish actual alternate permitted arrangements, maximum outage duration and welfare constraints. Without them, no continuous-clearance claim under prolonged release closure is defensible.

### Common conditions

Three physical positions do not eliminate a common sea-state/depth failure. Compare geometries and mechanisms across the relevant conditions and maintain an explicit envelope. Independent controllers cannot correct a physical barrier that is ineffective in that flow.

### Detector underestimation

Healthy-looking but biased observations can delay reserve activation. Add independent flux calibration and plausible load/collector cross-checks; test disagreement and drift. A missing observation alarm is easier to handle than an undetected systematic error.

### Marine handling

Time/crowding flags identify operational concerns; they do not tell us whether animals survive. The biologist's work must define these limits. Retained animals and associated small fish require observation, not assumptions of successful AI sorting.

## Capacity comparison workflow

Run `python simulation/design_tradeoffs.py` after the main model. It changes reserve capacities and aggregate logistics separately and together, exposing which bottleneck improves and which persists. Rates/powers remain synthetic. This is a design discussion tool, not field optimization. Keep the unchanged reference results alongside every alternative.

Before selecting a production arrangement, replace uncertain inputs with measurements, establish hydraulic/ecological constraints and produce realistic transport schedules. Choose the least complex design that meets the agreed performance requirements with acceptable degraded operation and lifecycle cost.
