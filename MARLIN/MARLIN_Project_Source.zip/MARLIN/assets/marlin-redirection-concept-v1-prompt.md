# MARLIN redirection concept image

Generated using the built-in image-generation tool on 11 October 2026.

Image: `marlin-redirection-concept-v1.png`

Proposed functional illustration; not an approved site layout, hardware design or evidence of efficacy. Bubble assist is optional. The illustration does not establish acceptable water flow or handling welfare. Actual collectors must preserve validated wet-handling conditions.

## Generation prompt

Use case: infographic-diagram.
Create a polished, clean educational image explaining MARLIN jellyfish redirection. Landscape composition, generous whitespace, readable minimal text. Flat technical illustration with a slight isometric perspective, crisp shapes, soft pale aqua sea, navy and teal equipment, amber jellyfish and capture arrows, muted gray shoreline. No photorealism and no decorative clutter.

Title: "MARLIN"
Small subtitle: "Proposed redirection concept"

Main scene: open sea on the left, a simplified shoreline and water intake on the far right. Water travels left to right toward the intake. Three distinct spaced angled permeable guide structures cross the conceptual water approach, in order: outer, middle, inner. They must look like mesh net segments through which water can pass, not solid dams. Each guide slopes so its downstream end feeds a separate small collection pocket beside the upper edge of the water approach. The geometry and arrows must agree: incoming jellyfish drift right, meet a guide, then an amber arrow bends diagonally upward along that guide into its pocket. Each pocket has a clearly illustrated small slow wet collector transferring jellyfish into its own water-filled rectangular receiver. Show many jellyfish before the outer guide, a few between outer and middle, and one between middle and inner; these are illustrative icons, no numerical efficiency claims. Show a few residual amber dashed arrows traveling to subsequent bands to make the three-stage response clear. Water arrows in light blue continue through the mesh toward the intake. Keep the capture routes and water arrows visually distinct.

Above the main scene, show ONE small transport boat with a water-filled module and a dotted teal route away from the intake toward an open-sea release symbol at the upper left. Dotted connections from each of the three receivers to this boat represent transport, NOT permanent pipes or discharge channels. The boat route must point away from the intake. No receiver should empty toward the intake. Existing backup screen can be a small gray grid immediately at the intake without extra text.

Optional bubble assist: a short subtle line of bubbles ONLY beside the outer guide. It must not be shown as the main capture mechanism or present at all three stages.

Only these words should appear, with no paragraphs:
"MARLIN"
"Proposed redirection concept"
"Outer"
"Middle"
"Inner"
"Water flow"
"Guide net" (one callout to outer guide)
"Collector" (one callout to visible outer collector)
"Wet receiver" (one callout to outer receiver; all 3 identical shapes)
"Bubble assist (optional)" (one callout to short outer bubble line)
"Transport"
"Approved release"
"Intake"

Make the mechanism unambiguous, accurate as a proposed functional schematic, and easy to understand at a glance. Labels short and large, no crossing leader lines, no percentages, no AI/control panels, no robots, no invented distances or site geometry, no claims of perfect protection, no logo watermark.

