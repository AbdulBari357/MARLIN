# MARLIN v4 design and physics screening

Candidate: 2.50% uncaptured; 97.50% delivered to hypothetical supervised shore receiving. Unknown exits and unfinished collection are counted explicitly.

**This is a conditional scenario, not predicted ENEC field performance.** The target was met by deeper interception, wider coverage and finite powered collection/transport. Bubbles do not guarantee exclusion. Contact probabilities remain the earlier uncalibrated .90/.80; they were not increased to obtain the target.

## Candidate changes

- Two porous guides, both active during the bloom, extend to 11.8 m in an assumed flat 12 m water column (0.2 m bottom gap). This is a different design from half-depth surface booms.
- 200 m modeled coverage surrounds the original 116 m incoming source corridor, with 42 m margin each side. This is a declared hypothetical streamtube; the map does not establish that site geometry or current envelope.
- Explicit powered wet conveyance at 0.20 m/s and vertical lift at 0.04 m/s. Deep animals cannot enter a surface collector until they reach its 0.2 m pickup zone. Retention, injury and motor sizing need physical tests.
- 2,400 kg/h collection per guide, 900 kg guide/load proxy and 1,400 kg receiver each; two 900 kg supervised transport resources; finite 6,000 kg shore receiving.
- Shore trips use hypothetical 5 minute travel each way, 4 minute loading and 3 minute unloading. Water/oxygen management and downstream handling after delivery are not simulated. Actual delivery and release plans require review.
- Bubbles are an optional comparison, not needed to hit the simulated baseline target. When both diffuser lines are run continuously in the reference case, estimated compressor use is 77.1 kWh per bloom event; no reliable capture improvement appears across the small seed sample. Treat the bubble curtains as off until a calibrated trial shows a benefit. The model imposes no sealed-wall or jellyfish-avoidance effect.

## Main scenarios and checks

| Case | Intakeward % | Unknown exits % | Total uncaptured % | Delivered % | Still held % | Max pre-delivery age (min) | Numerical target |
|---|---:|---:|---:|---:|---:|---:|---|
| Previous three half-depth guides · corrected transport | 29.00 | 14.25 | 43.25 | 56.75 | 0.00 | 50.2 | not met |
| Candidate · two deep guides (bubbles OFF) | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.7 | met |
| Optional seabed airlift + near-outer bubble wall | 2.25 | 0.00 | 2.25 | 97.75 | 0.00 | 41.7 | met |
| Candidate · strongest current window (bubbles OFF) | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.8 | met |
| Candidate · strongest wave window (bubbles OFF) | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 40.5 | met |
| 2 m waves + 14 m/s wind · bubbles OFF | 16.25 | 0.25 | 16.50 | 83.50 | 0.00 | 158.1 | not met |
| Candidate · 2 m waves + 14 m/s wind for 2 hours | 15.75 | 0.25 | 16.00 | 84.00 | 0.00 | 158.1 | not met |
| Candidate · triple bloom load | 27.00 | 0.00 | 27.00 | 41.67 | 31.33 | 352.0 | not met |
| Candidate · outer collector stops for 2 hours | 9.00 | 0.00 | 9.00 | 91.00 | 0.00 | 148.2 | not met |
| Candidate · water 0.8 m deeper, same skirts | 5.00 | 0.00 | 5.00 | 95.00 | 0.00 | 41.7 | not met |
| Bloom concentrated within 0.3 m of seabed | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.7 | met |
| 10× vertical mixing sensitivity | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.7 | met |
| Candidate · penetration risk shared across guides | 9.50 | 0.25 | 9.75 | 90.25 | 0.00 | 38.5 | not met |
| quarter 2 first complete week | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 40.6 | met |
| quarter 3 first complete week | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 40.7 | met |
| quarter 4 first complete week | 2.25 | 0.00 | 2.25 | 97.75 | 0.00 | 39.4 | met |
| 20 °C / 35 PSU sensitivity | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.7 | met |
| 20 °C / 42 PSU sensitivity | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.7 | met |
| 36 °C / 35 PSU sensitivity | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.7 | met |
| 36 °C / 42 PSU sensitivity | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.7 | met |
| Bubble-OFF repeat seed 20261012 | 2.25 | 0.00 | 2.25 | 97.75 | 0.00 | 41.3 | met |
| Bubble-OFF repeat seed 20261013 | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 40.6 | met |
| Bubble-OFF repeat seed 20261014 | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 39.6 | met |
| Bubble-OFF repeat seed 20261015 | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 40.3 | met |
| Bubble-OFF repeat seed 20261016 | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 42.2 | met |
| Bubble-OFF repeat seed 20261017 | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 40.2 | met |
| Bubble-OFF repeat seed 20261018 | 2.00 | 0.00 | 2.00 | 98.00 | 0.00 | 40.1 | met |
| Bubble-OFF repeat seed 20261019 | 2.25 | 0.00 | 2.25 | 97.75 | 0.00 | 41.3 | met |
| Bubble-OFF repeat seed 20261020 | 2.25 | 0.00 | 2.25 | 97.75 | 0.00 | 39.9 | met |
| Bubble-OFF repeat seed 20261021 | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 41.8 | met |
| Bubble-ON repeat seed 20261012 | 2.25 | 0.00 | 2.25 | 97.75 | 0.00 | 41.2 | met |
| Bubble-ON repeat seed 20261013 | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 40.4 | met |
| Bubble-ON repeat seed 20261014 | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 40.6 | met |
| Half timestep · 15 s | 2.50 | 0.00 | 2.50 | 97.50 | 0.00 | 42.0 | met |
| Half cohort mass · 6 kg | 1.62 | 0.00 | 1.62 | 98.38 | 0.00 | 42.4 | met |
| Strong transverse-current sensitivity | 0.50 | 6.00 | 6.50 | 93.50 | 0.00 | 39.5 | not met |

## Numerical review

All 27 focused code/kinematic tests pass, including invalid-input cases. Tests check divergence, boundary projection, signed return flow, actual path exposure, bell extent, finite vertical lift/pickup, zero/one capture probabilities, source/receiver/vessel/shore capacity and biomass conservation.
Maximum mass ledger error over the suite: 0.000e+00 kg.
Bubble-ON repeats: 2.25–2.50% uncaptured, median 2.38% (n=4). Bubble-OFF repeats (including main run): 2.00–2.50%, median 2.50% (n=11). These are simulation variations, not field confidence intervals.
15 s timestep and 6 kg cohort checks are reported above. Different steps change diffusion draws, so compare outcome distributions rather than expect identical trajectories.

## Environmental factors

- **wind:** ERA5 wind controls vessel availability. Direct aerodynamic/structural wind load not resolved.
- **waves:** ERA5 height/period controls boats; regular-wave screen load proxy; storm contact loss sensitivity. No irregular-wave particle dynamics.
- **currents:** SMOC time interpolation + prescribed local component; three-dimensional flow and intake/net feedback unmeasured.
- **temperature / salinity:** 20/36 °C and 35/42 PSU synthetic tests via EOS-80 density, gas expansion and compressor pressure. No measured local thermal/haline profile.
- **tides / depth:** Regional sea-level ranges reported. Fixed-depth +0.8 m clearance sensitivity; no moving-surface tidal solver.
- **biology:** Synthetic uniform depth and 1200 kg/h arrivals; public species occurrences do not supply local abundance or capture physics.

The report also stores each forcing window’s current, wave, wind and sea-level ranges and estimated net drag/headloss proxies. These proxies do not couple net resistance back into intake flow and their limits are hypothetical engineering screening values.

## Remaining limits

- Solving water continuity does not establish momentum, turbulence, stratification, free-surface waves or intake hydraulics. The streamfunction plume is an uncalibrated circulation surrogate.
- The shared-escape scenario tests the independence assumption: a penetration-prone animal may pass both guides. Field contact/retention measurements are needed to establish a realistic joint failure model.
- Nearly full-depth netting creates bycatch, debris, mooring and maintenance exposure. Mesh, local pump suction, cleaning, clogging pressure, bed clearance and movement limits require ENEC and ecological review.
- Synthetic bloom arrivals, source corridor, depth distribution and contact probabilities are not a public Blue Blubber abundance/trajectory dataset.
- Holding flags cover pre-delivery time only; survival and time spent in shore receiving are not computed. No autonomous navigation or real ML/CV is implemented.

## Primary sources

- https://arxiv.org/html/2401.09771v1
- https://link.springer.com/article/10.1007/s10652-025-10029-1
- https://research.ucc.ie/en/publications/field-and-flume-tank-experiments-investigating-the-efficacy-of-a/
- https://legacy.repository.oceanbestpractices.org/handle/11329/109
