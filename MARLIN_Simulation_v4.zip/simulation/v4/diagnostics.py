"""Screen drag proxy and explicit physical/environmental model limitations."""
import math

def wave_number(period,depth):
    if period<=0 or depth<=0: raise ValueError('Positive period/depth required')
    omega=2*math.pi/period;k=max(omega*omega/9.80665,omega/math.sqrt(9.80665*depth))
    for _ in range(20):
        kd=k*depth;t=math.tanh(kd)
        k-=(9.80665*k*t-omega*omega)/(9.80665*(t+kd*(1-t*t)))
    return k

def environmental_audit(cfg,forcing,scenario='reference'):
    from engine import Simulation
    sim=Simulation(cfg,forcing,scenario,'two_off',cfg['seed'])
    rho=sim.water_density();g=9.80665;D=cfg['geometry']['water_depth_m'];h=cfg['hydraulics']
    solidity=h['clean_solidity'];cd=h['strand_drag_coefficient'];band_peaks=[];records=[]
    for minute in range(0,int(cfg['observation_hours']*60)+1,15):
        e=sim.conditions(minute);u,v=sim.ambient_velocity(0,0,minute)
        records.append(dict(minute=minute,temperature_c=cfg['environment']['temperature_c'],salinity_psu=cfg['environment']['salinity_psu'],local_u_m_s=u,local_v_m_s=v,**e))
    for b in cfg['bands']:
        a,z=b['start'],b['end'];L=math.dist(a,z);normal=((z[1]-a[1])/L,-(z[0]-a[0])/L)
        peak_pressure=peak_drag=0.0
        for e in records:
            un=abs(e['local_u_m_s']*normal[0]+e['local_v_m_s']*normal[1]);k=wave_number(e['wave_period'],D)
            drag_per_m=0.0
            for j in range(24):
                d=b['skirt_depth_m']*(j+.5)/24
                # Regular wave with height=Hs, normal incidence: screening load,
                # not an irregular-wave extreme or a resolved particle forcing.
                orbital=math.pi*e['wave_height']/e['wave_period']*math.cosh(k*(D-d))/math.sinh(k*D)
                pore=(un+orbital)/(1-solidity)
                pressure=.5*rho*cd*solidity*pore*pore
                peak_pressure=max(peak_pressure,pressure)
                drag_per_m+=pressure*b['skirt_depth_m']/24
            peak_drag=max(peak_drag,drag_per_m)
        band_peaks.append(dict(name=b['name'],peak_pressure_proxy_pa=peak_pressure,
            peak_headloss_proxy_m=peak_pressure/(rho*g),peak_total_drag_proxy_kn=peak_drag*L/1000,
            peak_span_force_proxy_kn=peak_drag*h['mooring_span_m']/1000))
    return dict(ranges={k:[min(r[k] for r in records),max(r[k] for r in records)] for k in records[0] if k!='minute'},bands=band_peaks,
        headloss_proxy_limit_m=h['screening_headloss_limit_m'],allowable_span_proxy_kn=h['illustrative_allowable_span_force_kn'],
        proxy_within_assumed_limits=all(b['peak_headloss_proxy_m']<=h['screening_headloss_limit_m'] and b['peak_span_force_proxy_kn']<=h['illustrative_allowable_span_force_kn'] for b in band_peaks),
        limitations=['No coupled intake/net hydraulic solver; this drag proxy does not predict actual pump head loss.',
          'Hs regular-wave orbital amplitude is a screening proxy, not certified design waves or mooring fatigue.',
          'Wind and waves gate transport; wave-driven contact, overtopping and irregular-wave particle motion unresolved.',
          'SMOC mean currents already include wave/tide contributions; no duplicate mean Stokes drift added.',
          'Temperature and salinity are uniform synthetic sensitivities; stratification, jellyfish behavior and survival unresolved.',
          'Sea level reported from regional data; constant depth sensitivities test clearance, not a solved moving free surface.'])
