# MARLIN v4 physics and model review

**Status: exploratory screening model, not a validated prediction for Barakah.** A result below 5% means the simulated candidate met that target under its stated assumptions. It does not establish field capture efficiency, acceptable cooling-water restriction, animal survival, or production readiness.

The candidate uses two bands with nearly full-depth porous skirts and explicit powered wet conveyance. Bubble-off is the lower-energy base case; seabed airlift and a near-outer bubble curtain are optional comparisons. The low-slip mechanism primarily closes depth and lateral coverage gaps and increases clearing/receiving capacity; it does not assume that every jellyfish crossing bubbles must reach the surface.

## What was corrected

| Earlier problem | v4 correction | What the correction establishes |
| --- | --- | --- |
| Closely spaced point-plume velocities were added and clipped | A prescribed planar circulation field replaces that approximation | Water continuity and a signed return flow are represented; a calibrated two-phase momentum solution is still absent |
| Deterministic upward advection could reflect off the surface and bounce an animal downward | Deterministic movement is projected inside the water column; stochastic diffusion alone reflects | No numerical rebound from an imposed upward velocity |
| A guide moved cohorts at a fixed speed without identifying a power source | Passive movement follows the signed tangential water velocity; the candidate explicitly selects powered wet conveyance | Powered and passive handling assumptions are distinguishable |
| Deep intercepted cohorts could reach a surface collector without a vertical mechanism | Powered conveyance has an explicit vertical lift speed and a pickup-depth requirement | No direct transfer from depth to a surface collector |
| Biomass leaving a side boundary could be mistaken for successful clearance | Side exits and free biomass remain in the uncaptured metric | A low intakeward percentage cannot conceal unidentified side escapes |
| Held inventory could be mistaken for finished removal | Held biomass, shore delivery, free biomass, side exits and intakeward passage are reported separately | Capture and completed handling can be assessed independently |
| Compressor electricity was an unrelated constant | Pressure, gas flow, line loss and assumed efficiency determine an isothermal estimate | Energy changes consistently with configured flow and depth; actual compressor selection remains open |
| Invalid or incomplete physical inputs could be accepted | Range and consistency checks reject invalid probabilities, geometry, diffusion and resource inputs | Invalid numerical configurations are rejected; valid input ranges are not evidence of real feasibility |

The invariant tests address boundary behavior, water divergence, signed circulation, depth bypass, collector access, capacity, gas accounting and biomass closure. Passing those tests establishes code consistency. It does not test the entire ocean or prove the biological and equipment assumptions.

## Bubble field: equations and limits

Use depth **d positive downward**. For each diffuser, define a fixed horizontal unit normal **n** to the line and a unit tangent **s**. The field uses a streamfunction per metre of diffuser, psi(n,s,d,t), with units m2/s:

    normal water velocity u_n = partial psi / partial d
    depth velocity v_d       = -partial psi / partial n
    upward water velocity    =  partial psi / partial n
    tangential added velocity = 0

Therefore, in local line coordinates,

    partial u_n / partial n + partial v_d / partial d
      = partial² psi / partial n partial d
        - partial² psi / partial d partial n
      = 0.

Rotating the normal velocity back to x and y preserves this result. A finite-line window can depend on s without breaking this cancellation: the added tangent velocity is zero. The implemented centered derivative stencils are checked numerically away from nonsmooth boundaries. The prescribed ambient current is spatially uniform, so its divergence is also zero.

The implemented streamfunction has the form

    psi = U(d) F(d) E(s,d) b(d) sqrt(pi/2)
          [erf(n/(sqrt(2)b)) - erf(n/(sqrt(2)B))],
    B = R b, R > 1.

Here E is a finite-line end window; F smoothly reduces the field toward the surface and outlet plane; b is the core width; and B is a wider return-flow width. At fixed depth and s, differentiating with respect to n gives

    upward velocity = U F E
      [exp(-n²/(2b²)) - (b/B) exp(-n²/(2B²))].

This produces an upward core and broader downward return flow. Their integrals across an infinite normal section cancel. In a finite domain, flow can still cross a lateral boundary; that boundary is not a solid wall and its biomass flux must remain accounted for.

The code sets psi=0 at d=0 and at/below the diffuser outlet, including the seabed. Thus partial psi/partial n=0 there: the added water field has no vertical boundary penetration. Nonzero horizontal surface flow is permitted. The 0.05 m numerical particle clearance from each boundary is a numerical convention, not the finite size of a real animal.

This is a **divergence-free surrogate**, not the published Beelen-Krug model. That primary study normalizes the Gaussian nozzle superposition, then solves mass, momentum and bubble transport through the round-to-planar transition. Its freshwater calibration cannot be assumed valid for this Gulf installation. [Beelen & Krug, 2024](https://arxiv.org/html/2401.09771v1)

### Amplitude and gas accounting

The amplitude uses a planar buoyancy/slip speed scale. For a uniform, steady, unstratified top-hat line plume per metre of diffuser,

    Q = 2 b w, M = 2 b w²,
    dQ/dh = 2 alpha w,
    dM/dh = g q_g(h)/(w + v_s).

Q is liquid volume flux (m2/s), M is kinematic momentum flux (m3/s2), h is height above the outlet (m), w is liquid speed (m/s), q_g is gas volume flow per metre (m2/s), and v_s is bubble slip speed (m/s). A constant-q_g similarity balance gives

    w²(w + v_s) = g q_g/(2 alpha).

The code solves this positive speed scale but does **not** integrate those plume equations as a complete solver. The surface taper, end window, return width and entrainment coefficient remain assumed closure choices. The core speed after return-flow subtraction is lower than the amplitude U. Summing separate diffuser circulation fields preserves continuity but does not solve nonlinear interactions between curtains.

Gas flow is defined at 101325 Pa and 293.15 K. The local isothermal/ideal-gas estimate is

    p(d) = p_atm + rho_water g d,
    q_g(d) = q_reference p_atm/p(d) * T_air/T_reference.

Using seawater temperature for T_air assumes the rising gas equilibrates with the water. Dissolution, bubble breakup, coalescence, uneven supply, nozzle fouling and gas leakage are not solved. Crossflow displacement uses a rise-time estimate; it is not a conserved vector momentum calculation. Published integral multiphase models treat crossflow entrainment and stratification explicitly. [Dissanayake et al., 2018](https://link.springer.com/article/10.1007/s10652-018-9591-y)

The compressor estimate is

    power = p_atm Q_reference ln(p_delivery/p_atm)/efficiency,
    p_delivery = p_atm + rho_water g d_outlet + assumed_line_loss.

Divide by 1000 to obtain kW. The candidate assumes 55% efficiency and 15 kPa line loss. This is a screening calculation, not a supplier performance curve; startup, distribution piping and duty constraints need measurement.

### Why bubbles cannot guarantee capture

A jellyfish follows the **water** velocity and its own behavior, not the bubble slip speed. Required lift time is approximately depth change divided by water upflow. Available exposure is approximately plume width divided by current normal to the plume. A 6 m rise at 0.1 m/s takes 60 s; crossing a 2 m plume at 0.12 m/s takes only about 17 s. These illustrative values explain why an enabled narrow curtain can leave deep animals below a half-depth skirt.

Moving a narrow curtain upstream alone does not guarantee longer exposure. Strong currents, turbulence, swim behavior and return circulation can carry animals through or back down. Real bubble curtains generate recirculation and alter near-bed and surface current profiles. [Covarrubias-Contreras et al., 2025](https://link.springer.com/article/10.1007/s10652-025-10029-1)

Jellyfish exclusion experiments have shown mixed field outcomes, and wave-driven movement can cross the curtain. Those results are not a measured capture probability for Blue Blubber jellyfish at Barakah. [Haberlin et al., 2021](https://research.ucc.ie/en/publications/field-and-flume-tank-experiments-investigating-the-efficacy-of-a/)

## Candidate geometry and capacity

| Quantity | Candidate assumption | Consequence |
| --- | --- | --- |
| Water depth | Flat 12 m domain | No surveyed bathymetry, tidal depth change or local shoals |
| Two skirts | 11.8 m deep, nominal 0.2 m bed gap; assumed 0.225 m jellyfish half-height | Guide contact checks the body extent, not just its center. A rough seabed, flexible net or gap can still create bypass |
| Domain width | 200 m | A hypothetical interception corridor, not measured intake-channel width |
| Source corridor | y=42–158 m | Assumes a 116 m incoming bloom corridor inside the wider interception domain; widening the source is an essential sensitivity check |
| Contact probabilities | Outer 0.90, second 0.80 | Uncalibrated conditional probabilities, not calculated from jellyfish shape or hydrodynamic forces. The 45 cm image reference is represented only as an assumed 0.225 m vertical half-height |
| Clearing rate | 2400 kg/h at each band | Must be demonstrated with a physical collector, wet biomass and debris |
| Conveyance | 0.2 m/s horizontal and 0.04 m/s upward | Requires an engineered powered mechanism, retention design and power/torque measurements |
| Transport | Two 900 kg resources | Scheduled payload/time abstraction, not navigation, stability or docking simulation |
| Destination | Finite hypothetical shore receiving | No uncontrolled sea release; actual receiving, handling and ecological approvals remain open |

For independent contacts that actually occur within covered depth and available capacity, probabilities 0.90 and 0.80 give a nominal miss fraction of (1-0.90)(1-0.80)=2%. This is arithmetic under assumptions, not evidence that the two contacts are independent or that both probabilities are achievable. Shared underflow, net deformation, debris and weather can invalidate that expectation.

Nearly full-depth porous guides require more material, stronger anchors, larger powered conveyance and more maintenance. They also increase animal contact, bycatch/entanglement opportunity and interactions with benthic habitat. Mesh size, deformation and open-area fraction are unresolved. The candidate cannot claim lower whole-life cost or acceptable ecological impact merely because simulated leakage decreases.

## Environmental inputs and unresolved physics

| Input | Current representation | Needed for a site prediction |
| --- | --- | --- |
| Currents | Regional surface point values, projected and scaled, plus an assumed intakeward component | ADCP profiles, tides, pump demand, crossflow, reversal and a calibrated local flow field |
| Waves | Heights/periods loaded; illustrative operating closures and scripted adverse contact cases | Orbital velocity, wave direction, Stokes drift, breaking and net/collector motion |
| Wind | Regional 10 m wind and illustrative vessel availability limits | Local wind-wave coupling, floating boom response and confirmed operating envelope |
| Sea level | Loaded and checked, not used to solve hydraulics | Tide-dependent depth, freeboard, skirt clearance and intake levels |
| Temperature | Uniform sensitivity value, used for density and gas expansion | Measured vertical profiles and temperature-dependent equipment/biology behavior |
| Salinity | Uniform sensitivity value, used for density | Density stratification, bubble behavior and species response |

Density uses the atmospheric-pressure EOS-80 polynomial with explicit input limits; it does not create a stratified water column. Temperature and salinity sweeps therefore test only the effects represented in the code. The density reference comes from the UNESCO algorithms. [Fofonoff & Millard, 1983](https://www.vliz.be/imisdocs/publications/ocrd/122840.pdf)

The model does not solve Navier-Stokes momentum, turbulence production, wave transport, two-phase bubbles, fluid-structure coupling, net clogging/deformation, or jellyfish body dynamics. A 0.225 m vertical half-height only prevents the 45 cm reference animal from numerically protruding through the surface/seabed or being treated as a point when it reaches a skirt; it does not resolve a deformable bell shape. Diffusion is a chosen mixing parameter. Cohorts are weighted biomass parcels, so a 12 kg mark is not an individual jellyfish. The paired depth counterfactual is a diagnostic, not an animal-scale experiment.

## Hydraulic proxy: what it can and cannot say

The candidate supplies clean solidity, a strand drag coefficient, a nominal span and illustrative force/headloss limits for preliminary screening. Any drag/headloss calculation made with them is a **proxy**, not a validated pressure-drop solver or ENEC limit.

It can show how normal current speed, material blockage and loading increase a drag estimate. It cannot establish the actual cooling-water flow loss, pump operating margin, mooring safety, net shape or flow redistribution. Jellyfish mass is not itself net blockage area; bell area, packing, attachment and debris must be measured. Loads from waves, anchoring geometry, seabed stiffness, fatigue, marine growth and failure transients also need engineering review. A proxy below its assumed threshold is not approval to install a deeper net.

## Datasets and what the simulation measures

Regional ERA5 wind/wave and SMOC surface-current records provide environmental scenario forcing. Their provider points differ geographically; interpolation is in time, not a reconstructed local channel field. The input hashes and selection windows should be retained with every result.

OBIS biological occurrence records establish reported occurrence context. They do not supply observed local bloom arrival rates, vertical distributions, individual mass, swim speeds, handling survival or net-contact efficiency. The 1200 kg/h reference arrivals, uniform depth distribution, 0.5 kg animal-equivalent conversion and contact probabilities are synthetic inputs. No trained ML/CV detector is used; perception errors are emulated separately.

Interpret the result using all three questions:

1. How much biomass passed intakeward, left an unresolved boundary, or remained free?
2. How much was intercepted but still held?
3. How much actually reached the modeled receiving destination before the observation ended?

Mass closure prevents numerical disappearance. It does not prove safe handling or real delivery. A target should fail if side exits are hidden, inventory exceeds its limits, or removal remains incomplete beyond an allowed holding time.

## Concrete calibration plan

1. **Measure the site envelope:** bathymetry, tidal clearance, ADCP depth profiles, wave direction, permitted hydraulic restriction and space for guides/collectors. Replace the corridor hypothesis with measured arrival cross-sections.
2. **Measure the bubble field:** test one short seabed diffuser in saline water; record standard gas delivery, pressure, liquid upflow, width, crossflow displacement, surface flow and return flow. Fit uncertain coefficients and verify on separate runs.
3. **Measure interception and handling:** use appropriately approved jellyfish or validated physical surrogates; vary depth, current, mesh gap, loading and debris. Measure contacts, escapes, powered lift throughput, injury and non-target catch. Establish dependence between the two bands rather than assuming independence.
4. **Validate hydraulic and mechanical margins:** measure net pressure drop, deformation, blockage, anchor loads, actual collector torque/power and wet payload. Couple these measurements to the local hydraulic model.
5. **Check resilience:** repeat low-slip trials with the full source width, faster/deeper flow, strong mixing, reduced contact probability, power/collector/transport outages and rough water. Report distributions across seeds and numerical refinement, not one favorable number.
6. **Require independent evidence before a field claim:** retain a withheld forcing period and physical trial; compare observed trajectories, capture and delivery with predicted values. Define the below-5% target together with flow restriction, animal outcomes, holding time and total operating cost.

Until those steps are complete, MARLIN v4 is useful for design comparison and identifying requirements. It cannot certify a 95% field capture rate or that every relevant law of physics has been solved.
