# MARLIN v4 simulation

This is a conditional research scenario, not a field-performance claim. It runs 36 reference, weather, bloom, equipment, geometry, temperature/salinity and numerical sensitivity cases. The invariant checks run first; any failure stops the run.

From the MARLIN project root in PowerShell:

```powershell
& "C:\Users\Abdul Bari\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" ".\simulation\v4\run_scenarios.py"
```

Open the generated `outputs\v4\low-slip\report.html` through the existing local MARLIN web server. The result folder also includes `results.json`, `scenario_summary.csv`, and `RUN_REPORT.md`.

The target counts free biomass, intakeward passage and unknown exits as uncaptured. It also requires no unfinished collection or pre-delivery holding-age exceedance. Shore receiving is a finite modeled destination; downstream processing and animal survival are not modeled. Bubbles are off in the low-energy baseline; the airlift and wall run separately as an optional comparison. No trained ML/CV runs.

See `PHYSICS_REVIEW.md` for equations, corrected defects, scientific assumptions, limits and a flume/site calibration plan. Run `python .\simulation\v4\test_physics.py` to repeat the focused checks.
