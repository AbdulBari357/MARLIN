"""Short invariant checks for MARLIN's uncalibrated screening model.

These checks establish code consistency, not field efficacy, animal survival,
hydraulic approval, or a solved momentum/two-phase flow model.
"""
import copy
import json
import math
from pathlib import Path
import unittest

from engine import Inventory, Lot, Particle, Simulation, seawater_density


class ConstantForcing:
    window = {"label": "synthetic_invariant_check"}

    def at(self, minute):
        return {
            "wave_height": 0.1, "wave_period": 3.0,
            "wind_speed_10m": 0.0, "wind_u_east_m_s": 0.0,
            "wind_v_north_m_s": 0.0, "current_u_east_m_s": 0.0,
            "current_v_north_m_s": 0.0, "sea_level_height_msl": 0.0,
        }

    def metadata(self):
        return {"status": "synthetic constant forcing, invariant check only"}


def configuration():
    cfg = json.loads(Path(__file__).with_name("candidate.json").read_text(encoding="utf-8"))
    cfg["geometry"]["horizontal_dispersion_m2_s"] = 0.0
    cfg["geometry"]["vertical_dispersion_m2_s"] = 0.0
    cfg["external_rate_kg_h"] = 0.0
    cfg["arrival_hours"] = 0.01
    cfg["observation_hours"] = 0.02
    cfg["return_fraction"] = 0.0
    return cfg


def simulation(cfg=None, variant="two_off"):
    return Simulation(configuration() if cfg is None else cfg, ConstantForcing(),
                      "reference", variant, 20261011, detail=True)


def install_particle(sim, x=20.0, y=100.0, z=6.0, state="free", band=-1, kg=12.0):
    p = Particle(0, 0, kg, x, y, z, z, state=state, band=band)
    sim.particles = [p]
    sim.external = kg
    if state == "guided":
        sim.bands[band]["guided_kg"] = kg
    return p


class BoundaryAndCirculationTests(unittest.TestCase):
    def test_surface_advection_clamps_without_downward_bounce(self):
        sim = simulation()
        p = install_particle(sim, z=0.1)
        sim.velocity = lambda x, y, t, depth=0: (0.0, 0.0)
        sim.bubble_path_average = lambda *args: 1.0
        sim.move(0.5)
        self.assertAlmostEqual(p.z, 0.225, places=12)
        self.assertAlmostEqual(sim.accounting()["mass_error_kg"], 0.0)

    def test_bottom_advection_clamps_without_upward_bounce(self):
        sim = simulation()
        p = install_particle(sim, z=11.9)
        sim.velocity = lambda x, y, t, depth=0: (0.0, 0.0)
        sim.bubble_path_average = lambda *args: -1.0
        sim.move(0.5)
        self.assertAlmostEqual(p.z, 11.775, places=12)

    def test_diffusion_reflection_stays_within_bounds(self):
        sim = simulation()
        for depth in (-1000, -1, 0, 0.05, 6, 11.95, 12, 1000):
            with self.subTest(depth=depth):
                reflected = sim.reflect_depth(depth)
                self.assertGreaterEqual(reflected, 0.225 - 1e-12)
                self.assertLessEqual(reflected, 11.775 + 1e-12)
        self.assertAlmostEqual(sim.reflect_depth(-1), 1.45)

    def test_spawn_respects_assumed_bell_extent(self):
        sim = simulation()
        sim.spawn(1.0)
        radius = sim.cfg['biology']['assumed_bell_vertical_half_height_m']
        self.assertGreaterEqual(sim.particles[0].z, radius)
        self.assertLessEqual(sim.particles[0].z, sim.cfg['geometry']['water_depth_m'] - radius)

    def test_bell_extent_increases_skirt_contact_depth(self):
        sim = simulation()
        band = sim.bands[0]['cfg']
        body = sim.cfg['biology']['assumed_bell_vertical_half_height_m']
        self.assertGreater(band['skirt_depth_m'] + body, band['skirt_depth_m'])

    def test_circulation_has_no_vertical_boundary_penetration(self):
        sim = simulation(variant="two_airlift_plus_wall")
        for depth in (0.0, 11.9, 12.0):
            for x in (45, 70, 90, 110, 132):
                with self.subTest(depth=depth, x=x):
                    self.assertAlmostEqual(sim.bubble_upwelling(x, 100, depth, 0), 0.0, places=11)

    def test_finite_difference_water_divergence_is_zero(self):
        sim = simulation(variant="two_airlift_plus_wall")
        eps = 0.002  # Match the internal centered derivative stencil.
        for x, y, z in ((70, 100, 6), (75, 100, 3), (110, 100, 6),
                        (85, 3, 1), (130, 196, 8), (75, 100, 11.8)):
            with self.subTest(x=x, y=y, z=z):
                du = (sim.velocity(x+eps, y, 0, z)[0] - sim.velocity(x-eps, y, 0, z)[0])/(2*eps)
                dv = (sim.velocity(x, y+eps, 0, z)[1] - sim.velocity(x, y-eps, 0, z)[1])/(2*eps)
                dz = (-sim.bubble_upwelling(x, y, z+eps, 0) + sim.bubble_upwelling(x, y, z-eps, 0))/(2*eps)
                self.assertAlmostEqual(du + dv + dz, 0.0, delta=2e-6)

    def test_signed_circulation_contains_upflow_and_return_flow(self):
        sim = simulation(variant="two_airlift_plus_wall")
        vals = [sim.bubble_upwelling(x, 100, 6, 0) for x in range(50, 141)]
        self.assertGreater(max(vals), 0)
        self.assertLess(min(vals), 0)

    def test_path_exposure_matches_actual_signed_field(self):
        sim = simulation(variant="two_airlift_plus_wall")
        x0, x1, y, z = 65.0, 85.0, 100.0, 6.0
        actual = sim.bubble_path_average(x0, y, x1, y, z, 0)
        n = 1600
        reference = sum(sim.bubble_upwelling(x0+(i+.5)*(x1-x0)/n, y, z, 0)
                        for i in range(n))/n
        self.assertAlmostEqual(actual, reference, delta=0.0002)


class GuidanceCaptureAndAccountingTests(unittest.TestCase):
    def test_passive_guide_has_no_motion_with_zero_water_flow(self):
        cfg = configuration()
        cfg["geometry"]["guide_transport_mode"] = "passive"
        sim = simulation(cfg)
        p = install_particle(sim, x=100, y=40, state="guided", band=0)
        sim.velocity = lambda x, y, t, depth=0: (0.0, 0.0)
        before = (p.x, p.y, p.z)
        sim.move(0.5)
        self.assertEqual((p.x, p.y, p.z), before)
        self.assertEqual(p.state, "guided")

    def test_powered_guide_speed_uses_metres_per_second(self):
        sim = simulation()
        p = install_particle(sim, x=100, y=40, state="guided", band=0)
        before = (p.x, p.y)
        sim.move(0.5)
        self.assertAlmostEqual(math.dist(before, (p.x, p.y)), 6.0, places=10)
        self.assertAlmostEqual(p.z, 4.8, places=10)

    def test_deep_animal_cannot_enter_surface_collector_without_lift(self):
        cfg = configuration()
        cfg["geometry"]["guide_transport_mode"] = "passive"
        sim = simulation(cfg)
        x, y = cfg["bands"][0]["end"]
        p = install_particle(sim, x=x, y=y, z=6, state="guided", band=0)
        sim.velocity = lambda x, y, t, depth=0: (0.0, 0.0)
        sim.move(0.5)
        self.assertEqual(p.state, "guided")
        self.assertEqual(sim.bands[0]["net"].kg, 0)
        self.assertEqual(sim.bands[0]["guided_kg"], 12)

    def test_explicit_lift_precedes_collection(self):
        sim = simulation()
        x, y = sim.cfg["bands"][0]["end"]
        p = install_particle(sim, x=x, y=y, z=6, state="guided", band=0)
        sim.move(0.5)
        self.assertEqual(p.state, "guided")
        self.assertAlmostEqual(p.z, 4.8)
        for _ in range(5):
            sim.move(0.5)
        self.assertEqual(p.state, "inventory")
        self.assertAlmostEqual(p.z, 0.2)
        self.assertEqual(sim.bands[0]["net"].kg, 12)
        self.assertEqual(sim.accounting()["mass_error_kg"], 0)

    def test_capture_probability_extremes(self):
        for probability, expected in ((0.0, "free"), (1.0, "guided")):
            with self.subTest(probability=probability):
                cfg = configuration()
                cfg["bands"][0]["start"] = [30, 0]
                cfg["bands"][0]["end"] = [30, 200]
                cfg["bands"][0]["intercept_probability"] = probability
                sim = simulation(cfg)
                p = install_particle(sim, x=29, z=2)
                sim.velocity = lambda x, y, t, depth=0: (1.0, 0.0)
                sim.move(0.05)
                self.assertEqual(p.state, expected)
                self.assertAlmostEqual(sim.accounting()["mass_error_kg"], 0)

    def test_depth_bypass_is_not_captured(self):
        cfg = configuration()
        cfg["bands"][0].update(start=[30, 0], end=[30, 200], intercept_probability=1.0, skirt_depth_m=3)
        sim = simulation(cfg)
        p = install_particle(sim, x=29, z=6)
        sim.velocity = lambda x, y, t, depth=0: (1.0, 0.0)
        sim.move(0.05)
        self.assertEqual(p.state, "free")
        self.assertTrue(any(g["code"] == "depth_bypass" for g in sim.gaps.values()))

    def test_capture_and_receiver_capacity_limits_conserve_mass(self):
        cfg = configuration()
        cfg["bands"][0].update(start=[30, 0], end=[30, 200], intercept_probability=1.0, capture_load_limit_kg=12)
        sim = simulation(cfg)
        p = install_particle(sim, x=29, z=2)
        sim.velocity = lambda x, y, t, depth=0: (1.0, 0.0)
        sim.move(0.05)
        self.assertEqual(p.state, "free")  # 80% load reserve cannot fit this cohort.
        self.assertEqual(sim.accounting()["mass_error_kg"], 0)
        sim.particles = []
        sim.bands[0]["net"].add(Lot(12, 0, 0, 0))
        sim.bands[0]["cfg"]["receiver_capacity_kg"] = 5
        sim.collect(1)
        self.assertEqual(sim.bands[0]["receiver"].kg, 5)
        self.assertEqual(sim.bands[0]["net"].kg, 7)
        self.assertEqual(sim.accounting()["mass_error_kg"], 0)

    def test_zero_collector_rate_does_not_remove_mass(self):
        sim = simulation()
        sim.external = 12
        sim.bands[0]["net"].add(Lot(12, 0, 0, 0))
        sim.bands[0]["cfg"]["collector_rate_kg_h"] = 0
        sim.collect(1)
        self.assertEqual(sim.bands[0]["net"].kg, 12)
        self.assertEqual(sim.bands[0]["receiver"].kg, 0)
        self.assertEqual(sim.accounting()["mass_error_kg"], 0)

    def test_side_exit_is_unresolved_not_captured(self):
        sim = simulation()
        p = install_particle(sim, x=20, y=199.9, z=2)
        sim.velocity = lambda x, y, t, depth=0: (0.0, 1.0)
        sim.move(0.05)
        result = sim.run()["summary"]
        self.assertEqual(p.state, "left_domain")
        self.assertEqual(result["uncaptured_percent"], 100)
        self.assertEqual(result["terminal_captured_percent"], 0)

    def test_short_run_mass_and_percentage_closure(self):
        cfg = configuration()
        cfg["external_rate_kg_h"] = 1200
        result = simulation(cfg).run()["summary"]
        self.assertAlmostEqual(result["external_kg"], 12)
        self.assertLess(result["max_accounting_error_kg"], 1e-8)
        self.assertAlmostEqual(result["uncaptured_percent"] + result["terminal_captured_percent"], 100)

    def test_partial_shore_delivery_retains_excess_onboard(self):
        cfg = configuration()
        cfg["vessel"]["shore_receiving_capacity_kg"] = 5
        sim = simulation(cfg)
        sim.external = 12
        boat = sim.boats[0]
        boat.update(state="unloading", remaining=0, band=0, trip=0)
        boat["cargo"].add(Lot(12, 0, 0, 0))
        sim.trips.append({"phases": [], "loaded_kg": 12, "released_kg": 0,
                          "release_minute": None, "completed_minute": None})
        sim.boats_step(0.5)
        self.assertEqual(sim.released, 5)
        self.assertEqual(boat["cargo"].kg, 7)
        self.assertEqual(boat["state"], "unloading")
        self.assertEqual(sim.pending_returns, [])
        self.assertEqual(sim.accounting()["mass_error_kg"], 0)
        sim.boats_step(0.5)
        self.assertEqual(sim.released, 5)
        self.assertEqual(boat["cargo"].kg, 7)
        self.assertFalse(sim.release_open())

    def test_two_vessels_cannot_overfill_common_shore_receiving(self):
        cfg = configuration()
        cfg["vessel"]["shore_receiving_capacity_kg"] = 5
        sim = simulation(cfg)
        sim.external = 24
        for i, boat in enumerate(sim.boats):
            boat.update(state="unloading", remaining=0, band=i, trip=i)
            boat["cargo"].add(Lot(12, 0, i, 0))
            sim.trips.append({"phases": [], "loaded_kg": 12, "released_kg": 0,
                              "release_minute": None, "completed_minute": None})
        sim.boats_step(0.5)
        self.assertEqual(sim.released, 5)
        self.assertEqual(sum(b["cargo"].kg for b in sim.boats), 19)
        self.assertEqual(sim.accounting()["mass_error_kg"], 0)

    def test_departed_vessel_does_not_reserve_pickup_berth(self):
        cfg = configuration()
        sim = simulation(cfg)
        sim.external = 312
        sim.bands[0]["receiver"].add(Lot(300, 0, 1, 0))
        boat = sim.boats[0]
        boat.update(state="release_travel", remaining=999, band=0, trip=0)
        boat["cargo"].add(Lot(12, 0, 0, 0))
        sim.trips.append({"phases": [], "loaded_kg": 12, "released_kg": 0,
                          "release_minute": None, "completed_minute": None})
        sim.boats_step(0.5)
        self.assertEqual(sim.boats[1]["state"], "pickup_travel")
        self.assertEqual(sim.boats[1]["band"], 0)
        self.assertEqual(sim.accounting()["mass_error_kg"], 0)


class DensityGasAndValidationTests(unittest.TestCase):
    def test_reference_seawater_density(self):
        self.assertAlmostEqual(seawater_density(15, 35), 1025.97, delta=0.02)
        self.assertGreater(seawater_density(15, 40), seawater_density(15, 35))

    def test_eos_outside_range_is_rejected(self):
        for temperature, salinity in ((-1, 35), (41, 35), (15, -1), (15, 43)):
            with self.subTest(temperature=temperature, salinity=salinity):
                with self.assertRaises(ValueError):
                    seawater_density(temperature, salinity)

    def test_compressor_power_is_positive_and_scales_with_flow(self):
        cfg = configuration()
        first = simulation(cfg, "two_airlift_plus_wall").compressor_power_kw()
        cfg["bubble"]["gas_flow_per_metre_m3_s_m"] *= 2
        second = simulation(cfg, "two_airlift_plus_wall").compressor_power_kw()
        self.assertGreater(first, 0)
        self.assertAlmostEqual(second, 2*first, places=12)
        self.assertEqual(simulation(cfg, "two_off").compressor_power_kw(), 0)

    def test_delivered_gas_matches_line_lengths(self):
        sim = simulation(variant="two_airlift_plus_wall")
        sim.bubble_active_minutes = 1
        expected = sum(math.dist(s["diffuser_start_xy_m"], s["diffuser_end_xy_m"])
                       for s in sim.cfg["bubble"]["diffusers"])*0.00015*3600
        self.assertAlmostEqual(sim.bubble_gas_flow_m3_h(), expected, places=10)

    def test_invalid_configuration_is_rejected(self):
        changes = [
            ("probability_negative", lambda c: c["bands"][0].update(intercept_probability=-0.1)),
            ("probability_above_one", lambda c: c["bands"][0].update(intercept_probability=1.1)),
            ("negative_diffusion", lambda c: c["geometry"].update(vertical_dispersion_m2_s=-0.1)),
            ("zero_width", lambda c: c["geometry"].update(width_m=0)),
            ("bad_corridor", lambda c: c["geometry"].update(source_y_min_m=160, source_y_max_m=100)),
            ("bad_depth", lambda c: c["biology"].update(initial_depth_min_m=20)),
            ("bad_efficiency", lambda c: c["bubble"].update(isothermal_compressor_efficiency=0)),
            ("bad_diffuser_clearance", lambda c: c["bubble"]["diffusers"][0].update(diffuser_bottom_clearance_m=13)),
            ("negative_diffuser_flow", lambda c: c["bubble"]["diffusers"][0].update(gas_flow_per_metre_m3_s_m=-1)),
            ("empty_diffuser", lambda c: c["bubble"]["diffusers"][0].update(diffuser_end_xy_m=[45, 0])),
            ("missing_vessel_timing", lambda c: c["vessel"].update(pickup_travel_minutes_by_band=[])),
            ("sensor_probability", lambda c: c["sensor"].update(detect_probability=1.1)),
            ("negative_pickup_depth", lambda c: c["bands"][0].update(collector_pickup_depth_m=-1)),
            ("negative_line_pressure", lambda c: c["bubble"].update(air_line_pressure_loss_pa=-1000000)),
            ("negative_planar_entrainment", lambda c: c["bubble"].update(planar_entrainment_coefficient=-0.1)),
            ("negative_shore_capacity", lambda c: c["vessel"].update(shore_receiving_capacity_kg=-1)),
        ]
        for label, mutate in changes:
            with self.subTest(label=label):
                cfg = configuration()
                mutate(cfg)
                with self.assertRaises(ValueError):
                    simulation(cfg)


if __name__ == "__main__":
    unittest.main(verbosity=2)
