"""Reproducible screening suite; no trained detection or equipment control."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,copy,csv,json,statistics,time
import unittest
from engine import simulate,DISCLAIMER
from forcing import Forcing
from diagnostics import environmental_audit
from report import write_report

class Overrides:
    def __init__(self,base,values): self.base=base;self.values=values;self.window=base.window
    def at(self,t): return self.base.at(t)|self.values
    def metadata(self): return self.base.metadata()|{'synthetic_overrides':self.values}

def make_jobs(cfg):
    jobs=[]
    def add(id,label,c=None,window='quarter_1_first_complete_week',scenario='reference',variant='two_airlift_plus_wall',detail=True,overrides=None):
        jobs.append(dict(id=id,label=label,cfg=copy.deepcopy(c or cfg),window=window,scenario=scenario,variant=variant,detail=detail,overrides=overrides or {}))
    old=copy.deepcopy(cfg);old['geometry'].update(width_m=120,source_y_min_m=2,source_y_max_m=118)
    for i,b in enumerate(old['bands']): b.update(start=[100+i*105,3],end=[135+i*105,117],skirt_depth_m=6)
    third=copy.deepcopy(old['bands'][1]);third.update(name='inner',start=[285,3],end=[320,117],intercept_probability=.75)
    old['bands'].append(third);old['vessel']['pickup_travel_minutes_by_band'].append(5)
    old['bubble']['diffusers']=[dict(name='Seabed airlift',role='airlift',diffuser_start_xy_m=[55,3],diffuser_end_xy_m=[90,117]),dict(name='Near-outer wall',role='curtain',diffuser_start_xy_m=[92,3],diffuser_end_xy_m=[127,117])]
    add('previous_geometry','Previous three half-depth guides · corrected transport',old,variant='three_airlift_plus_wall')
    add('target','Candidate · two deep guides (bubbles OFF)',variant='two_off')
    add('bubble_assist','Optional seabed airlift + near-outer bubble wall')
    add('high_current','Candidate · strongest current window (bubbles OFF)',window='high_current_week',variant='two_off')
    add('high_waves','Candidate · strongest wave window (bubbles OFF)',window='high_wave_week',variant='two_off')
    add('storm_off','2 m waves + 14 m/s wind · bubbles OFF',scenario='storm',variant='two_off')
    add('storm','Candidate · 2 m waves + 14 m/s wind for 2 hours',scenario='storm')
    add('overload','Candidate · triple bloom load',scenario='overload')
    add('outer_outage','Candidate · outer collector stops for 2 hours',scenario='outer_outage')
    deep=copy.deepcopy(cfg);deep['geometry']['water_depth_m']=12.8
    add('deeper_water','Candidate · water 0.8 m deeper, same skirts',deep)
    deep_bloom=copy.deepcopy(cfg);deep_bloom['biology'].update(initial_depth_min_m=9.5,bottom_clearance_m=0.05,initial_depth_max_fraction=0.995)
    add('deep_bloom','Bloom concentrated within 0.3 m of seabed',deep_bloom,variant='two_off')
    highmix=copy.deepcopy(cfg);highmix['geometry']['vertical_dispersion_m2_s']=0.02
    add('high_vertical_mixing','10× vertical mixing sensitivity',highmix,variant='two_off',detail=False)
    correlated=copy.deepcopy(cfg);correlated['capture_correlation']=1.0
    add('shared_escape','Candidate · penetration risk shared across guides',correlated)
    for label in ['quarter_2_first_complete_week','quarter_3_first_complete_week','quarter_4_first_complete_week']:
        add(label,label.replace('_',' '),window=label,detail=False)
    for T,S in [(20,35),(20,42),(36,35),(36,42)]:
        c=copy.deepcopy(cfg);c['environment'].update(temperature_c=T,salinity_psu=S)
        add(f'temp_{T}_salt_{S}',f'{T} °C / {S} PSU sensitivity',c,detail=False)
    for i in range(1,11):
        c=copy.deepcopy(cfg);c['seed']+=i
        add(f'seed_off_{i}',f'Bubble-OFF repeat seed {c["seed"]}',c,variant='two_off',detail=False)
    for i in range(1,4):
        c=copy.deepcopy(cfg);c['seed']+=i
        add(f'seed_on_{i}',f'Bubble-ON repeat seed {c["seed"]}',c,detail=False)
    c=copy.deepcopy(cfg);c['step_seconds']=15
    add('step_15','Half timestep · 15 s',c,detail=False)
    c=copy.deepcopy(cfg);c['cohort_kg']=6
    add('cohort_6','Half cohort mass · 6 kg',c,detail=False)
    # Combination of current stress and delivery closure is deliberately not tuned away.
    add('cross_current','Strong transverse-current sensitivity',detail=False,overrides={'current_u_east_m_s':.08,'current_v_north_m_s':.70})
    return jobs

def worker(root,job):
    c=job['cfg'];flow=Forcing(Path(root)).select(job['window'],c['observation_hours'])
    if job['overrides']: flow=Overrides(flow,job['overrides'])
    begin=time.monotonic();r=simulate(c,flow,job['scenario'],job['variant'],c['seed'],detail=job['detail'])
    r.update(case_id=job['id'],variant_label=job['label'],environment=environmental_audit(c,flow,job['scenario']))
    s=r['summary']
    s['passes_numerical_target']=s['uncaptured_percent']<5 and s['held_kg']<1e-6 and not s['numerical_held_age_flag']
    s['hydraulic_proxy_within_assumed_limits']=r['environment']['proxy_within_assumed_limits']
    r['elapsed_seconds']=time.monotonic()-begin
    if not job['detail']:
        for key in ('frames','series','lifecycle','trips','events'): r[key]=[]
    return r

def main():
    suite=unittest.defaultTestLoader.discover(str(Path(__file__).parent),pattern='test_physics.py')
    test_result=unittest.TextTestRunner(verbosity=0).run(suite)
    if not test_result.wasSuccessful(): raise SystemExit('Physics invariant tests failed; simulation stopped.')
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);parser.add_argument('--output',type=Path)
    args=parser.parse_args();root=args.root.resolve();config=Path(__file__).with_name('candidate.json')
    if not config.exists(): config=root/'config/model_low_slip_v4.json'
    cfg=json.loads(config.read_text(encoding='utf-8'));out=args.output or root/'outputs/v4/low-slip';out.mkdir(parents=True,exist_ok=True)
    jobs=make_jobs(cfg);results={}
    with ProcessPoolExecutor(max_workers=3) as pool:
        fs={pool.submit(worker,str(root),job):job['id'] for job in jobs}
        for f in as_completed(fs):
            try: r=f.result()
            except Exception as exc:
                print(f"FAILED {fs[f]}: {type(exc).__name__}: {exc}",flush=True);continue
            results[r['case_id']]=r;s=r['summary']
            print(f"Completed {r['case_id']}: uncaptured={s['uncaptured_percent']:.2f}%, delivered={s['delivered_percent']:.2f}%, held={s['held_percent']:.2f}%, age={s['oldest_holding_minutes']:.1f} min",flush=True)
            (out/'checkpoint.json').write_text(json.dumps({'completed':len(results),'total':len(jobs),'case':r['case_id']},separators=(',',':')),encoding='utf-8')
            (out/'partial_results.json').write_text(json.dumps(list(results.values()),ensure_ascii=False,allow_nan=False,separators=(',',':')),encoding='utf-8')
    if len(results)!=len(jobs): print(f"WARNING: {len(results)} of {len(jobs)} cases completed; failed runs are not presented as passing.",flush=True)
    ordered=[results[j['id']] for j in jobs];runs=[r for r in ordered if r['frames']];checks=[r for r in ordered if not r['frames']]
    payload=dict(model='MARLIN v4 low-slip design screening',disclaimer=DISCLAIMER,config=cfg,runs=runs,checks=checks,
      target_definition='Below 5% of arrivals remaining free, crossing intakeward boundary, or leaving by an unknown side/upstream route; no unfinished handling or assumed holding-age exceedance.',
      qualification='Numerical target only; independent interception probabilities .90/.80 and hypothetical coverage, powered transport, shore receiving remain unvalidated.',
      factor_coverage={'wind':'ERA5 wind controls vessel availability. Direct aerodynamic/structural wind load not resolved.',
       'waves':'ERA5 height/period controls boats; regular-wave screen load proxy; storm contact loss sensitivity. No irregular-wave particle dynamics.',
       'currents':'SMOC time interpolation + prescribed local component; three-dimensional flow and intake/net feedback unmeasured.',
       'temperature_salinity':'20/36 °C and 35/42 PSU synthetic tests via EOS-80 density, gas expansion and compressor pressure. No measured local thermal/haline profile.',
       'tides_depth':'Regional sea-level ranges reported. Fixed-depth +0.8 m clearance sensitivity; no moving-surface tidal solver.',
       'biology':'Synthetic uniform depth and 1200 kg/h arrivals; public species occurrences do not supply local abundance or capture physics.'},
      references=['https://arxiv.org/html/2401.09771v1','https://link.springer.com/article/10.1007/s10652-025-10029-1','https://research.ucc.ie/en/publications/field-and-flume-tank-experiments-investigating-the-efficacy-of-a/','https://legacy.repository.oceanbestpractices.org/handle/11329/109'],
      numerical_audit={'tests_passed':test_result.testsRun,'test_file':'simulation/v4/test_physics.py','max_mass_error_kg':max(r['summary']['max_accounting_error_kg'] for r in ordered)})
    (out/'results.json').write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False,separators=(',',':')),encoding='utf-8')
    rows=[]
    for r in ordered:
        s=r['summary'];rows.append(dict(case=r['case_id'],label=r['variant_label'],uncaptured_pct=s['uncaptured_percent'],intakeward_pct=s['residual_percent'],unknown_exit_pct=s['unknown_exit_percent'],delivered_pct=s['delivered_percent'],held_pct=s['held_percent'],maximum_holding_min=s['oldest_holding_minutes'],numerical_target=s['passes_numerical_target'],bubble_kwh=s['bubble_kwh'],total_kwh=s['total_kwh'],density_kg_m3=s['density_kg_m3'],mass_error_kg=s['max_accounting_error_kg'],hydraulic_proxy_ok=r['environment']['proxy_within_assumed_limits']))
    with (out/'scenario_summary.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    write_report(out,payload,rows)
    print(json.dumps({'output':str(out),'runs':len(ordered),'target':results['target']['summary']['uncaptured_percent'],'max_mass_error_kg':payload['numerical_audit']['max_mass_error_kg']}),flush=True)

if __name__=='__main__': main()
