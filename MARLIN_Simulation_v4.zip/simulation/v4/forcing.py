"""Read inspected point records. Does not reconstruct a local hydraulic field."""
from datetime import datetime, timedelta
from pathlib import Path
import bisect
import csv
import hashlib
import json
import math

REQUIRED={
    'wind':('era5_wind_2024',['wind_speed_10m','wind_u_east_m_s','wind_v_north_m_s']),
    'waves':('era5_ocean_waves_2024',['wave_height','wave_period']),
    'smoc':('smoc_surface_points_2024',['current_u_east_m_s','current_v_north_m_s','sea_level_height_msl'])
}

class Forcing:
    def __init__(self, root: Path):
        self.root=root
        self.windows=json.loads((root/'data/processed/environment_windows.json').read_text(encoding='utf-8'))
        self.sources={}
        self.rows={}
        for kind,(name,variables) in REQUIRED.items():
            path=root/f'data/processed/{name}.csv'
            rows={}
            with path.open(encoding='utf-8',newline='') as f:
                for r in csv.DictReader(f):
                    if r['point_id']!='0': continue
                    t=datetime.fromisoformat(r['time_utc'].replace('Z','+00:00'))
                    rows[t]={v:float(r[v]) if r[v] else None for v in variables}
                    latitude,longitude=float(r['latitude']),float(r['longitude'])
            self.rows[kind]=rows
            self.sources[kind]={'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'point_id':0,'latitude':latitude,'longitude':longitude,'variables':variables}

    def select(self,label,hours):
        window=next(w for w in self.windows if w['label']==label)
        start=datetime.fromisoformat(window['start_utc'].replace('Z','+00:00'))
        offset=0
        if label in ('high_wave_week','high_current_week'):
            kind,variable=('waves','wave_height') if label=='high_wave_week' else ('smoc','current_u_east_m_s')
            length=math.ceil(hours)
            def severity(index):
                records=[self.rows[kind][start+timedelta(hours=index+j)] for j in range(length)]
                return sum(r['wave_height'] if kind=='waves' else math.hypot(r['current_u_east_m_s'],r['current_v_north_m_s']) for r in records)/length
            offset=max(range(168-length),key=severity)
            start+=timedelta(hours=offset)
        records=[]
        for h in range(math.ceil(hours)+1):
            t=start+timedelta(hours=h)
            values={}
            for kind in REQUIRED:
                record=self.rows[kind].get(t)
                if record is None or any(v is None or not math.isfinite(v) for v in record.values()):
                    raise ValueError(f'Missing {kind} forcing at {t.isoformat()}; refusing zero fill')
                values.update(record)
            records.append(values)
        return WindowForcing(window,records,self.sources,start,offset)

class WindowForcing:
    def __init__(self,window,records,sources,start,offset):
        self.window=window;self.records=records;self.sources=sources;self.start=start;self.offset=offset
    def at(self,minute):
        # Linear interpolation in time only. Provider points differ geographically.
        index=min(int(minute//60),len(self.records)-2)
        fraction=min(1,max(0,(minute-index*60)/60))
        return {k:a+(self.records[index+1][k]-a)*fraction for k,a in self.records[index].items()}
    def metadata(self):
        return {'window':self.window,'interval_start_utc':self.start.isoformat(),'hours_offset_within_week':self.offset,'interval_selection':'Strongest mean wave/current subwindow within selected week' if self.offset else 'Start of selected week','sources':self.sources,'used_hours':len(self.records)-1,'mapping':'Point 0 per product; time interpolation only. Projected regional velocity plus prescribed local component. Transverse component is additionally scaled by assumed factor 0.15. Not a resolved channel field. Wind/waves affect illustrative operating availability; no species wind drift added. Sea level is loaded/checked but does not drive a hydraulic solver.'}
